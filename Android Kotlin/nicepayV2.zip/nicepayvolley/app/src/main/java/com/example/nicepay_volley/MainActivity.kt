package com.example.nicepay_volley

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val reV2 = findViewById(R.id.reV2) as Button
        val diV2 = findViewById(R.id.diV2) as Button

        reV2.setOnClickListener{
            val intent = Intent(applicationContext, Form::class.java)
            intent.putExtra("version","2")
            startActivity(intent)
        }

        diV2.setOnClickListener{
            val intent = Intent(applicationContext, Form::class.java)
            intent.putExtra("version","3")
            startActivity(intent)
        }
    }
}