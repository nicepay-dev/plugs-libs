package com.example.nicepay_volley

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.WebView
import android.widget.*
import androidx.annotation.RequiresApi
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONException
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

class Payment : AppCompatActivity() {
    var partner : String? = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        var partners = resources.getStringArray(R.array.zero)

        val cc = findViewById(R.id.cc) as TextView
        val va = findViewById(R.id.va) as TextView
        val cvs = findViewById(R.id.cvs) as TextView
        val cp = findViewById(R.id.cp) as TextView
        val ew = findViewById(R.id.ew) as TextView
        val pl = findViewById(R.id.pl) as TextView
        val qr = findViewById(R.id.qr) as TextView

        val iMid = intent.getStringExtra("iMid")
        val referenceNo = intent.getStringExtra("referenceNo")
        val amount = intent.getStringExtra("amount")
        var merchantTokenV2 = intent.getStringExtra("merchantToken")
        cc.setOnClickListener{
            val next = Intent(applicationContext, choosePartner::class.java)
            next.putExtra("method","01")
            next.putExtra("iMid",iMid)
            next.putExtra("referenceNo",referenceNo)
            next.putExtra("amount",amount)
            next.putExtra("key", intent.getStringExtra("merchantKey"))
            next.putExtra("merchantToken",merchantTokenV2)
            startActivity(next)
        }

        va.setOnClickListener{
            val next = Intent(applicationContext, choosePartner::class.java)
            next.putExtra("method","02")
            next.putExtra("iMid",iMid)
            next.putExtra("referenceNo",referenceNo)
            next.putExtra("amount",amount)
            next.putExtra("key", intent.getStringExtra("merchantKey"))
            next.putExtra("merchantToken",merchantTokenV2)
            startActivity(next)
        }

        cvs.setOnClickListener{
            val next = Intent(applicationContext, choosePartner::class.java)
            next.putExtra("method","03")
            next.putExtra("iMid",iMid)
            next.putExtra("referenceNo",referenceNo)
            next.putExtra("amount",amount)
            next.putExtra("key", intent.getStringExtra("merchantKey"))
            next.putExtra("merchantToken",merchantTokenV2)
            startActivity(next)
        }

        cp.setOnClickListener{
            val next = Intent(applicationContext, choosePartner::class.java)
            next.putExtra("method","04")
            next.putExtra("iMid",iMid)
            next.putExtra("referenceNo",referenceNo)
            next.putExtra("amount",amount)
            next.putExtra("key", intent.getStringExtra("merchantKey"))
            next.putExtra("merchantToken",merchantTokenV2)
            startActivity(next)
        }

        ew.setOnClickListener{
            val next = Intent(applicationContext, choosePartner::class.java)
            next.putExtra("method","05")
            next.putExtra("iMid",iMid)
            next.putExtra("referenceNo",referenceNo)
            next.putExtra("amount",amount)
            next.putExtra("key", intent.getStringExtra("merchantKey"))
            next.putExtra("merchantToken",merchantTokenV2)
            startActivity(next)
        }

        pl.setOnClickListener{
            val next = Intent(applicationContext, choosePartner::class.java)
            next.putExtra("method","06")
            next.putExtra("iMid",iMid)
            next.putExtra("referenceNo",referenceNo)
            next.putExtra("amount",amount)
            next.putExtra("key", intent.getStringExtra("merchantKey"))
            next.putExtra("merchantToken",merchantTokenV2)
            startActivity(next)
        }

        qr.setOnClickListener{
            val next = Intent(applicationContext, choosePartner::class.java)
            next.putExtra("method","08")
            next.putExtra("iMid",iMid)
            next.putExtra("referenceNo",referenceNo)
            next.putExtra("amount",amount)
            next.putExtra("key", intent.getStringExtra("merchantKey"))
            next.putExtra("merchantToken",merchantTokenV2)
            startActivity(next)
        }
    }


    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }

    // get user's IP Address
    fun getLocalIpAddress(): String? {
        try {
            val en: Enumeration<NetworkInterface> = NetworkInterface.getNetworkInterfaces()
            while (en.hasMoreElements()) {
                val intf: NetworkInterface = en.nextElement()
                val enumIpAddr: Enumeration<InetAddress> = intf.getInetAddresses()
                while (enumIpAddr.hasMoreElements()) {
                    val inetAddress: InetAddress = enumIpAddr.nextElement()
                    if (!inetAddress.isLoopbackAddress() && inetAddress is Inet4Address) {
                        return inetAddress.getHostAddress()
                    }
                }
            }
        } catch (ex: Exception) {
            Log.e("IP Address", ex.toString())
        }
        return null
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun postDataV2(partner: String, method : String) {
        val url : String ="https://dev.nicepay.co.id/nicepay/direct/v2/registration"

        var rekan:String = ""

        when(partner){
            "BRI"->rekan="BRIN"
            "BNI"->rekan="BNIN"
            "BCA"->rekan="CENA"
            "Mandiri"->rekan="BMRI"
            "CIMB"->rekan="BNIA"
            "Danamon"->rekan="BDIN"
            "Maybank"->rekan="IBBK"
            "Permata"->rekan="BBBA"
            "Permata Syariah"->rekan="BBBB"
            "BJB"->rekan="PDJB"
            "BNC"->rekan="YUDB"
            "Alfamart"->rekan="ALMA"
            "Indomaret"->rekan="INDO"
            "OVO"->rekan="OVOE"
            "LinkAja"->rekan="LINK"
            "DANA"->rekan="DANA"
            "Shopeepay"->rekan="ESHP"
            "Mandiri wallet"->rekan="MDRE"
            "BCA(Sakuku)"->rekan="BCAE"
            "Akulaku"->rekan="AKLP"
            "Kredivo"->rekan="KDVI"
            "Indodana"->rekan="IDNA"
            "Mandiri cp"->rekan="MDRC"
            "BCA cp"->rekan="BCAC"
            "CIMB cp"->rekan="CIMC"
            "Jenius cp"->rekan="JENC"
        }

        val requestQueue = Volley.newRequestQueue(this)

        val date = getCurrentDateTime()
        val dateTime = date.toString("yyyyMMddHHmmss")
        val mToken = hashString(dateTime+intent.getStringExtra("merchantToken"))
        val iMid = intent.getStringExtra("iMid")

        val postData = JSONObject()
        try {
            val params = HashMap<String, String>()
            val goodsNm : String = "Test eWallet By Android Kotlin 2"
            val billingNm : String = "Nicepay"
            val billingPhone : String = "081234567891"
            val billingEmail : String = "nicepay_mobile@nicepay.co.id"
            val billingAddr : String = "Jalan Bukit Berbunga 22"
            val billingCity : String = "Jakarta"
            val billingState : String = "Jakarta Selatan"
            val billingPostCd : String = "12870"
            val billingCountry : String = "Indonesia"
            val deliveryNm : String = "Nicepay"
            val deliveryPhone : String = "081234567891"
            val deliveryAddr : String = "Jalan Bukit Berbunga 22"
            val deliveryCity : String = "Jakarta"
            val deliveryState : String = "Jakarta Selatan"
            val deliveryPostCd : String = "12870"
            val deliveryCountry : String = "Indonesia"
            val callBackUrl : String = "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp?merchantNm=PT. Nicepay&email=Nicepay Callback"
            val dbProcessUrl : String = "https://ptsv2.com/t/nicepay-dbProccessUrl/post"
            val description : String = "tes redirect v2 with kotlin"
            val cartData : String = "{\"count\":1,\"item\":[{\"img_url\":\"https://d3nevzfk7ii3be.cloudfront.net/igi/vOrGHXlovukA566A.medium\",\"goods_name\":\"Nokia 3360\",\"goods_detail\":\"Old Nokia 3360\",\"goods_amt\":\""+intent.getStringExtra("amount")+"\",\"goods_quantity\":\"1\"}]}"
            val userIP : String = getLocalIpAddress().toString()

            postData.put("timeStamp",dateTime)
            postData.put("iMid",intent.getStringExtra("iMid"))
            postData.put("payMethod",method)
            postData.put("currency","IDR")
            postData.put("amt",intent.getStringExtra("amount"))
            postData.put("referenceNo",intent.getStringExtra("referenceNo"))
            postData.put("goodsNm",goodsNm)
            postData.put("billingNm",billingNm)
            postData.put("billingPhone",billingPhone)
            postData.put("billingEmail",billingEmail)
            postData.put("billingAddr",billingAddr)
            postData.put("billingCity",billingCity)
            postData.put("billingState",billingState)
            postData.put("billingPostCd",billingPostCd)
            postData.put("billingCountry",billingCountry)
            postData.put("deliveryNm",deliveryNm)
            postData.put("deliveryPhone",deliveryPhone)
            postData.put("deliveryAddr",deliveryAddr)
            postData.put("deliveryCity",deliveryCity)
            postData.put("deliveryState",deliveryState)
            postData.put("deliveryPostCd",deliveryPostCd)
            postData.put("deliveryCountry",deliveryCountry)
            postData.put("dbProcessUrl",dbProcessUrl)
            postData.put("vat","")
            postData.put("fee","")
            postData.put("notaxAmt","")
            postData.put("description",description)
            postData.put("merchantToken",mToken)
            postData.put("reqDt","")
            postData.put("reqTm","")
            postData.put("reqDomain","merchant.com")
            postData.put("reqServerIP","127.0.0.1")
            postData.put("reqClientVer","")
            postData.put("userIP",userIP)
            postData.put("userSessionID","697D6922C961070967D3BA1BA5699C2C")
            postData.put("userAgent",System.getProperty("http.agent"))
            postData.put("userLanguage", Locale.getDefault().toLanguageTag())
            postData.put("cartData",cartData)
            postData.put("sellers","[{\"sellersId\": \"SEL123\",\"sellersNm\": \"Sellers 1\",\"sellersEmail\":\"sellers@test.com\",\"sellersAddress\": {\"sellerNm\": \"Sellers\",\"sellerLastNm\": \"1\",\"sellerAddr\": \"jalan berbangsa 1\",\"sellerCity\":\"Jakarta Barat\",\"sellerPostCd\": \"12344\",\"sellerPhone\":\"08123456789\",\"sellerCountry\": \"ID\"}}]")
            postData.put("instmntType","2")
            postData.put("instmntMon","1")
            postData.put("recurrOpt","0")
            if(method=="02"){
                postData.put("bankCd",rekan)
            }else{
                postData.put("bankCd","")
            }
            postData.put("vacctValidDt","")
            postData.put("vacctValidTm","")
            postData.put("merFixAcctId","")
            if(method!="02"){
                postData.put("mitraCd",rekan)
            }else{
                postData.put("mitraCd","")
            }

            Log.e("send", postData.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, postData,
            { response ->
                val cd : String? = response.getString("resultCd")
                if(cd == "0000") {
                    val next = Intent(applicationContext, paymentPage::class.java)
                    if(method == "02"){
                        next.putExtra("validDt", response.getString("vacctValidDt"))
                        next.putExtra("validTm", response.getString("vacctValidTm"))
                        next.putExtra("payNo", response.getString("vacctNo"))
                    }else if(method == "03"){
                        next.putExtra("validDt", response.getString("payValidDt"))
                        next.putExtra("validTm", response.getString("payValidTm"))
                        next.putExtra("payNo", response.getString("payNo"))
                    }
                    next.putExtra("dateTime", dateTime)
                    next.putExtra("iMid", iMid)
                    next.putExtra("amount", response.getString("amt"))
                    next.putExtra("tXid", response.getString("tXid"))
                    next.putExtra("referenceNo", response.getString("referenceNo"))
                    next.putExtra("token", mToken)
                    next.putExtra("key", intent.getStringExtra("merchantKey"))
                    startActivity(next)
                }else{
                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
                }
                Log.e("response", response.toString())
            }
        ) { error -> error.printStackTrace() }

        requestQueue.add(jsonObjectRequest)
    }

    // convert merchant token
    @RequiresApi(Build.VERSION_CODES.O)
    private fun hashString(input: String): String {
        val HEX_CHARS = "0123456789abcdef"
        val bytes = MessageDigest
            .getInstance("SHA-256")
            .digest(input.toByteArray())
        val result = StringBuilder(bytes.size * 2)

        bytes.forEach {
            val i = it.toInt()
            result.append(HEX_CHARS[i shr 4 and 0x0f])
            result.append(HEX_CHARS[i and 0x0f])
        }

        return result.toString()
    }
}