package com.example.nicepay_volley

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import org.w3c.dom.Text

class paymentStatus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_status)

        val image = findViewById<ImageView>(R.id.statusImage)
        val text = findViewById<TextView>(R.id.statusText)
        val status = intent.getStringExtra("status")
        val type = intent.getStringExtra("type")
        val paid = resources.getIdentifier("@drawable/paid", null, packageName)
        val unpaid = resources.getIdentifier("@drawable/unpaid", null, packageName)
        val exp = resources.getIdentifier("@drawable/exp", null, packageName)
        if(type=="cancel"){
            if(intent.getStringExtra("resultMsg") == "SUCCESS") {
                image.setImageDrawable(resources.getDrawable(paid))
                text.setText("Pembatalan Pembayaran Sukses")
            }else{
                image.setImageDrawable(resources.getDrawable(exp))
                text.setText("Pembatalan Pembayaran Gagal")
            }
        }else{
            if(status == "0"){
                image.setImageDrawable(resources.getDrawable(paid))
                text.setText("Pembayaran anda sudah dibayar")
            }else if(status == "3"){
                image.setImageDrawable(resources.getDrawable(unpaid))
                text.setText("Pembayaran anda belum dibayar")
            }else if(status == "4"){
                image.setImageDrawable(resources.getDrawable(exp))
                text.setText("Pembayaran anda sudah expired")
            }
        }


    }
}
