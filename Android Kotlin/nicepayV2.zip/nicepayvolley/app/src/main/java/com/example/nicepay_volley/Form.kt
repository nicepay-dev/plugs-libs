package com.example.nicepay_volley

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*


class Form : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form)

        val version = intent.getStringExtra("version")

        Log.e("IP address", "secret")

        val submit = findViewById(R.id.btn_submit) as Button
        var reff = findViewById(R.id.reffno) as EditText
        var iMid = findViewById(R.id.iMid) as EditText
        var mKey = findViewById(R.id.merchantKey) as EditText
        var amt = findViewById(R.id.amt) as EditText

        Log.e("API version", version.toString())

        submit.setOnClickListener{
            val iMid = iMid.text.toString().trim()
            val referenceNo = reff.text.toString().trim()
            val amount = amt.text.toString().trim()

            val date = getCurrentDateTime()
            val dateTime = date.toString("yyyyMMddHHmmss")

            var mTokenBefore : String = iMid+referenceNo+amount+mKey.text.toString().trim()
            var mTokenAfter = hashString(mTokenBefore)

            val merchantToken = mTokenAfter

            var mTokenBeforeV2 : String = dateTime+iMid+referenceNo+amount+mKey.text.toString().trim()
            var mTokenAfterV2 = hashString(mTokenBeforeV2)

            val merchantTokenV2 = mTokenAfterV2

            Log.e("mtoken", merchantToken)

            if(version == "2"){
                postDataV2(
                    iMid,
                    referenceNo,
                    merchantTokenV2,
                    amount,
                    dateTime,
                    mKey.text.toString().trim()
                )
            }else{
                val intent = Intent(applicationContext, Payment::class.java)
                intent.putExtra("iMid",iMid)
                intent.putExtra("referenceNo",referenceNo)
                intent.putExtra("amount",amount)
                intent.putExtra("merchantToken",iMid+referenceNo+amount+mKey.text.toString().trim())
                intent.putExtra("merchantKey",mKey.text.toString().trim())
                startActivity(intent)
            }

        }
    }

    // convert merchant token
    @RequiresApi(Build.VERSION_CODES.O)
    private fun hashString(input: String): String {
        val HEX_CHARS = "0123456789abcdef"
        val bytes = MessageDigest
            .getInstance("SHA-256")
            .digest(input.toByteArray())
        val result = StringBuilder(bytes.size * 2)

        bytes.forEach {
            val i = it.toInt()
            result.append(HEX_CHARS[i shr 4 and 0x0f])
            result.append(HEX_CHARS[i and 0x0f])
        }

        return result.toString()
    }

    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }

    // get user's IP Address
    fun getLocalIpAddress(): String? {
        try {
            val en: Enumeration<NetworkInterface> = NetworkInterface.getNetworkInterfaces()
            while (en.hasMoreElements()) {
                val intf: NetworkInterface = en.nextElement()
                val enumIpAddr: Enumeration<InetAddress> = intf.getInetAddresses()
                while (enumIpAddr.hasMoreElements()) {
                    val inetAddress: InetAddress = enumIpAddr.nextElement()
                    if (!inetAddress.isLoopbackAddress() && inetAddress is Inet4Address) {
                        return inetAddress.getHostAddress()
                    }
                }
            }
        } catch (ex: Exception) {
            Log.e("IP Address", ex.toString())
        }
        return null
    }

    // for redirect V.2
    fun postDataV2(iMid:String, reff:String, mToken:String, amounts:String, dateTime:String, mKey:String){
        val url : String ="https://dev.nicepay.co.id/nicepay/redirect/v2/registration"

        val requestQueue = Volley.newRequestQueue(this)

        val postData = JSONObject()
        try {
            val params = HashMap<String, String>()
            val goodsNm : String = "Test eWallet By Android Kotlin 2"
            val billingNm : String = "Nicepay"
            val billingPhone : String = "081234567891"
            val billingEmail : String = "nicepay_mobile@nicepay.co.id"
            val billingAddr : String = "Jalan Bukit Berbunga 22"
            val billingCity : String = "Jakarta"
            val billingState : String = "Jakarta Selatan"
            val billingPostCd : String = "12870"
            val billingCountry : String = "Indonesia"
            val deliveryNm : String = "Nicepay"
            val deliveryPhone : String = "081234567891"
            val deliveryAddr : String = "Jalan Bukit Berbunga 22"
            val deliveryCity : String = "Jakarta"
            val deliveryState : String = "Jakarta Selatan"
            val deliveryPostCd : String = "12870"
            val deliveryCountry : String = "Indonesia"
            val callBackUrl : String = "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp?merchantNm=PT. Nicepay&email=Nicepay Callback"
            val dbProcessUrl : String = "https://ptsv2.com/t/nicepay-dbProccessUrl/post"
            val description : String = "tes redirect v2 with kotlin"
            val cartData : String = "{\"count\":1,\"item\":[{\"img_url\":\"https://d3nevzfk7ii3be.cloudfront.net/igi/vOrGHXlovukA566A.medium\",\"goods_name\":\"Nokia 3360\",\"goods_detail\":\"Old Nokia 3360\",\"goods_amt\":\""+amounts+"\",\"goods_quantity\":\"1\"}]}"
            val userIP : String = getLocalIpAddress().toString()

            postData.put("timeStamp",dateTime)
            postData.put("iMid",iMid)
            postData.put("payMethod","00")
            postData.put("currency","IDR")
            postData.put("amt",amounts)
            postData.put("referenceNo",reff)
            postData.put("callBackUrl",callBackUrl)
            postData.put("goodsNm",goodsNm)
            postData.put("billingNm",billingNm)
            postData.put("billingPhone",billingPhone)
            postData.put("billingEmail",billingEmail)
            postData.put("billingAddr",billingAddr)
            postData.put("billingCity",billingCity)
            postData.put("billingState",billingState)
            postData.put("billingPostCd",billingPostCd)
            postData.put("billingCountry",billingCountry)
            postData.put("deliveryNm",deliveryNm)
            postData.put("deliveryPhone",deliveryPhone)
            postData.put("deliveryAddr",deliveryAddr)
            postData.put("deliveryCity",deliveryCity)
            postData.put("deliveryState",deliveryState)
            postData.put("deliveryPostCd",deliveryPostCd)
            postData.put("deliveryCountry",deliveryCountry)
            postData.put("dbProcessUrl",dbProcessUrl)
            postData.put("vat","")
            postData.put("fee","")
            postData.put("notaxAmt","")
            postData.put("description",description)
            postData.put("merchantToken",mToken)
            postData.put("reqDt","")
            postData.put("reqTm","")
            postData.put("reqDomain","merchant.com")
            postData.put("reqServerIP","127.0.0.1")
            postData.put("reqClientVer","")
            postData.put("userIP",userIP)
            postData.put("userSessionID","697D6922C961070967D3BA1BA5699C2C")
            postData.put("userAgent",System.getProperty("http.agent"))
            postData.put("userLanguage",Locale.getDefault().toLanguageTag())
            postData.put("cartData",cartData)
            postData.put("sellers","[{\"sellersId\": \"SEL123\",\"sellersNm\": \"Sellers 1\",\"sellersEmail\":\"sellers@test.com\",\"sellersAddress\": {\"sellerNm\": \"Sellers\",\"sellerLastNm\": \"1\",\"sellerAddr\": \"jalan berbangsa 1\",\"sellerCity\":\"Jakarta Barat\",\"sellerPostCd\": \"12344\",\"sellerPhone\":\"08123456789\",\"sellerCountry\": \"ID\"}}]")
            postData.put("instmntType","2")
            postData.put("instmntMon","1")
            postData.put("recurrOpt","0")
            postData.put("bankCd","BBRI")
            postData.put("vacctValidDt","")
            postData.put("vacctValidTm","")
            postData.put("merFixAcctId","")
            postData.put("mitraCd","")
            postData.put("msId","")
            postData.put("msFee","")
            postData.put("msFeeType","")
            postData.put("escrowCl","")
            postData.put("shopId","")

            Log.e("send", postData.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, postData,
            { response ->
                val cd : String? = response.getString("resultCd")
                val id : String? = response.getString("tXid")
                val url : String? = response.getString("paymentURL")
                if(cd == "0000") {
                    val next = Intent(applicationContext, WebViewActivity::class.java)

                    next.putExtra("timeStamp",dateTime)
                    next.putExtra("tXid",intent.getStringExtra("tXid"))
                    next.putExtra("amt",amounts)
                    next.putExtra("referenceNo", reff)
                    next.putExtra("merchantToken",mToken)
                    next.putExtra("iMid",iMid)
                    next.putExtra("url", url)
                    next.putExtra("tXid", id)
                    next.putExtra("mKey", mKey)
                    next.putExtra("version", intent.getStringExtra("version"))
                    startActivity(next)
                }else{
                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
                }
                Log.e("response", response.toString())
            }
        ) { error -> error.printStackTrace() }

        requestQueue.add(jsonObjectRequest)
    }
}