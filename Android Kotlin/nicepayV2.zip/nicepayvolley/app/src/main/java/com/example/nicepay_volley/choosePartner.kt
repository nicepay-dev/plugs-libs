package com.example.nicepay_volley

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.core.view.isVisible
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

class choosePartner : AppCompatActivity() {
    var partner : String? = ""
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_partner)
        var partners = resources.getStringArray(R.array.zero)
        var amount = findViewById(R.id.title2) as TextView
        var finish = findViewById(R.id.finish) as Button
        val method = intent.getStringExtra("method")
        if(method == "01"){
            partners = resources.getStringArray(R.array.inst)
        }else if(method == "02"){
            partners = resources.getStringArray(R.array.va)
        }else if(method == "03"){
            partners = resources.getStringArray(R.array.cvs)
        }else if(method == "04"){
            partners = resources.getStringArray(R.array.cp)
        }else if(method == "05"){
            partners = resources.getStringArray(R.array.ew)
        }else if(method == "06"){
            partners = resources.getStringArray(R.array.pl)
        }else if(method == "08"){
            postDataV2(
                "QSHP",
                "08"
            )
        }

        amount.setText("Total Pembayaran : "+intent.getStringExtra("amount"))


        // dropdown for redirect V.1
        val spinner = findViewById(R.id.partner) as Spinner
        // end of dropdown

        // dropdown condition for redirect V.1 : Payment Method, Instalment, Instalment Types
        if (spinner != null) {
            val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_item, partners)
            spinner.adapter = adapter
            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>,
                                            view: View, position: Int, id: Long) {
                    partner = partners[position]
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

        finish.setOnClickListener{
            var partner = partner.toString().trim()

            when(partner){
                "Full Payment"->partner="1"
                "3 Months"->partner="3"
                "6 Months"->partner="6"
                "9 Months"->partner="9"
                "12 Months"->partner="12"
                "BRI"->partner="BRIN"
                "BNI"->partner="BNIN"
                "BCA"->partner="CENA"
                "Mandiri"->partner="BMRI"
                "CIMB"->partner="BNIA"
                "Danamon"->partner="BDIN"
                "Maybank"->partner="IBBK"
                "Permata"->partner="BBBA"
                "Permata Syariah"->partner="BBBB"
                "BJB"->partner="PDJB"
                "BNC"->partner="YUDB"
                "Alfamart"->partner="ALMA"
                "Indomaret"->partner="INDO"
                "OVO"->partner="OVOE"
                "LinkAja"->partner="LINK"
                "DANA"->partner="DANA"
                "Shopeepay"->partner="ESHP"
                "Mandiri wallet"->partner="MDRE"
                "BCA(Sakuku)"->partner="BCAE"
                "Akulaku"->partner="AKLP"
                "Kredivo"->partner="KDVI"
                "Indodana"->partner="IDNA"
                "Mandiri cp"->partner="MDRC"
                "BCA cp"->partner="BCAC"
                "CIMB cp"->partner="CIMC"
                "Jenius cp"->partner="JENC"
            }
            if (method != null) {
                postDataV2(
                    partner,
                    method
                )
            }
        }
    }

    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }

    // get user's IP Address
    fun getLocalIpAddress(): String? {
        try {
            val en: Enumeration<NetworkInterface> = NetworkInterface.getNetworkInterfaces()
            while (en.hasMoreElements()) {
                val intf: NetworkInterface = en.nextElement()
                val enumIpAddr: Enumeration<InetAddress> = intf.getInetAddresses()
                while (enumIpAddr.hasMoreElements()) {
                    val inetAddress: InetAddress = enumIpAddr.nextElement()
                    if (!inetAddress.isLoopbackAddress() && inetAddress is Inet4Address) {
                        return inetAddress.getHostAddress()
                    }
                }
            }
        } catch (ex: Exception) {
            Log.e("IP Address", ex.toString())
        }
        return null
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun postDataV2(partner: String, method : String) {
        val url : String ="https://dev.nicepay.co.id/nicepay/direct/v2/registration"

        val requestQueue = Volley.newRequestQueue(this)

        val date = getCurrentDateTime()
        val dateTime = date.toString("yyyyMMddHHmmss")
        val mToken = hashString(dateTime+intent.getStringExtra("merchantToken"))
        val iMid = intent.getStringExtra("iMid")

        var waktu : String = ""
        val postData = JSONObject()
        try {
            val params = HashMap<String, String>()
            val goodsNm : String = "Test eWallet By Android Kotlin 2"
            val billingNm : String = "Nicepay"
            val billingPhone : String = "082168349939"
            val billingEmail : String = "nicepay_mobile@nicepay.co.id"
            val billingAddr : String = "Jalan Bukit Berbunga 22"
            val billingCity : String = "Jakarta"
            val billingState : String = "Jakarta Selatan"
            val billingPostCd : String = "12870"
            val billingCountry : String = "Indonesia"
            val deliveryNm : String = "Nicepay"
            val deliveryPhone : String = "081234567891"
            val deliveryAddr : String = "Jalan Bukit Berbunga 22"
            val deliveryCity : String = "Jakarta"
            val deliveryState : String = "Jakarta Selatan"
            val deliveryPostCd : String = "12870"
            val deliveryCountry : String = "Indonesia"
            val callBackUrl : String = "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp?merchantNm=PT. Nicepay&email=Nicepay Callback"
            val dbProcessUrl : String = "https://ptsv2.com/t/nicepay-dbProccessUrl/post"
            val description : String = "tes redirect v2 with kotlin"
            val cartData : String = "{\"count\":1,\"item\":[{\"img_url\":\"https://d3nevzfk7ii3be.cloudfront.net/igi/vOrGHXlovukA566A.medium\",\"goods_name\":\"Nokia 3360\",\"goods_detail\":\"Old Nokia 3360\",\"goods_amt\":\""+intent.getStringExtra("amount")+"\",\"goods_quantity\":\"1\"}]}"
            val userIP : String = getLocalIpAddress().toString()

            postData.put("timeStamp",dateTime)
            postData.put("iMid",intent.getStringExtra("iMid"))
            postData.put("payMethod",method)
            postData.put("currency","IDR")
            postData.put("amt",intent.getStringExtra("amount"))
            postData.put("referenceNo",intent.getStringExtra("referenceNo"))
            postData.put("goodsNm",goodsNm)
            postData.put("billingNm",billingNm)
            postData.put("billingPhone",billingPhone)
            postData.put("billingEmail",billingEmail)
            postData.put("billingAddr",billingAddr)
            postData.put("billingCity",billingCity)
            postData.put("billingState",billingState)
            postData.put("billingPostCd",billingPostCd)
            postData.put("billingCountry",billingCountry)
            postData.put("deliveryNm",deliveryNm)
            postData.put("deliveryPhone",deliveryPhone)
            postData.put("deliveryAddr",deliveryAddr)
            postData.put("deliveryCity",deliveryCity)
            postData.put("deliveryState",deliveryState)
            postData.put("deliveryPostCd",deliveryPostCd)
            postData.put("deliveryCountry",deliveryCountry)
            postData.put("dbProcessUrl",dbProcessUrl)
            postData.put("vat","")
            postData.put("fee","")
            postData.put("notaxAmt","")
            postData.put("description",description)
            postData.put("merchantToken",mToken)
            postData.put("reqDt","")
            postData.put("reqTm","")
            postData.put("reqDomain","merchant.com")
            postData.put("reqServerIP","127.0.0.1")
            postData.put("reqClientVer","")
            postData.put("userIP",userIP)
            postData.put("userSessionID","697D6922C961070967D3BA1BA5699C2C")
            postData.put("userAgent",System.getProperty("http.agent"))
            postData.put("userLanguage", Locale.getDefault().toLanguageTag())
            postData.put("cartData",cartData)
            postData.put("sellers","[{\"sellersId\": \"SEL123\",\"sellersNm\": \"Sellers 1\",\"sellersEmail\":\"sellers@test.com\",\"sellersAddress\": {\"sellerNm\": \"Sellers\",\"sellerLastNm\": \"1\",\"sellerAddr\": \"jalan berbangsa 1\",\"sellerCity\":\"Jakarta Barat\",\"sellerPostCd\": \"12344\",\"sellerPhone\":\"08123456789\",\"sellerCountry\": \"ID\"}}]")
            postData.put("instmntType","2")
            if(method=="01"){
                postData.put("instmntMon", partner)
            }else {
                postData.put("instmntMon", "1")
            }
            postData.put("recurrOpt","0")
            if(method=="02"){
                postData.put("bankCd",partner)
            }else{
                postData.put("bankCd","")
            }
            postData.put("vacctValidDt","")
            postData.put("vacctValidTm","")
            postData.put("merFixAcctId","")
            if(method!="02"){
                postData.put("mitraCd",partner)
            }else{
                postData.put("mitraCd","")
            }
            if(method=="08"){
                postData.put("paymentExpDt","")
                postData.put("paymentExpTm","")
                postData.put("shopId","NICEPAY")
            }

            Log.e("send", postData.toString())
            waktu = postData.getString("timeStamp")
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, postData,
            { response ->
                val cd : String? = response.getString("resultCd")
                if(cd == "0000") {
                    var next = Intent()
                    if(method=="02" || method=="03" || method=="08"){
                        next = Intent(applicationContext, paymentPage::class.java)
                    }else if(method=="01") {
                        next = Intent(applicationContext, creditCard::class.java)
                    }else if(method=="05"){
                        next = Intent(applicationContext, v2PaymentDetail::class.java)
                    }
                    if(method == "02"){
                        next.putExtra("validDt", response.getString("vacctValidDt"))
                        next.putExtra("validTm", response.getString("vacctValidTm"))
                        next.putExtra("payNo", response.getString("vacctNo"))
                        next.putExtra("method", "02")
                    }else if(method == "03"){
                        next.putExtra("validDt", response.getString("payValidDt"))
                        next.putExtra("validTm", response.getString("payValidTm"))
                        next.putExtra("payNo", response.getString("payNo"))
                        next.putExtra("method", "03")
                    }else if(method == "08"){
                        next.putExtra("link", response.getString("qrUrl"))
                        next.putExtra("method", "08")
                    }else if(method == "01"){
                        next.putExtra("method", "01")
                    }else if(method == "05"){
                        next.putExtra("method", "05")
                    }
                    next.putExtra("dateTime", waktu)
                    Log.e("waktunya", waktu)
                    next.putExtra("iMid", iMid)
                    next.putExtra("amount", response.getString("amt"))
                    next.putExtra("tXid", response.getString("tXid"))
                    next.putExtra("referenceNo", response.getString("referenceNo"))
                    next.putExtra("token", mToken)
                    next.putExtra("key", intent.getStringExtra("key"))
                    startActivity(next)
                }else{
                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
                }
                Log.e("response", response.toString())
            }
        ) { error -> error.printStackTrace() }

        requestQueue.add(jsonObjectRequest)
    }

    // convert merchant token
    @RequiresApi(Build.VERSION_CODES.O)
    private fun hashString(input: String): String {
        val HEX_CHARS = "0123456789abcdef"
        val bytes = MessageDigest
            .getInstance("SHA-256")
            .digest(input.toByteArray())
        val result = StringBuilder(bytes.size * 2)

        bytes.forEach {
            val i = it.toInt()
            result.append(HEX_CHARS[i shr 4 and 0x0f])
            result.append(HEX_CHARS[i and 0x0f])
        }

        return result.toString()
    }
}