package com.example.nicepay_volley

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.core.view.isVisible
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

class cancelOption : AppCompatActivity() {
    var cOption : String? = "01"
    var pMeth : String? = "01"
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cancel_option)
        val spinner = findViewById(R.id.cancelOption) as Spinner
        val rePay = findViewById(R.id.rePayMeth) as Spinner
        val amount = findViewById(R.id.totalAmount) as EditText
        val finish = findViewById(R.id.bayar) as Button

        val cOpt = resources.getStringArray(R.array.cancel)
        val pMethod = resources.getStringArray(R.array.PayMethod)

        val version = intent.getStringExtra("version")

        Log.e("id", intent.getStringExtra("iMid").toString())

        if(version != "2"){
            rePay.isVisible = false
        }

        if (spinner != null) {
            val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_item, cOpt)
            spinner.adapter = adapter
            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>,
                                            view: View, position: Int, id: Long) {
                    cOption = cOpt[position]
                    if(cOption == "partial"){
                        amount.isVisible = true
                    }else{
                        amount.isVisible = false
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

        if (rePay != null) {
            val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_item, pMethod)
            rePay.adapter = adapter
            rePay.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>,
                                            view: View, position: Int, id: Long) {
                    Log.e("pay method", cOption.toString())
                    pMeth = pMethod[position]
                    when(pMeth){
                        "Credit Card"->pMeth="01"
                        "Virtual Account"->pMeth="02"
                        "Convenience Store"->pMeth="03"
                        "ClickPay"->pMeth="04"
                        "eWallet"->pMeth="05"
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

        finish.setOnClickListener {
            when(cOption){
                "partial"->cOption="2"
                "full"->cOption="1"
            }

            var amt : String = ""

            if(cOption == "1"){
                amt = intent.getStringExtra("amt").toString()
            }else{
                amt = amount.text.toString().trim()
            }

            if(version == "2"){
                cancel2(cOption.toString(), amt, pMeth.toString())
            }else{
                cancelv2(cOption.toString(), amt)
            }

        }

    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun cancelv2(option : String, amount: String) {
        val url : String ="https://dev.nicepay.co.id/nicepay/direct/v2/cancel"

        Log.e("Url", url)
        Log.e("mKey", intent.getStringExtra("key").toString())
        val requestQueue = Volley.newRequestQueue(this)
        val method = intent.getStringExtra("method")

        val date = getCurrentDateTime()
        val dateTime = date.toString("yyyyMMddHHmmss")

        val postData = JSONObject()
        try {
            postData.put("timeStamp",dateTime)
            postData.put("tXid",intent.getStringExtra("tXid"))
            postData.put("preauthToken","")
            postData.put("amt",amount)
            postData.put("merchantToken",hashString(dateTime+intent.getStringExtra("iMid")+intent.getStringExtra("tXid")+amount+intent.getStringExtra("key")))
            postData.put("iMid",intent.getStringExtra("iMid"))
            postData.put("payMethod",method)
            postData.put("cancelType",option)
            postData.put("cancelMsg","Request Cancel")
            postData.put("cancelServerIp","")
            postData.put("cancelUserId","")
            postData.put("cancelUserIp","")
            postData.put("cancelUserInfo","")
            postData.put("cancelRetryCnt","")
            postData.put("worker","")

            Log.e("send", postData.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, postData,
            { response ->
                val cd : String? = response.getString("resultCd")
                if(cd == "0000") {
                    val intent = Intent(applicationContext, paymentStatus::class.java)
                    intent.putExtra("type", "cancel")
                    intent.putExtra("resultMsg", response.getString("resultMsg"))
                    startActivity(intent)
                }else{
                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
                }
                Log.e("response", response.toString())
            }
        ) { error -> error.printStackTrace() }

        requestQueue.add(jsonObjectRequest)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun cancel2(option: String, amount: String, method: String) {
        val url : String ="https://dev.nicepay.co.id/nicepay/direct/v2/cancel"

        val requestQueue = Volley.newRequestQueue(this)
        val date = getCurrentDateTime()
        val dateTime = date.toString("yyyyMMddHHmmss")
        Log.e("tes",dateTime+intent.getStringExtra("iMid")+intent.getStringExtra("tXid")+amount+intent.getStringExtra("key"))

        val postData = JSONObject()
        try {
            postData.put("timeStamp",dateTime)
            postData.put("tXid",intent.getStringExtra("tXid"))
            postData.put("preauthToken","")
            postData.put("amt",amount)
            postData.put("merchantToken",hashString(dateTime+intent.getStringExtra("iMid")+intent.getStringExtra("tXid")+amount+intent.getStringExtra("mKey")))
            postData.put("iMid",intent.getStringExtra("iMid"))
            postData.put("payMethod",method)
            postData.put("cancelType",option)
            postData.put("cancelMsg","Request Cancel")
            postData.put("cancelServerIp","")
            postData.put("cancelUserId","")
            postData.put("cancelUserIp","")
            postData.put("cancelUserInfo","")
            postData.put("cancelRetryCnt","")
            postData.put("worker","")

            Log.e("iMid", intent.getStringExtra("dateTime").toString())
            Log.e("send", postData.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, postData,
            { response ->
                val cd : String? = response.getString("resultCd")
                if(cd == "0000") {
                    val intent = Intent(applicationContext, paymentStatus::class.java)
                    intent.putExtra("type", "cancel")
                    intent.putExtra("resultMsg", response.getString("resultMsg"))
                    startActivity(intent)
                }else{
                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
                }
                Log.e("response", response.toString())
            }
        ) { error -> error.printStackTrace() }

        requestQueue.add(jsonObjectRequest)
    }

    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun hashString(input: String): String {
        val HEX_CHARS = "0123456789abcdef"
        val bytes = MessageDigest
            .getInstance("SHA-256")
            .digest(input.toByteArray())
        val result = StringBuilder(bytes.size * 2)

        bytes.forEach {
            val i = it.toInt()
            result.append(HEX_CHARS[i shr 4 and 0x0f])
            result.append(HEX_CHARS[i and 0x0f])
        }

        return result.toString()
    }
}