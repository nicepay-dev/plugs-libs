package com.example.nicepay_volley

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import java.text.SimpleDateFormat
import java.util.*

class v2PaymentDetail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_v2_payment_detail)

        val next = findViewById<Button>(R.id.next)

        Log.e("datetime", intent.getStringExtra("dateTime").toString())
        next.setOnClickListener {
            val finish = Intent(applicationContext, v2DirectPayment::class.java)
            finish.putExtra("method", "05")
            finish.putExtra("timeStamp", intent.getStringExtra("dateTime"))
            finish.putExtra("tXid", intent.getStringExtra("tXid"))
            finish.putExtra("merchantToken", intent.getStringExtra("token"))
            finish.putExtra("amt", intent.getStringExtra("amount"))
            finish.putExtra("referenceNo", intent.getStringExtra("referenceNo"))
            finish.putExtra("tXid", intent.getStringExtra("tXid"))
            finish.putExtra("key", intent.getStringExtra("key"))
            finish.putExtra("iMid", intent.getStringExtra("iMid"))
            startActivity(finish)
        }
    }

    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }
}