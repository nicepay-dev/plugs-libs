package com.example.nicepay_volley

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class creditCard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit_card)

        val next = findViewById<Button>(R.id.buy)
        val cc = findViewById<EditText>(R.id.cc)
        val expDt = findViewById<EditText>(R.id.expDt)
        val cvv = findViewById<EditText>(R.id.cvv)

        cc.addTextChangedListener((object : separatorText(' ', 4) {
            override fun onAfterTextChanged(text: String) {
                cc.run {
                    setText(text)
                    setSelection(text.length)
                }
            }
        }))

        next.setOnClickListener {
            var ccText = cc.text.toString().trim()
            val expText = expDt.text.toString().trim()
            val cvvText = cvv.text.toString().trim()

            val date = getCurrentDateTime()
            val dateTime = date.toString("yyyyMMddHHmmss")

            ccText = ccText.replace(" ", "")
            val bayar = Intent(applicationContext, v2DirectPayment::class.java)
            bayar.putExtra("timeStamp",intent.getStringExtra("dateTime").toString())
            bayar.putExtra("tXid",intent.getStringExtra("tXid"))
            bayar.putExtra("merchantToken",intent.getStringExtra("token"))
            bayar.putExtra("amt",intent.getStringExtra("amount"))
            bayar.putExtra("iMid",intent.getStringExtra("iMid"))
            bayar.putExtra("callBackUrl","https://pluto.nicepay.co.id/result")
            bayar.putExtra("cardNo",ccText)
            bayar.putExtra("cardExpYymm",expText)
            bayar.putExtra("cardCvv",cvvText)
            bayar.putExtra("cardHolderNm","Jackson")
            bayar.putExtra("key",intent.getStringExtra("key"))
            bayar.putExtra("referenceNo", intent.getStringExtra("referenceNo"))
            bayar.putExtra("method","01")
            startActivity(bayar)

            Log.e("timeStamp",intent.getStringExtra("dateTime").toString())
            Log.e("tXid", intent.getStringExtra("tXid").toString())
            Log.e("merchantToken", intent.getStringExtra("token").toString())
            Log.e("amt", intent.getStringExtra("amount").toString())
            Log.e("callBackUrl","https://pluto.nicepay.co.id/result")
            Log.e("cardNo",ccText)
            Log.e("cardExpYymm",expText)
            Log.e("cardCvv",cvvText)
            Log.e("cardHolderNm","Jackson")
            Log.e("key", intent.getStringExtra("key").toString())
            Log.e("referenceNo", intent.getStringExtra("referenceNo").toString())
            Log.e("method","01")
        }
    }

    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }
}
