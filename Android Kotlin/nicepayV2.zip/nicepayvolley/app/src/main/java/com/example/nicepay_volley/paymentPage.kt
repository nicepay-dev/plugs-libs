package com.example.nicepay_volley

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

class paymentPage : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_page)

        val payNo = findViewById<TextView>(R.id.payNo)
        val time = findViewById<TextView>(R.id.time)
        val title = findViewById<TextView>(R.id.title)
        val sts = findViewById<Button>(R.id.status)
        val cancel = findViewById<Button>(R.id.cancel)
        val image = findViewById<ImageView>(R.id.QR)

        val method = intent.getStringExtra("method")
        Log.e("method", method.toString())
        if(method=="08"){
            val link = intent.getStringExtra("link")
            image.isVisible = true
            DownloadImageFromInternet(findViewById(R.id.QR)).execute(link)
            payNo.isVisible = false
            time.isVisible = false
            title.isVisible = false
        }else{
            payNo.setText(intent.getStringExtra("payNo"))
            val current = intent.getStringExtra("validDt")+intent.getStringExtra("validTm")
            val formatters = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
            time.setText("Valid until : "+LocalDateTime.parse(current, formatters))
        }

        sts.setOnClickListener{
            status()
        }

        cancel.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Cancel Transaction")
            builder.setMessage("Are you sure want to cancel this transaction?")

            builder.setPositiveButton(android.R.string.yes) { dialog, which ->
                cancel(method.toString())
            }

            builder.setNegativeButton(android.R.string.no) { dialog, which ->
                Toast.makeText(applicationContext,
                    android.R.string.no, Toast.LENGTH_SHORT).show()
            }

            builder.setNeutralButton("Maybe") { dialog, which ->
                Toast.makeText(applicationContext,
                    "Maybe", Toast.LENGTH_SHORT).show()
            }
            builder.show()

        }

    }



    private fun status() {
        val url : String ="https://dev.nicepay.co.id/nicepay/direct/v2/inquiry"

        val requestQueue = Volley.newRequestQueue(this)

        val postData = JSONObject()
        try {
            postData.put("timeStamp",intent.getStringExtra("dateTime"))
            postData.put("tXid",intent.getStringExtra("tXid"))
            postData.put("referenceNo",intent.getStringExtra("referenceNo"))
            postData.put("amt",intent.getStringExtra("amount"))
            postData.put("merchantToken",intent.getStringExtra("token"))
            postData.put("iMid",intent.getStringExtra("iMid"))

            Log.e("iMid", intent.getStringExtra("iMid").toString())
            Log.e("send", postData.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, postData,
            { response ->
                val cd : String? = response.getString("resultCd")
                if(cd == "0000") {
                    val intent = Intent(applicationContext, paymentStatus::class.java)
                    intent.putExtra("status", response.getString("status"))
                    startActivity(intent)
                }else{
                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
                }
                Log.e("response", response.toString())
            }
        ) { error -> error.printStackTrace() }

        requestQueue.add(jsonObjectRequest)
    }

    private fun cancel(method : String) {
        val url : String ="https://dev.nicepay.co.id/nicepay/direct/v2/cancel"

        val requestQueue = Volley.newRequestQueue(this)

        val postData = JSONObject()
        try {
            postData.put("timeStamp",intent.getStringExtra("dateTime"))
            postData.put("tXid",intent.getStringExtra("tXid"))
            postData.put("preauthToken","")
            postData.put("amt",intent.getStringExtra("amount"))
            postData.put("merchantToken",intent.getStringExtra("token"))
            postData.put("iMid",intent.getStringExtra("iMid"))
            postData.put("payMethod",method)
            postData.put("cancelType","1")
            postData.put("cancelMsg","Request Cancel")
            postData.put("cancelServerIp","")
            postData.put("cancelUserId","")
            postData.put("cancelUserIp","")
            postData.put("cancelUserInfo","")
            postData.put("cancelRetryCnt","")
            postData.put("worker","")

            Log.e("iMid", intent.getStringExtra("iMid").toString())
            Log.e("send", postData.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, postData,
            { response ->
                val cd : String? = response.getString("resultCd")
                if(cd == "0000") {
                    val intent = Intent(applicationContext, paymentStatus::class.java)
                    intent.putExtra("status", response.getString("status"))
                    startActivity(intent)
                }else{
                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
                }
                Log.e("response", response.toString())
            }
        ) { error -> error.printStackTrace() }

        requestQueue.add(jsonObjectRequest)
    }

    @SuppressLint("StaticFieldLeak")
    @Suppress("DEPRECATION")
    private inner class DownloadImageFromInternet(var imageView: ImageView) : AsyncTask<String, Void, Bitmap?>() {
        init {
            Toast.makeText(applicationContext, "Please wait, it may take a few minute...",     Toast.LENGTH_SHORT).show()
        }
        override fun doInBackground(vararg urls: String): Bitmap? {
            val imageURL = urls[0]
            var image: Bitmap? = null
            try {
                val `in` = java.net.URL(imageURL).openStream()
                image = BitmapFactory.decodeStream(`in`)
            }
            catch (e: Exception) {
                Log.e("Error Message", e.message.toString())
                e.printStackTrace()
            }
            return image
        }
        override fun onPostExecute(result: Bitmap?) {
            imageView.setImageBitmap(result)
        }
    }
}