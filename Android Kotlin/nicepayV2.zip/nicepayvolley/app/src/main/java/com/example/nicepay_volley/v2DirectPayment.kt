package com.example.nicepay_volley

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

class v2DirectPayment : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_v2_direct_payment)

        val wView = findViewById<WebView>(R.id.wView)
        val method = intent.getStringExtra("method")
        val sts = findViewById<Button>(R.id.status)
        val cancel = findViewById<Button>(R.id.cancel)

        if(method == "05"){
            val buffer = StringBuffer("https://dev.nicepay.co.id/nicepay/direct/v2/payment")
            buffer.append("?timeStamp=" + URLEncoder.encode(intent.getStringExtra("timeStamp")))
            buffer.append("&tXid=" + URLEncoder.encode(intent.getStringExtra("tXid")))
            buffer.append("&merchantToken=" + URLEncoder.encode(intent.getStringExtra("merchantToken")))
            // url page to get status payment
            buffer.append("&callBackUrl=" + URLEncoder.encode("payment://tes"))
            buffer.append("&amt=" + URLEncoder.encode(intent.getStringExtra("amt")))
            Log.e("link", buffer.toString())
            wView.getSettings().setJavaScriptEnabled(true)
            wView.setWebViewClient(WebViewClient())
            wView.loadUrl(buffer.toString())

        }else{
            val buffer = StringBuffer("https://dev.nicepay.co.id/nicepay/direct/v2/payment")
            buffer.append("?timeStamp=" + URLEncoder.encode(intent.getStringExtra("timeStamp")))
            buffer.append("&tXid=" + URLEncoder.encode(intent.getStringExtra("tXid")))
            buffer.append("&merchantToken=" + URLEncoder.encode(intent.getStringExtra("merchantToken")))
            buffer.append("&callBackUrl=" + URLEncoder.encode("payment://tes"))
            buffer.append("&cardExpYymm=" + URLEncoder.encode(intent.getStringExtra("cardExpYymm")))
            buffer.append("&cardCvv=" + URLEncoder.encode(intent.getStringExtra("cardCvv")))
            buffer.append("&cardNo=" + URLEncoder.encode(intent.getStringExtra("cardNo")))
            buffer.append("&cardHolderNm=" + URLEncoder.encode(intent.getStringExtra("cardHolderNm")))
            buffer.append("&amt=" + URLEncoder.encode(intent.getStringExtra("amt")))
            wView.getSettings().setJavaScriptEnabled(true)
            Log.e("link", buffer.toString())
            wView.setWebViewClient(WebViewClient())
            wView.loadUrl(buffer.toString())
        }



        sts.setOnClickListener{
            status()
        }

        cancel.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Cancel Transaction")
            builder.setMessage("Are you sure want to cancel this transaction?")

            builder.setPositiveButton(android.R.string.yes) { dialog, which ->
                cancel(method.toString())
            }

            builder.setNegativeButton(android.R.string.no) { dialog, which ->
                dialog.dismiss()
            }

            builder.setNeutralButton("Maybe") { dialog, which ->
                dialog.dismiss()
            }
            builder.show()

        }
    }

    private fun status() {
        val url : String ="https://dev.nicepay.co.id/nicepay/direct/v2/inquiry"

        val requestQueue = Volley.newRequestQueue(this)

        val postData = JSONObject()
        try {
            postData.put("timeStamp",intent.getStringExtra("timeStamp"))
            postData.put("tXid",intent.getStringExtra("tXid"))
            postData.put("referenceNo",intent.getStringExtra("referenceNo"))
            postData.put("amt",intent.getStringExtra("amt"))
            postData.put("merchantToken",intent.getStringExtra("merchantToken"))
            postData.put("iMid",intent.getStringExtra("iMid"))

            Log.e("iMid", intent.getStringExtra("iMid").toString())
            Log.e("send", postData.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, postData,
            { response ->
                val cd : String? = response.getString("resultCd")
                if(cd == "0000") {
                    val intent = Intent(applicationContext, paymentStatus::class.java)
                    intent.putExtra("type", "statusCheck")
                    intent.putExtra("status", response.getString("status"))
                    startActivity(intent)
                }else{
                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
                }
                Log.e("response", response.toString())
            }
        ) { error -> error.printStackTrace() }

        requestQueue.add(jsonObjectRequest)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun cancel(method : String) {
        val cancel = Intent(this, cancelOption::class.java)
        cancel.putExtra("iMid",intent.getStringExtra("iMid"))
        cancel.putExtra("tXid",intent.getStringExtra("tXid"))
        cancel.putExtra("amt",intent.getStringExtra("amt"))
        cancel.putExtra("key",intent.getStringExtra("key"))
        cancel.putExtra("method",method)
        cancel.putExtra("version","3")
        startActivity(cancel)
//        val url : String ="https://dev.nicepay.co.id/nicepay/direct/v2/cancel"
//
//        val requestQueue = Volley.newRequestQueue(this)
//
//        val date = getCurrentDateTime()
//        val dateTime = date.toString("yyyyMMddHHmmss")
//
//        val postData = JSONObject()
//        try {
//            postData.put("timeStamp",dateTime)
//            postData.put("tXid",intent.getStringExtra("tXid"))
//            postData.put("preauthToken","")
//            postData.put("amt",intent.getStringExtra("amt"))
//            postData.put("merchantToken",hashString(dateTime+intent.getStringExtra("iMid")+intent.getStringExtra("tXid")+intent.getStringExtra("amt")+intent.getStringExtra("key")))
//            postData.put("iMid",intent.getStringExtra("iMid"))
//            postData.put("payMethod",method)
//            postData.put("cancelType","1")
//            postData.put("cancelMsg","Request Cancel")
//            postData.put("cancelServerIp","")
//            postData.put("cancelUserId","")
//            postData.put("cancelUserIp","")
//            postData.put("cancelUserInfo","")
//            postData.put("cancelRetryCnt","")
//            postData.put("worker","")
//
//            Log.e("iMid", intent.getStringExtra("dateTime").toString())
//            Log.e("send", postData.toString())
//        } catch (e: JSONException) {
//            e.printStackTrace()
//        }
//
//        val jsonObjectRequest = JsonObjectRequest(
//            Request.Method.POST, url, postData,
//            { response ->
//                val cd : String? = response.getString("resultCd")
//                if(cd == "0000") {
//                    val intent = Intent(applicationContext, paymentStatus::class.java)
//                    intent.putExtra("type", "cancel")
//                    intent.putExtra("resultMsg", response.getString("resultMsg"))
//                    startActivity(intent)
//                }else{
//                    Toast.makeText(applicationContext, cd + " Order Regist Error", Toast.LENGTH_LONG).show()
//                }
//                Log.e("response", response.toString())
//            }
//        ) { error -> error.printStackTrace() }
//
//        requestQueue.add(jsonObjectRequest)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun hashString(input: String): String {
        val HEX_CHARS = "0123456789abcdef"
        val bytes = MessageDigest
            .getInstance("SHA-256")
            .digest(input.toByteArray())
        val result = StringBuilder(bytes.size * 2)

        bytes.forEach {
            val i = it.toInt()
            result.append(HEX_CHARS[i shr 4 and 0x0f])
            result.append(HEX_CHARS[i and 0x0f])
        }

        return result.toString()
    }

    fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {
        val formatter = SimpleDateFormat(format, locale)
        return formatter.format(this)
    }

    fun getCurrentDateTime(): Date {
        return Calendar.getInstance().time
    }
}