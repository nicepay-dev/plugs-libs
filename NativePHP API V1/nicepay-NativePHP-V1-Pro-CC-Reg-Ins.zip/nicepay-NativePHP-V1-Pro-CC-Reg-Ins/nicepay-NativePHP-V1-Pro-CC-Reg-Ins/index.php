<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="author" content="Yohanes Darmawan Hariyanto">
  <title>NICEPAY - Secure Checkout</title>
  <link rel='stylesheet' href='index.css' type='text/css'/>
  <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
</head>

<body>

  <!-- NAVIGATION PANE -->
  <div class="nav">
    <input class="tablinks" type="button" onclick="openCity(event, 'payMethod-form')" id="payMethod-btn" value="Credit Card" />
    <input class="tablinks" type="button" onclick="openCity(event, 'check-form')" id="check-btn" value="Check Payment" />
    <input class="tablinks" type="button" onclick="openCity(event, 'cancel-form')" id="cancel-btn" value="Cancel Payment" />
  </div>
  
  <!-- FORM CHECKOUT PAYMENT METHOD -->
  <div id="payMethod-form" class="form-style-8">
    <h2><img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">Credit Card V1 Redirect</h2>
    <form action="checkout.php" method="post">
      <input type="hidden" name="payMethod" value="01">

      <div class="group">      
        <input type="text" name="referenceNo"  value="<?= uniqid('NCPAY-', true) ?>"/>
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Reference Number</label>
      </div>

      <div class="group">      
        <input type="number" min="1" name="amt" value="15000" />
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Amount</label>
      </div>

      <div class="group"> 
        <select name="instmntMon">
          <option value="1">1</option>
          <option value="3">3</option>
          <option value="6">6</option>
          <option value="9">9</option>
          <option value="12">12</option>
        </select>     
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Installment Month</label>
      </div>

      <div class="group">   
        <select name="instmntType">
          <option value="1">1</option>
          <option value="2">2</option>
        </select>   
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Installment Type</label>
      </div>

      <input type="submit" value="checkout" />
    </form>
  </div>

  <!-- FORM CHECK PAYMENT -->
  <div id="check-form" class="form-style-8">
    <h2><img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">Check Payment V1</h2>
    <form action="checkPayment.php" method="post">
      <input type="hidden" name="payMethod" value="01">

      <div class="group">      
        <input type="text" name="tXid"/>
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Transaction ID</label>
      </div>

      <div class="group">      
        <input type="text" name="referenceNo" value="99999" />
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Reference Number</label>
      </div>

      <div class="group">      
        <input type="number" min="1" name="amt" value="15000" />
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Amount</label>
      </div> 

      <input type="submit" value="check Payment" />
    </form>
  </div>

  <!-- FORM CANCEL -->
  <div id="cancel-form" class="form-style-8">
    <h2><img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">Cancel V1</h2>
    <form action="cancel.php" method="post">
      <input type="hidden" name="payMethod" value="01">

      <div class="group">      
        <input type="text" name="tXid"/>
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Transaction ID</label>
      </div>

      <div class="group">      
        <input type="number" min="1" name="amt" value="15000" />
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Amount</label>
      </div>  

      <input type="radio" name="cancelType" value="1" checked>Full Cancellation
      <input type="radio" name="cancelType" value="2">Partial Cancellation
      <br >

      <input style="margin-top:5% !important;" type="submit" value="cancel Transaction" />
    </form>
  </div>

  <script type="text/javascript" src="http://code.jquery.com/jquery-1.5.1.min.js?ver=3.5"></script>
  <script type="text/javascript" src="index.js"></script>

</body>
</html>