<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="author" content="Yohanes Darmawan Hariyanto">
    <title>ERROR PAGE</title>
    <link rel='stylesheet' href='index.css' type='text/css'/>
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>

    <div class="form-style-8" style="margin-top:5%;">
        <h2><img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">ERROR PAGE</h2>
        <form action="index.php" method="get">

            <?= $_GET['msg'] ?>
            <br>
                               
            <input style="margin-top:5% !important;" type="submit" value="Back To Checkout" formaction= />
        </form>
    </div>
</body>
</html>
