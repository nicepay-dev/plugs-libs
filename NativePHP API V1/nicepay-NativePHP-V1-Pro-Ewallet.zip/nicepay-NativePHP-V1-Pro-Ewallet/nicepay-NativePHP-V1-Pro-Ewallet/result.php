<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="author" content="Yohanes Darmawan Hariyanto">
    <title>Your order is being process...</title>
    <link rel='stylesheet' href='index.css' type='text/css'/>
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>

    <div class="form-style-8" style="margin-top:5%;">
        <h2><img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">Thank You and Have a nice pay</h2>
        <form action="checkPayment.php" method="post">

            <input type="hidden" name="checkPayment" value="checkPayment">

            <input type="text" name="tXid" value="<?= $_REQUEST['tXid'] ?>">
            <input type="hidden" name="iMid" value="<?= $_SESSION['iMid'] ?>">            
            <input type="hidden" name="merchantKey" value="<?= $_SESSION['merchantKey'] ?>">            
            <input type="text" name="amt" value="<?= $_REQUEST['amount'] ?>">
            <input type="text" name="referenceNo" value="<?= $_REQUEST['referenceNo'] ?>">

            <input type="submit" value="check Payment"/>
            <input type="submit" value="Back To Checkout" formaction="index.php" />
        </form>
    </div>
</body>
</html>
