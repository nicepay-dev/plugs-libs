<?php
session_start();
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 * Please do not modify this module.
 * This module may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 09.03.2016
 *
 * 09.03.2016 Update Log
 * Please contact it.support@ionpay.net for inquiry
 *
 * ____________________________________________________________
 */
// Include the Nicepay class
// Check Payment Status
include_once('lib/NicepayLib.php');

$nicepay = new NicepayLib();

if(!empty($_POST['tXid']) && !empty($_POST['tXid'])){

    // Populate Mandatory parameters to send
    $nicepay->set('tXid', $_POST['tXid']);
    $nicepay->set('iMid', $_POST['iMid']);
    $nicepay->set('merchantKey', $_POST['merchantKey']);
    $nicepay->set('amt', $_POST['amt']);
    $nicepay->set('referenceNo', $_POST['referenceNo']);
    
    // <REQUEST to NICEPAY>
    $response = $nicepay->checkPaymentStatus();

    // <RESPONSE from NICEPAY>
    if (isset($response->resultCd) && $response->resultCd == "0000") {
        //header('Location: paymentStatus.php');
        header("Location: checkPaymentResult.php?tXid=".$response->tXid."&reqDt=".$response->reqDt."&reqTm=".$response->reqTm."&transDt=".$response->transDt."&transTm=".$response->transTm."&resultMsg=".$response->resultMsg."&amt=".$response->amt."");
            //  please save tXid in your database
            // echo "<pre>";
            // echo "tXid              : ".$response->tXid."\n";
            // // echo "API Type          : $response->apiType\n";

            // echo "Request Date      : ".$response->reqDt."\n";
            // echo "Request Time      : ".$response->reqTm."\n";
            // echo "Transaction Date  : ".$response->transDt."\n";
            // echo "result message    : ".$response->resultMsg."\n";
            // echo "</pre>";
    } elseif(isset($response->resultCd)) {
         // API data not correct or error happened in bank system, you can redirect back to checkout page or echo error message.
         // In this sample, we echo error message
         // header("Location: "."http://example.com/checkout.php");
        header("Location: checkPaymentResultError.php?resultCd=".$response->resultCd."&resultMsg=".$response->resultMsg."");

        // echo "<pre>";
        // echo "result code       : ".$response->resultCd."\n";
        // echo "result message    : ".$response->resultMsg."\n";
        // echo "requestUrl        : ".$response->data->requestURL."\n";
        // echo "</pre>";
    } else {
        // Timeout, you can redirect back to checkout page or echo error message.
        // In this sample, we echo error message
        // header("Location: "."http://example.com/checkout.php");
        // echo "<pre>Connection Timeout. Please Try again.</pre>";
        header("Location: otherErrorPage.php?msg=Connection Timeout. Please Try again.");

    }
    // echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
    // echo "<pre>";
    // var_dump($response);
    // echo "</pre>";

} else {
    header("Location: otherErrorPage.php?msg=Please Set Amount, ReferenceNo and tXid.");
    // echo "Please set amount, referenceNo and tXid";
}

