<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="author" content="Yohanes Darmawan Hariyanto">
    <title>CANCELLATION RESULT</title>
    <link rel='stylesheet' href='index.css' type='text/css'/>
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>

    <div class="form-style-8" style="margin-top:5%;">
        <h2><img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">CANCELLATION RESULT</h2>
        <form action="cancel.php" method="post">

            <div class="group">
                <input type="text" name="tXid" value="<?= $_GET['canceltXid'] ?>">   
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction ID</label>         
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="<?=$_GET['resultMsg'] ?>">            
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Status Cancel</label>           
            </div>
            
            <div class="group">
                <input type="text" name="canceltXid" value="<?= $_GET['tXid'] ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Cancel Transaction ID</label>           
            </div>

            <div class="group">
                <input type="text" name="amt" value="<?= $_GET['amt'] ?>">            
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Amount</label>           
            </div>
            
            <div class="group">
                <input type="text" name="transDt" value="<?= $_GET['transDt'] ?>">            
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction Date</label>           
            </div>

            <div class="group">
                <input type="text" name="transTm" value="<?= $_GET['transTm'] ?>">            
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction Time</label>           
            </div>
        </form>
        <form action="index.php" method="get"><input type="submit" value="Back To Checkout" formaction="index.php" /></form>
    </div>
</body>
</html>
