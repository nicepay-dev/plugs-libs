<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="author" content="Yohanes Darmawan Hariyanto">
    <title>PAYMENT STATUS</title>
    <link rel='stylesheet' href='index.css' type='text/css'/>
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>

    <div class="form-style-8" style="margin-top:5%;">
        <h2><img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">PAYMENT STATUS ERROR</h2>
        <form action="/" method="get">

            <div class="group">
                <input type="text" name="tXid" value="<?= $_GET['tXid'] ?>">   
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction ID</label>         
            </div>

            <div class="group">
                <input type="text" name="tXid" value="<?= $_GET['resultCd'] ?>">   
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Code</label>         
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="<?=$_GET['resultMsg'] ?>">            
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Message</label>
            </div>
                               
            <input type="submit" value="Back To Checkout" formaction="index.php" />
        </form>
    </div>
</body>
</html>
