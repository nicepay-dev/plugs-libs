<?php
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 * Please do not modify this module.
 * This module may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 09.03.2016
 *
 * 09.03.2016 Update Log
 * Please contact it.support@ionpay.net for inquiry
 *
 * ____________________________________________________________
 */
// Include the Nicepay class
// Cancel Transaction (VA can be canceled only if VA status is not paid)
include_once('lib/NicepayLib.php');

$nicepay = new NicepayLib();
if(!empty($_POST['tXid']) && !empty($_POST['tXid'])){

    $nicepay->set('tXid', $_POST['tXid']);
    $nicepay->set('amt', $_POST['amt']);
    $nicepay->set('payMethod', '03');
    $nicepay->set('cancelType', $_POST['cancelType']);

    // $merchantToken = $nicepay->merchantTokenCancel();

    // $nicepay->set('merchantToken', $merchantToken);
//    echo $nicepay->get('merchantToken');
//    exit();
    // <REQUEST to NICEPAY>
    $response = $nicepay->cancelTrans();

    // <RESPONSE from NICEPAY>
    if (isset($response->resultCd) && $response->resultCd == "0000") {
        //header('Location: checkPaymentResult.php');
        header("Location: cancelResult.php?tXid=".$response->tXid."&canceltXid=".$response->canceltXid."&amt=".$response->amount."&transDt=".$response->transDt."&transTm=".$response->transTm."&resultMsg=".$response->resultMsg."");
            //  please save tXid in your database
            // echo "<pre>";
            // echo "tXid              : ".$response->tXid."\n";
            // // echo "API Type          : $response->apiType\n";

            // echo "Request Date      : ".$response->reqDt."\n";
            // echo "Request Time      : ".$response->reqTm."\n";
            // echo "Transaction Date  : ".$response->transDt."\n";
            // echo "result message    : ".$response->resultMsg."\n";
            // echo "</pre>";
    } elseif(isset($response->resultCd)) {
            // API data not correct or error happened in bank system, you can redirect back to checkout page or echo error message.
            // In this sample, we echo error message
            // header("Location: "."http://example.com/checkout.php");
        header("Location: cancelResultError.php?resultCd=".$response->resultCd."&resultMsg=".$response->resultMsg."&tXid=".$_POST['tXid']."");

        // echo "<pre>";
        // echo "result code       : ".$response->resultCd."\n";
        // echo "result message    : ".$response->resultMsg."\n";
        // echo "requestUrl        : ".$response->data->requestURL."\n";
        // echo "</pre>";
    } else {
            // Timeout, you can redirect back to checkout page or echo error message.
            // In this sample, we echo error message
            // header("Location: "."http://example.com/checkout.php");
        header("Location: otherErrorPage.php?msg=Connection Timeout. Please Try again.");
        // echo "<pre>Connection Timeout. Please Try again.</pre>";
    }
    // echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
    // echo "<pre>";
    // var_dump($response);
    // echo "</pre>";

} else {
    header("Location: otherErrorPage.php?msg=Please Set Amount, ReferenceNo and tXid.");
    // alert("Please Set Amount, ReferenceNo and tXid");
}