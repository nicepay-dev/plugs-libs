<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CI_NicepayChecker{

  protected $CI;

  private $apiUrl = 'https://www.nicepay.co.id/nicepay/api/onePassStatus.do';
  private $timeout_connect = 30;
  private $timeout_read = 25;

  public $iMid = 'IONPAYTEST';
  public $merchantKey = '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==';
  public $referenceNo;
  public $amt;
  public $tXid;
  public $merchantToken;
  public $pushedToken;
  public $merchantTokenC;

  public $requestData = array();
  public $resultData = array();

  function __construct()
  {
      $this->ci =& get_instance();
  }

  public function getUserIP(){
    return $_SERVER['REMOTE_ADDR'];
  }

  public function getMerchantToken(){
    if(!isset($this->iMid)){
      die("Cannot set Merchant Token, please set param iMid using this->nicepaychecker->iMid = iMid values");
    }
    elseif(!isset($this->referenceNo)){
      die("Cannot set Merchant Token, please set param referenceNo using this->nicepaychecker->referenceNo = referenceNo values");
    }
    elseif(!isset($this->amt)){
      die("Cannot set Merchant Token, please set param amt using this->nicepaychecker->amt = amt values");
    }
    elseif(!isset($this->merchantKey)){
      die("Cannot set Merchant Token, please set param merchantKey using this->nicepaychecker->merchantKey = merchantKey values");
    }
    else {
      $merchantToken = hash('sha256', $this->iMid.$this->referenceNo.$this->amt.$this->merchantKey);
      return $merchantToken;
    }
  }

  public function getMerchantTokenC() {
    if(!isset($this->iMid)){
      die("Cannot set Merchant Token, please set param iMid using this->nicepaychecker->iMid = iMid values");
    }
    elseif(!isset($this->tXid)){
      die("Cannot set Merchant Token, please set param referenceNo using this->nicepaychecker->tXid = tXid values");
    }
    elseif(!isset($this->amt)){
      die("Cannot set Merchant Token, please set param amt using this->nicepaychecker->amt = amt values");
    }
    elseif(!isset($this->merchantKey)){
      die("Cannot set Merchant Token, please set param merchantKey using this->nicepaychecker->merchantKey = merchantKey values");
    }
    else {
      $merchantTokenC = hash('sha256', $this->iMid.$this->tXid.$this->amt.$this->merchantKey);
      return $merchantTokenC;
    }
  }

  private function set_param(){
    $this->requestData['iMid'] = $this->iMid;
    $this->requestData['merchantToken'] = $this->merchantToken;
    $this->requestData['tXid'] = $this->tXid;
    $this->requestData['referenceNo'] = $this->referenceNo;
    $this->requestData['amt'] = $this->amt;
    return $this->requestData;
  }

  private function checkParams($requestData){
    foreach ($requestData as $key => $value) {
      if(!isset($this->requestData[$key])){
        die("Undefined mandatory parameter '". $key ."', please set param using this->nicepaychecker->". $key ." = ". $key ." values");
      }
    }
  }

  public function apiRequest(){
    $this->set_param();
    $this->checkParams($this->requestData);
    $postData = '';
    foreach ($this->requestData as $key => $value) {
      $postData .= urlencode($key) . '='.urlencode($value).'&';
    }
    $postData = rtrim($postData, '&');

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $result = curl_exec($ch);
    return $result;
  }

  public function createlog($msg){
		$file = getcwd()."/log_nicepay/".date('Y-m-d').".txt";
		if(file_exists($file)){
			//$current = file_get_contents($file);
			// Append a new person to the file
			//$current .= $msg;
			file_put_contents($file, $msg, FILE_APPEND | LOCK_EX);
		}else{
			$ourFileHandle = fopen($file, 'w') or die("can't open file");
			//$current = file_get_contents($file);
			// Append a new person to the file
			//$current .= $msg;
			file_put_contents($file, $msg, FILE_APPEND | LOCK_EX);
			fclose($ourFileHandle);
		}
	}
}
?>
