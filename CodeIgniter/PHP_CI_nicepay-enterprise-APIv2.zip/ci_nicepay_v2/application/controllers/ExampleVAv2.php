<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleVAv2 extends CI_Controller {


  private $timeout_connect = 30;
  
  //private $no = 0;

  public function __construct(){
    parent::__construct();

  }


  public function index()
  {
    //$tgl = date("Y/m/d H:i:s");
    $apiUrl = 'https://api.nicepay.co.id/nicepay/direct/v2/registration';
    $ch = curl_init($apiUrl);
        //print_r($ch);exit;


    $jsonData = array(
      'timeStamp' => $_POST['timeStamp'],
      'iMid' => $_POST['mid'],
      'payMethod' => '02',
      'referenceNo' => 'invoice897',
      'currency' => 'IDR',
      'amt' => $_POST['amt'],
      'goodsNm' => 'invoice897',
      'billingNm' => 'John Doe',
      'billingPhone' => '02112345678',
      'billingEmail' => 'john@example.com',
      'billingCity' => 'Jakarta Pusat',
      'billingState' => 'DKI Jakarta',
      'billingPostCd' => '10210',
      'billingCountry' => 'Indonesia',
      'dbProcessUrl' => 'http://www.merchant.com/notification',
      'merchantToken' => 'f2fe822f1e5e763f723a53973fddece5cd1f625944c4bed7d0e05a4cb395c164',
      'userIP' => $_SERVER['REMOTE_ADDR'],
      'bankCd' => $_POST['bankcd'],
      'cartData' => '{}'


      );



    $jsonDataEncoded = json_encode($jsonData);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 

    $curl_result = curl_exec($ch);
    $result = json_decode($curl_result);


      if(isset($result->resultCd) && $result->resultCd == "0000"){

      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "VAcct No          :".$result->vacctNo."\n";
      echo "</pre>";
      // "&cardCvv=".$_POST['cardCvv']."&merchantToken=".$jsonData['merchantToken']);
     //header("location:".site_url(welcome/card)."?tXid=".$result->tXid."&amt=".$result->amt);
    }
    elseif (isset($result->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "</pre>";
    }
    else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>Connection Timeout. Please Try again.</pre>";
    }

  }
  // private function generateReference()
  // {
  //   $micro_date = microtime();
  //   $date_array = explode(" ",$micro_date);
  //   $date = date("YmdHis",$date_array[1]);
  //   $date_array[0] = preg_replace('/[^\p{L}\p{N}\s]/u', '', $date_array[0]
  //   return "Ref".$date.$date_array[0].rand(100,999);
  // }


}
