<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CallPaymentPayloan extends CI_Controller {

  // private $apiUrl = 'http://172.16.10.161:8080/nicepay/direct/v2/payment';
  // private $timeout_connect = 30;


  public function __construct(){
    parent::__construct();
  }

  public function index()
  {

    $this->load->view('payloan_redirectpg');
  }
}
