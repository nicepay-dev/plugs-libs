<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExamplePay extends CI_Controller {


  private $timeout_connect = 30;
  
  //private $no = 0;

  public function __construct(){
    parent::__construct();

  }


  public function index()
  {
    //$tgl = date("Y/m/d H:i:s");
    // print_r($_POST);exit;
    $apiUrl = 'https://dev.nicepay.co.id/nicepay/direct/v2/registration';
    $ch = curl_init($apiUrl);
        //print_r($ch);exit;

   // 'cartData' => '{"count": "1","item": [{"img_url": "https://www.lecs.com/image/introduction/img_vmd020101.jpg","goods_name": "Jam Tangan Army - Strap Kulit - Hitam","goods_detail": "jumlah 1","goods_amt": "400"}]}',
   
    $_POST['merchantToken'] = hash('sha256', $_POST['timeStamp'].$_POST['mid'].'invoice897'.'6500000'.$_POST['key']);
// print_r($_POST['merchantToken']);exit;
    $jsonData = array(
      'timeStamp' => $_POST['timeStamp'],
      'iMid' => $_POST['mid'],
      'payMethod' => '06',
      'referenceNo' => 'invoice897',
      'currency' => 'IDR',
      'amt' => '6500000',
      'goodsNm' => 'invoice897',
      'billingNm' => 'John Doe',
      'billingPhone' => '02112345678',
      'billingEmail' => 'john@example.com',
      'billingCity' => 'Jakarta Pusat',
       'billingAddr' => 'Jalan Jenderal Gatot Subroto Kav.57',
      'billingState' => 'DKI Jakarta',
      'billingPostCd' => '10210',
      'billingCountry' => 'Indonesia',
 'deliveryNm' => 'HongGilDong',
 'deliveryPhone' => '62-21-0000-0000',
 'deliveryAddr' => 'Jalan Jenderal Gatot Subroto Kav.57',
 'deliveryCity'=>'Jakarta',
 'deliveryState'=>'DKI Jakarta',
 'deliveryPostCd'=>'12950',
 'deliveryCountry'=>'ID',
  'vat'=>'0',
 'fee'=>'0',
 'notaxAmt'=>'0',
 'description'=>'this is test transaction!!',
      'dbProcessUrl' => 'http://www.merchant.com/notification',
      'merchantToken' => $_POST['merchantToken'],
       'reqDt'=>'20190620',
 'reqTm'=>'160607',
 'reqDomain'=>'merchant.com',
 'reqServerIP'=>'172.29.2.178',
 'reqClientVer'=>'',
 'userSessionID'=>'697D6922C961070967D3BA1BA5699C2C',
 'userAgent'=>'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/60.0.3112.101 Safari/537.36',
 'userLanguage'=>'en-US',
      'userIP' => $_SERVER['REMOTE_ADDR'],
      'mitraCd' => $_POST['mitracd'],
      'cartData' => '{"count":"2","item":[{"goods_id":"BB12345678","goods_detail":"BB12345678","goods_name":"iPhone 5S","goods_amt":"6000000","goods_type":"Smartphone","goods_url":"http://merchant.com/cellphones/iphone5s_64g","goods_quantity":"1","goods_sellers_id":"SEL123","goods_sellers_name":"Sellers 1"},{"goods_id":"AZ14565678","goods_detail":"BB12345678","goods_name":"Hailee Sneakers Blink Silver","goods_amt":"250000","goods_url":"http://merchant.com/fashion/shoes/sneakers-blink-shoes","goods_type":"Sneakers","goods_quantity":"2","goods_sellers_id":"SEL124","goods_sellers_name":"Sellers 2"}]}',
      'sellers' =>'[{"sellersId": "SEL123","sellersNm": "Sellers 1","sellersEmail":"sellers@test.com","sellersAddress": {"sellerNm": "Sellers","sellerLastNm": "1","sellerAddr": "jalan berbangsa 1","sellerCity":"Jakarta Barat","sellerPostCd": "12344","sellerPhone":"08123456789","sellerCountry": "ID"}},{"sellersId":"SEL124","sellersNm": "Sellers 2","sellersEmail":"sellers2@test.com","sellersAddress": {"sellerNm": "Sellers","sellerLastNm": "2","sellerAddr": "jalan berkelok 3","sellerCity":"Jakarta Utara","sellerPostCd": "12222","sellerPhone":"081255556789","sellerCountry": "ID"}}]',
      'instmntType' => '2',
      'instmntMon' => '1'


      );



    $jsonDataEncoded = json_encode($jsonData);
    // print_r($jsonDataEncoded);exit;
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    // print_r($jsonDataEncoded);exit;
    $curl_result = curl_exec($ch);
    $result = json_decode($curl_result);


      if(isset($result->resultCd) && $result->resultCd == "0000"){
           header("location:".site_url(CallPaymentPayloan)."?tXid=".$result->tXid."&timeStamp=".$_POST['timeStamp']."&amt=".$result->amt."&merchantToken=".$jsonData['merchantToken']);

    }
    elseif (isset($result->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "</pre>";
    }
    else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>Connection Timeout. Please Try again.</pre>";
    }

  }
  // private function generateReference()
  // {
  //   $micro_date = microtime();
  //   $date_array = explode(" ",$micro_date);
  //   $date = date("YmdHis",$date_array[1]);
  //   $date_array[0] = preg_replace('/[^\p{L}\p{N}\s]/u', '', $date_array[0]
  //   return "Ref".$date.$date_array[0].rand(100,999);
  // }


}
