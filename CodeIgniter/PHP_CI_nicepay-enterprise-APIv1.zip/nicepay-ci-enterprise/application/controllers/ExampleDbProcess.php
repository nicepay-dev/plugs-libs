<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleDbProcess extends CI_Controller {

  public function __construct(){
    parent::__construct();
  }

	public function index()
	{
    $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Get Nicepay Notification - Data : ".json_encode($_REQUEST)." "."\n");
    $this->nicepaychecker->iMid = "IONPAYTEST";
    $this->nicepaychecker->merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==";
    $this->nicepaychecker->amt = $_REQUEST['amt'];
    $this->nicepaychecker->referenceNo = $_REQUEST['referenceNo'];
    $this->nicepaychecker->merchantToken = $this->nicepaychecker->getMerchantToken();
    $this->nicepaychecker->tXid = $_REQUEST['tXid'];
    $this->nicepaychecker->pushedToken = $_REQUEST['merchantToken'];
    $this->nicepaychecker->merchantTokenC = $this->nicepaychecker->getMerchantTokenC();
    $this->nicepaychecker->apiRequest();
    $jsonresult = $this->nicepaychecker->apiRequest();
    $result = json_decode($jsonresult);

    //Process Response Nicepay
    if($this->nicepaychecker->pushedToken == $this->nicepaychecker->merchantTokenC){
      if(isset($result->bankCd)){
        if($result->status == '0'){
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Transaction Status VA Paid "."\n");
        }elseif ($result->status == '1') {
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Transaction Status VA Reversal "."\n");
        }elseif ($result->status == '3') {
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Transaction Status VA Canceled "."\n");
        }elseif ($result->status == '4') {
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Transaction Status VA Expired "."\n");
        }else {
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Payment Status Unknown "."\n");
        }
      }else {
        if($result->status == '0'){
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Transaction Status CC Success "."\n");
        }elseif ($result->status == '1') {
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Transaction Status CC Void "."\n");
        }elseif ($result->status == '2') {
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Transaction Status CC Refund "."\n");
        }elseif ($result->status == '9') {
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Transaction Status CC Unpaid "."\n");
        }else {
          $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Payment Status Unknown "."\n");
        }
      }
    }else {
      $this->nicepaychecker->createlog(date("Y-m-d H:i:s")." Reference No. ".$this->nicepaychecker->referenceNo." - Token Not Match "."\n");
    }
	}
}
