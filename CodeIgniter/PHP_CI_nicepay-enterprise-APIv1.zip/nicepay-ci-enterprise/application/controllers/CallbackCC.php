<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CallbackCC extends CI_Controller {

  private $apiUrl = 'https://dev.nicepay.co.id/nicepay/api/onePassStatus.do';
  private $timeout_connect = 30;

  public function __construct(){
    parent::__construct();
  }

  public function index()
  {
    $requestData = array();
    $requestData['iMid'] = "IONPAYTEST";
    $requestData['merchantKey'] = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==";
    $requestData['amt'] = $_GET['amount'];
    $requestData['referenceNo'] = $_GET['referenceNo'];
    $requestData['merchantToken'] = hash('sha256', $requestData['iMid'].$requestData['referenceNo'].$requestData['amt'].$requestData['merchantKey']);
    $requestData['tXid'] = $_GET['tXid'];
    $requestData['resultCd'] = $_GET['resultCd'];
    $requestData['resultMsg'] = $_GET['resultMsg'];
    $requestData['authNo'] = $_GET['authNo'];

    $postData = '';
    foreach ($requestData as $key => $value) {
      $postData .= urlencode($key) . '='.urlencode($value).'&';
    }
    $postData = rtrim($postData, '&');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    $curl_result = curl_exec($ch);
    $result = json_decode($curl_result);
    //print_r($result->resultCd);exit;


    //Process Response Nicepay
    if(isset($result->resultCd) && $result->resultCd == '0000'){
      echo "<pre>";
      echo "tXid              : $result->tXid (Save to your database to check status) \n";
      echo "result code       : $result->resultCd\n";
      echo "result message    : $result->resultMsg\n";
      echo "reference no      : $result->referenceNo\n";
      echo "payment method    : $result->payMethod\n";
      echo "currency          : $result->currency\n";
      echo "amt               : $result->amt\n";
      echo "installment month : $result->instmntMon\n";
      echo "status            : $result->status\n";
      echo "</pre>";
    }
    elseif (isset($result->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "</pre>";
    }
    else {
      echo "<pre>";
      echo "Timeout When Checking Payment Status";
      echo "</pre>";
    }
  }
}
