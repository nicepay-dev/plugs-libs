<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ',							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE',		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE',	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE',					'ab');
define('FOPEN_READ_WRITE_CREATE',				'a+b');
define('FOPEN_WRITE_CREATE_STRICT',				'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');


/* End of file constants.php */
/* Location: ./application/config/constants.php */

/*
|--------------------------------------------------------------------------
| This file are additional constants created
|--------------------------------------------------------------------------
|
*/

define("NICEPAY_IMID",                              "IONPAYTEST");
define("NICEPAY_MERCHANT_KEY",                      "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==");
define("NICEPAY_CALLBACK_URL",                      "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp");
define("NICEPAY_DBPROCESS_URL",                     "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp");

define("NICEPAY_REQ_URL",                           "https://dev.nicepay.co.id/nicepay/direct/v2/registration");
define("NICEPAY_PAYMENT_URL",                       "https://dev.nicepay.co.id/nicepay/direct/v2/payment");
define("NICEPAY_CANCEL_URL",     	                "https://dev.nicepay.co.id/nicepay/direct/v2/cancel");
define("NICEPAY_ORDER_STATUS_URL",                  "https://dev.nicepay.co.id/nicepay/direct/v2/inquiry");

/* Virtual Account Fixopen */
define("NICEPAY_REG_URL_FIXOPEN",                   "https://dev.nicepay.co.id/nicepay/api/vacctCustomerRegist.do");
define("NICEPAY_VA_ACCOUNT_URL_FIXOPEN",            "https://dev.nicepay.co.id/nicepay/api/vacctCustomerInquiry.do");
define("NICEPAY_VA_ACCOUNT_DEPOSIT_URL_FIXOPEN",    "https://dev.nicepay.co.id/nicepay/api/vacctCustomerInquiry.do");

define("NICEPAY_CAPTURE_CC_URL",                    "https://dev.nicepay.co.id/nicepay/api/captureTrans.do");

/* JeniusPay Cashtag */
define("NICEPAY_CASHTAG",                           "xxxx"); //Spesial for payment method JeniusPay