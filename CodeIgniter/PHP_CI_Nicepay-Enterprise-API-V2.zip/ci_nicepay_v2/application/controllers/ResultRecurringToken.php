<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultRecurringToken extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library 
      $this->load->library('session');
      //setting data 
      $this->session->set_userdata('recurringToken',$_REQUEST['recurringToken']);

      header("location:".site_url()."welcome/resultRecurringToken"."?tXid=".$_REQUEST['tXid']."&referenceNo=".$_REQUEST['referenceNo']."&amt=".$_REQUEST['amt']."&resultMsg=".$_REQUEST['resultMsg']."&recurringToken=".$_REQUEST['recurringToken']);
    }
}
