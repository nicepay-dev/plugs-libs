<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CancelResult extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
    }

    public function index()
    {
        //loading session library 
        $this->load->library('session');

        header("location:".site_url()."welcome/cancelResult"."?tXid=".$_REQUEST['tXid']."&amt=".
        $_REQUEST['amt']."&transDt=".$_REQUEST['transDt']."&transTm=".$_REQUEST['transTm']."&resultMsg=".$_REQUEST['resultMsg']);
    }
}