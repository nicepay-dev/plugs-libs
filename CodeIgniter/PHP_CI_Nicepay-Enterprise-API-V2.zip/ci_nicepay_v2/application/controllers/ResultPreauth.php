<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultPreauth extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library 
      $this->load->library('session');
      //setting data 
      $this->session->set_userdata('preauthToken',$_REQUEST['preauthToken']);

      if (isset($_REQUEST['resultCd']) && $_REQUEST['resultCd'] == "0000") {
        header("location:".site_url()."welcome/resultPreauth"."?tXid=".$_REQUEST['tXid']."&referenceNo=".$_REQUEST['referenceNo']."&amt=".$_REQUEST['amt']."&resultMsg=".$_REQUEST['resultMsg']."&preauthToken=".$_REQUEST['preauthToken']);
      } elseif (isset($_REQUEST['resultCd'])) {
        header("location:".site_url()."welcome/OtherErrorPage"."?msg=Result: ".$_REQUEST['resultCd'].",".$_REQUEST['resultMsg']);
      } else {
        header("location:".site_url()."welcome/OtherErrorPage"."?msg=Connection Timeout. Please Try again.");
      }

      header("location:".site_url()."welcome/resultPreauth");
    }
}
