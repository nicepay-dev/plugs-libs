<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CheckPaymentResult extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library 
      $this->load->library('session');

      header("location:".site_url()."welcome/checkPaymentResult"."?tXid=".$_REQUEST['tXid']."&reqDt=".$_REQUEST['reqDt']."&reqTm=".$_REQUEST['reqTm'].
      "&transDt=".$_REQUEST['transDt']."&transTm=".$_REQUEST['transTm']."&resultMsg=".$_REQUEST['resultMsg']."&amt=".$_REQUEST['amt']."&referenceNo=".$_REQUEST['referenceNo']);
    }
}
