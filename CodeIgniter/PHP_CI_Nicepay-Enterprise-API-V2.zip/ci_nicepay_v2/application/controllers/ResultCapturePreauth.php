<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultCapturePreauth extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library 
      $this->load->library('session');

      header("location:".site_url()."welcome/resultCapturePreauth"."?tXid=".$_REQUEST['tXid']."&referenceNo=".$_REQUEST['referenceNo']."&resultMsg=".$_REQUEST['resultMsg']."&amt=".$_REQUEST['amt']);
    }
}
