<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class OtherErrorPage extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      header("location:".site_url()."welcome/otherErrorPage"."?msg=Connection Timeout. Please Try again.");
    }
}
