<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultPayloan extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library
      $this->load->library('session');

      header("location:".site_url()."welcome/resultPayloan"."?tXid=".$_REQUEST['tXid']."&referenceNo=".$_REQUEST['referenceNo']."&amt=".$_REQUEST['amt']."&resultMsg=".$_REQUEST['resultMsg']);
    }
}
