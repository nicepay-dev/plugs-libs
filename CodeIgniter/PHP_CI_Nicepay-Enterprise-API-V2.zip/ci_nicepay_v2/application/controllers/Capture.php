<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Capture extends CI_Controller {
    
    private $apiUrl = NICEPAY_CAPTURE_CC_URL;
    private $timeout_connect = 30;

    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $preauthToken = '';
        $iMid = NICEPAY_IMID;
        $merchantKey = NICEPAY_MERCHANT_KEY;

        $requestData = array();
        $requestData['iMid'] = $iMid;
        $requestData['tXid'] = $_POST['tXid'];
        $requestData['payMethod'] = "01";
        $requestData['referenceNo'] = $_POST['referenceNo'];
        $requestData['currency'] = "IDR";
        $requestData['amt'] = $_POST['amt'];
        $requestData['description'] = "Payment of Invoice No ".$_POST['referenceNo'];
        $requestData['merchantKey'] = $merchantKey;
        $requestData['goodsNm'] = "Test Transaction";
        $requestData['billingNm'] = "John Doe";
        $requestData['billingPhone'] = "082111111111";
        $requestData['billingEmail'] = "john@example.com";
        $requestData['billingCity'] = "Jakarta Pusat";
        $requestData['billingState'] = "DKI Jakarta";
        $requestData['billingPostCd'] = "10210";
        $requestData['billingCountry'] = "Indonesia";

        $requestData['deliveryNm'] = "John Doe";
        $requestData['deliveryPhone'] = "02112345678";
        $requestData['deliveryAddr'] = "Jl. Jend. Sudirman No. 28";
        $requestData['deliveryCity'] = "Jakarta Pusat";
        $requestData['deliveryState'] = "DKI Jakarta";
        $requestData['deliveryPostCd'] = "10210";
        $requestData['deliveryCountry'] = "Indonesia";

        $requestData['dbProcessUrl'] = NICEPAY_DBPROCESS_URL;
        $requestData['merchantToken'] = hash('sha256', $iMid.$_POST['referenceNo'].$_POST['amt'].$merchantKey);
        $requestData['instmntType'] = "1";
        $requestData['instmntMon'] = "1";
        $requestData['userIP'] = "127.0.0.1";
        $requestData['cartData'] = "{}";
        $requestData['preauthToken'] = $_POST['preauthToken'];

        $postData = '';
        foreach ($requestData as $key => $value) {
          $postData .= urlencode($key) . '='.urlencode($value).'&';
        }
        $postData = rtrim($postData, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $curl_result = curl_exec($ch);
        $result = json_decode($curl_result, true);
        
        // Process Response Nicepay
        if(isset($result['resultCd']) && $result['resultCd'] == "0000"){
            if(isset($result['amount'])){
                $responseAmt = $result['amount'];
            } else {
                $responseAmt = $result['amount'];
            }
            header("location:".site_url(ResultCapturePreauth)."?tXid=".$result['tXid']."&referenceNo=".$result['referenceNo']."&resultMsg=".$result['resultMsg']."&amt=".$responseAmt);
        } elseif (isset($result['resultCd'])) {
            header("location:".site_url()."welcome/OtherErrorPage"."?msg=Result: ".$result['resultCd'].",".$result['resultMsg']);
        } else {
            header("location:".site_url()."welcome/OtherErrorPage"."?msg=Connection Timeout. Please Try again.");
        }
    }
}