<?php
    class database{
         var $host = "localhost";
         var $username = "root";
         var $pass = "";
         var $db = "pelatihan_september";

        //  function_construt(){
        //      $koneksi = mysql_connect($this->host,$this->username,$->this->pass);
        //      $database = mysql_select_db($this->db);
        //  }

    }