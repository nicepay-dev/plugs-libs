<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultCC extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library 
      $this->load->library('session');

      if (isset($_REQUEST['resultCd']) && $_REQUEST['resultCd'] == "0000") {
        header("location:".site_url()."welcome/resultCC"."?tXid=".$_REQUEST['tXid']."&referenceNo=".$_REQUEST['referenceNo']."&amt=".$_REQUEST['amt']."&resultMsg=".$_REQUEST['resultMsg']);
      } elseif (isset($_REQUEST['resultCd'])) {
        header("location:".site_url()."welcome/OtherErrorPage"."?msg=Result: ".$_REQUEST['resultCd'].",".$_REQUEST['resultMsg']);
      } else {
        header("location:".site_url()."welcome/OtherErrorPage"."?msg=Connection Timeout. Please Try again.");
      }
    
    }
}
