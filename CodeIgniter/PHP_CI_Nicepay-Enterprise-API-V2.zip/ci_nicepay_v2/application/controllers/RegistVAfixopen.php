<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RegistVAfixopen extends CI_Controller {
    
    private $apiUrl = NICEPAY_REG_URL_FIXOPEN;
    private $timeout_connect = 30;

    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $iMid = NICEPAY_IMID;
        $merchantKey = NICEPAY_MERCHANT_KEY;

        $requestData = array();
        $requestData['iMid'] = $_POST['iMid'];
        $requestData['customerId'] = $_POST['customerId'];
        $requestData['customerNm'] = $_POST['customerNm'];
        $requestData['merchantKey'] = NICEPAY_MERCHANT_KEY;
        $requestData['merchantToken'] = hash('sha256', $iMid.$_POST['customerId'].NICEPAY_MERCHANT_KEY);

        $postData = '';
        foreach ($requestData as $key => $value) {
          $postData .= urlencode($key) . '='.urlencode($value).'&';
        }
        $postData = rtrim($postData, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $curl_result = curl_exec($ch);
        $response = json_decode($curl_result);

        $qrUrl = 'resultCd='.$response->resultCd.'&resultMsg='.$response->resultMsg.'&customerId='.$response->customerId.'&customerNm='.$response->customerNm;

        foreach($response->vacctInfoList as $row){
            $bankCd = $row->bankCd;
            $vacctNo = $row->vacctNo;
            $qrUrl .= "&".$bankCd."=".$vacctNo;
        }

        // Response from NICEPAY
        if (isset($response->resultCd) && $response->resultCd == "0000") {
            header("location:".site_url(ResultVAfixopen)."?".$qrUrl);
        } elseif (isset($response->resultCd)) {
            header("location:".site_url()."welcome/OtherErrorPage"."?msg=Result: ".$response->resultCd.",".$response->resultMsg);
        } else {
            header("location:".site_url()."welcome/OtherErrorPage"."?msg=Connection Timeout. Please Try again.");
        }
    }
}