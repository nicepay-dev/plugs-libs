<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultCVS extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library
      $this->load->library('session');

      header("location:".site_url()."welcome/resultCVS"."?tXid=".$_REQUEST['tXid']."&referenceNo=".$_REQUEST['referenceNo']."&payNo=".$_REQUEST['payNo']."&amt=".$_REQUEST['amt']."&description=".$_REQUEST['description']."&billingNm=".$_REQUEST['billingNm']);
    }
}
