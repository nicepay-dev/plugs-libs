<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$this->load->view('index');
	}

	// Credit Card
	public function creditCard()
	{
		$this->load->view('creditCard');
	}

	public function resultCC()
	{
		$this->load->view('resultCC');
	}

	// Virtual Account
	public function virtualAccount()
	{
		$this->load->view('virtualAccount');
	}

	public function resultVA()
	{
		$this->load->view('resultVA');
	}

	// Virtual Account Fixopen
	public function virtualAccountFixopen()
	{
		$this->load->view('virtualAccountFixopen');
	}

	public function resultVAfixopen()
	{
		$this->load->view('resultVAfixopen');
	}

	// Credit Card - Recurring
	public function recurring()
	{
		$this->load->view('recurring');
	}

	public function resultRecurring()
	{
		$this->load->view('resultRecurring');
	}

	public function resultRecurringToken()
	{
		$this->load->view('resultRecurringToken');
	}

	// Credit Card - Capture Preauth
	public function preauth()
	{
		$this->load->view('preauth');
	}

	public function resultPreauth()
	{
		$this->load->view('resultPreauth');
	}

	public function resultCapturePreauth()
	{
		$this->load->view('resultCapturePreauth');
	}

	// Convenience Store (CVS)
	public function convenienceStore()
	{
		$this->load->view('convenienceStore');
	}

	public function resultCVS()
	{
		$this->load->view('resultCVS');
	}

	public function convenienceStoreFix()
	{
		$this->load->view('convenienceStoreFix');
	}

	public function resultCVSfix()
	{
		$this->load->view('resultCVSfix');
	}

	// ClickPay
	public function clickPay()
	{
		$this->load->view('clickPay');
	}

	public function resultClickPay()
	{
		$this->load->view('resultClickPay');
	}

	// Ewallet
	public function ewallet()
	{
		$this->load->view('ewallet');
	}

	public function resultEwallet()
	{
		$this->load->view('resultEwallet');
	}

	// Payloan
	public function payloan()
	{
		$this->load->view('payloan');
	}

	public function resultPayloan()
	{
		$this->load->view('resultPayloan');
	}

	// QRIS
	public function qris()
	{
		$this->load->view('qris');
	}

	public function requestQris()
	{
		$this->load->view('requestQris');
	}

	public function resultQris()
	{
		$this->load->view('resultQris');
	}

	// Check Payment
	public function checkPaymentResult()
	{
		$this->load->view('checkPaymentResult');
	}

	// Cancel Result
	public function cancelResult()
	{
		$this->load->view('cancelResult');
	}

	// Handling Error Page
	public function otherErrorPage()
	{
		$this->load->view('otherErrorPage');
	}

	// Handling Cancel Error Page
	public function cancelResultError()
	{
		$this->load->view('cancelResultError');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */