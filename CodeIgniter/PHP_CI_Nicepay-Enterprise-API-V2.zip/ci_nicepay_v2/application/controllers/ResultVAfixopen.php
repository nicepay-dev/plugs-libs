<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultVAfixopen extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library 
      $this->load->library('session');
      
      header("location:".site_url()."welcome/resultVAfixopen"."?resultCd=".$_REQUEST['resultCd']."&resultMsg=".$_REQUEST['resultMsg']."&customerId=".$_REQUEST['customerId']."&customerNm=".$_REQUEST['customerNm']."&BDIN=".$_REQUEST['BDIN']."&BNIA=".$_REQUEST['BNIA']."&BNIN=".$_REQUEST['BNIN']."&IBBK=".$_REQUEST['IBBK']."&HNBN=".$_REQUEST['HNBN']."&BBBA=".$_REQUEST['BBBA']."&BMRI=".$_REQUEST['BMRI']."&CENA=".$_REQUEST['CENA']."&YUDB=".$_REQUEST['YUDB']);
    }
}
