<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultQRIS extends CI_Controller {

    public function __construct(){
      parent::__construct();
    }

    public function index()
    {
      //loading session library
      $this->load->library('session');

      header("location:".site_url()."welcome/resultQris"."?tXid=".$_REQUEST['tXid']."&referenceNo=".$_REQUEST['referenceNo'].
      "&resultCd=".$_REQUEST['resultCd']."&resultMsg=".$_REQUEST['resultMsg']."&amt=".$_REQUEST['amt']."&description=".$_REQUEST['description'].
      "&billingNm=".$_REQUEST['billingNm']."&paymentExpDt=".$_REQUEST['paymentExpDt']."&paymentExpTm=".$_REQUEST['paymentExpTm'].
      "&qrContent=".$_REQUEST['qrContent']."&qrUrl=".$_REQUEST['qrUrl']."&qrisLogo=".$_REQUEST['qrisLogo']);
    }
}
