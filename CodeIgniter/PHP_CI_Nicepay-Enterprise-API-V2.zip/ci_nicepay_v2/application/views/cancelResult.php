<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <title>Cancellation Result</title>

	<!-- CSS -->
	<link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

	<!-- Images -->
	<link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>
<body>

	<div id="payMethod-form" class="form-style-8">
		<h2><img class="img-valign" style="width: 60px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">Cancellation Result</h2>
        <div class="group">
            <input type="text" name="resultMsg" value="<?=$_GET['resultMsg'] ?>">            
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Status Cancel</label>           
        </div>
        <div class="group">
            <input type="text" name="tXid" value="<?= $_GET['tXid'] ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Transaction ID</label>           
        </div>
        <div class="group">
            <input type="text" name="amt" value="<?= $_GET['amt'] ?>">            
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Amount</label>           
        </div>
        <div class="group">
            <input type="text" name="transDt" value="<?= $_GET['transDt'] ?>">            
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Transaction Date</label>           
        </div>
        <div class="group">
            <input type="text" name="transTm" value="<?= $_GET['transTm'] ?>">            
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Transaction Time</label>           
        </div>

        <a href="<?php echo site_url().'';?>"><input type="button" value="Back To Checkout" /></a>
    </div>

</body>
</html>