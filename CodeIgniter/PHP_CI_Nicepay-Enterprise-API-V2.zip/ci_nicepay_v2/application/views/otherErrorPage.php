<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <title>Error Page</title>

    <!-- CSS -->
	<link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Images -->
    <link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>
<body>

    <div class="form-style-8" style="margin-top:5%;">
        <h2><img class="img-valign" style="width: 60px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">Error Page</h2>
        
        <?= $_GET['msg'] ?>
        <br><br>
        
        <a href="<?php echo site_url().'';?>"><input type="button" value="Back To Checkout" /></a>
    </div>
</body>
</html>
