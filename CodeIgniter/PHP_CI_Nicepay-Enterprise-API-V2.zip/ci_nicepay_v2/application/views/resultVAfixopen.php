<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Riko Adi Setiawan">
    <title>Your order is being process...</title>

	<!-- CSS -->
	<link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

	<!-- Images -->
	<link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>
<body>

	<div id="payMethod-form" class="form-style-8">
		<form action="<?php echo site_url();?>CheckPayment" method="post">
			<h2><img class="img-valign" style="width: 60px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">Thank You and Have a nice pay</h2>
			<div class="group">
				<input type="text" name="" value="<?php echo $_REQUEST['resultCd']; ?>" />
				<span class="highlight"></span>
				<span class="bar"></span>
				<label>Result Code</label>
			</div>

			<div class="group">
				<input type="text" name="" value="<?php echo $_REQUEST['resultMsg']; ?>" />
				<span class="highlight"></span>
				<span class="bar"></span>
				<label>Result Message</label>
			</div>

			<div class="group">
				<input type="text" name="" value="<?php echo $_REQUEST['customerId']; ?>" />
				<span class="highlight"></span>
				<span class="bar"></span>
				<label>Customer ID</label>
			</div>

			<div class="group">
				<input type="text" name="" value="<?php echo $_REQUEST['customerNm']; ?>" />
				<span class="highlight"></span>
				<span class="bar"></span>
				<label>Customer Name</label>
			</div>
			
			<?php if(isset($_REQUEST['BDIN'])){?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['BDIN']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA BANK DANAMON</label>
				</div>
			<?php } ?>
			
			<?php if(isset($_REQUEST['BNIA'])) { ?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['BNIA']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA BANK CIMB NIAGA</label>
				</div>
			<?php } ?>

			<?php if(isset($_REQUEST['BNIN'])) { ?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['BNIN']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA BANK BNI</label>
				</div>
			<?php } ?>

			<?php if(isset($_REQUEST['IBBK'])) { ?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['IBBK']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA BANK MAYBANK</label>
				</div>
			<?php } ?>

			<?php if(isset($_REQUEST['HNBN'])) { ?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['HNBN']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA Bank KEB Hana Indonesia</label>
				</div>
			<?php } ?>

			<?php if(isset($_REQUEST['BBBA'])) { ?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['BBBA']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA BANK PERMATA</label>
				</div>
			<?php } ?>

			<?php if(isset($_REQUEST['BMRI'])) { ?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['BMRI']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA BANK MANDIRI</label>
				</div>
			<?php } ?>

			<?php if(isset($_REQUEST['CENA'])) { ?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['CENA']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA BANK BCA</label>
				</div>
			<?php } ?>

			<?php if(isset($_REQUEST['YUDB'])) { ?>
				<div class="group">
					<input type="text" name="" value="<?php echo $_REQUEST['YUDB']; ?>" />
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>VA BANK BNC</label>
				</div>
			<?php } ?>
			<br>
			<a href="https://template.nicepay.co.id/VA_EN/"><input type="button" value="How to Pay" /></a>
			<br>
			<a href="<?php echo site_url().'welcome/virtualAccountFixopen';?>"><input type="button" value="Back to Checkout" /></a>
		</form>
	</div>

</body>
</html>