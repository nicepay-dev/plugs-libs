<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <title>Payment Status</title>

	<!-- CSS -->
	<link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

	<!-- Images -->
	<link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>
<body>

	<div id="payMethod-form" class="form-style-8">
		<form action="<?php echo site_url();?>Cancel" method="post">
			<h2><img class="img-valign" style="width: 60px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">Payment Status</h2>
			<div class="group">
                <input type="text" name="tXid" value="<?= $_REQUEST['tXid'] ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction ID</label>
            </div>
            <div class="group">
                <input type="text" name="resultMsg" value="<?= $_REQUEST['resultMsg'] ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Result Message</label>
            </div>
            <div class="group">
                <input type="text" name="amt" value="<?= $_REQUEST['amt'] ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Amount</label>
            </div>
            <div class="group">
                <input type="text" name="reqDt" value="<?= $_GET['reqDt'] ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Request Date</label>           
            </div>
            <div class="group">
                <input type="text" name="reqTm" value="<?= $_GET['reqTm'] ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Request Time</label>           
            </div>
            <div class="group">
                <input type="text" name="transDt" value="<?= $_GET['transDt'] ?>">            
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction Date</label>           
            </div>
            <div class="group">
                <input type="text" name="transTm" value="<?= $_GET['transTm'] ?>">            
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction Time</label>           
            </div>
            <div class="group">
                <input type="text" style="text-transform:none" name="referenceNo" value="<?= $_REQUEST['referenceNo'] ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Reference Number</label>
            </div>
            <div class="group">
                <select name="payMethod">
                  <option selected value="01">CC</option>
                  <option value="02">VA</option>
                  <option value="03">CVS</option>
                  <option value="04">ClicPay</option>
                  <option value="05">Ewallet</option>
                  <option value="06">Payloan</option>
                  <option value="08">QRIS</option>
                </select>
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Payment Method</label>
            </div>

            <input type="radio" name="cancelType" value="1" checked>Full Cancellation
            <input type="radio" name="cancelType" value="2">Partial Cancellation
            <input type="hidden" name="iMid" value="<?php echo NICEPAY_IMID;?>">
            <br>
            <br>

			<input type="submit" value="Cancel Transaction"/>
			<a href="<?php echo site_url().'';?>"><input type="button" value="back" /></a>
		</form>
	</div>

</body>
</html>