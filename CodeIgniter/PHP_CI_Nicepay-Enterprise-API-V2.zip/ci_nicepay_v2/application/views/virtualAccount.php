<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <title>Nicepay - Secure Checkout</title>

	<!-- CSS -->
	<link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

	<!-- Images -->
	<link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>

    <body>
        <!-- FORM VIRTUAL ACCOUNT -->
        <div id="payMethod-form" class="form-style-8">
            <h2>
                <img class="img-valign" style="width: 60px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">Virtual Account V2 Direct
            </h2>
            <form action="<?php echo site_url();?>RegistVA" method="post">
                <div class="group">
                    <input type="text" name="iMid" id="iMid" value="<?php echo NICEPAY_IMID;?>"/>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>iMid</label>
                </div>    

                <div class="group">
                    <input type="text" name="referenceNo" id="referenceNo" value="<?php date_default_timezone_set("Asia/Jakarta"); echo(date("YmdHis"));?>" />
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Reference Number</label>
                </div>

                <div class="group">
                    <select name="bankCd">
                    <option selected value="BMRI">Bank Mandiri</option>
                    <option value="IBBK">Maybank</option>
                    <option value="BBBA">Bank Permata</option>
                    <option value="CENA">Bank Central Asia</option>
                    <option value="BNIN">Bank Negara Indonesia 46</option>
                    <option value="HNBN">Bank KEB Hana Indonesia</option>
                    <option value="BRIN">Bank Rakyat Indonesia</option>
                    <option value="BNIA">BANK CIMB NIAGA</option>
                    <option value="BDIN">BANK DANAMON INDONESIA</option>
                    <option value="YUDB">BANK NEO COMMERCE</option>
                    </select>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Bank</label>
                </div>

                <div class="group">      
                    <input type="number" min="1" name="amt" value="10000" />
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Price</label>
                </div>

                <div class="group">      
                    <input type="number" min="1" name="merFixAcctId" value="" placeholder="Khusus VA Fix Close"/>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>merFixAcctId</label>
                </div>

                <div class="group">      
                    <input type="number" min="1" name="vacctValidDt" value="<?=date("Ymd", strtotime(' + 1 days')) ?>" />
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Validation Date</label>
                </div>

                <div class="group">      
                    <input type="number" min="0" name="vacctValidTm" value="235959"/>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Validation Time</label>
                </div>

                <input type="submit" value="checkout" />
                <a href="<?php echo site_url().'';?>"><input type="button" value="back" /></a>
            </form>
        </div>
    </body>
</html>


