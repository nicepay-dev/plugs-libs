<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <title>CANCELLATION STATUS</title>

    <!-- CSS -->
	<link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Images -->
    <link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>
<body>

    <div class="form-style-8" style="margin-top:5%;">
        <h2><img class="img-valign" style="width: 60px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">CANCELLATION ERROR</h2>
        <form action="index.php" method="get">

            <div class="group">
                <input type="text" name="tXid" value="<?= $_GET['tXid'] ?>">   
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction ID</label>         
            </div>

            <div class="group">
                <input type="text" name="tXid" value="<?= $_GET['resultCd'] ?>">   
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Code</label>         
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="<?=$_GET['resultMsg'] ?>">            
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Message</label>           
            </div>
                               
            <a href="<?php echo site_url().'';?>"><input type="button" value="Back To Checkout" /></a>
        </form>
    </div>
</body>
</html>
