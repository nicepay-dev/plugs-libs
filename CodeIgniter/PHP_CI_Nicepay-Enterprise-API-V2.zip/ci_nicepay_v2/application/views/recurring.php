<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <title>Nicepay - Secure Checkout</title>

	<!-- CSS -->
	<link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

	<!-- Images -->
	<link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>
    <body>
        <!-- FORM CREDIT CARD - RECURRING -->
        <div id="payMethod-form" class="form-style-8">
            <h2>
                <img class="img-valign" style="width: 60px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">Recurring Credit Card V2 Direct
            </h2>
            <form action="<?php echo site_url();?>RegistRecurring" method="post">
                <div class="group">
                    <input type="text" name="iMid" id="iMid" value="<?php echo NICEPAY_IMID;?>"/>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>iMid</label>
                </div>    

                <div class="group">
                    <input type="text" name="referenceNo" id="referenceNo" value="<?php date_default_timezone_set("Asia/Jakarta"); echo(date("YmdHis"));?>" />
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Reference Number</label>
                </div>

                <div class="group">
                    <input type="number" min="1" name="amt" value="15000" />
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Price</label>
                </div>

                <div class="group">
                    <select name="instmntMon">
                        <option value="1">Full Payment</option>
                        <option value="3">3 Months</option>
                        <option value="6" disabled>6 Months</option>
                        <option value="9" disabled>9 Months</option>
                        <option value="12" disabled>12 Months</option>
                    </select>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Installment</label>
                </div>

                <div class="group">
                    <select name="instmntType">
                        <option value="1" disabled>Customer Charge</option>
                        <option value="2" selected>Merchant Charge</option>
                    </select>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Installment Type</label>
                </div>

                <input type="submit" value="checkout" />
                <a href="<?php echo site_url().'';?>"><input type="button" value="back" /></a>
            </form>
        </div>
    </body>
</html>


