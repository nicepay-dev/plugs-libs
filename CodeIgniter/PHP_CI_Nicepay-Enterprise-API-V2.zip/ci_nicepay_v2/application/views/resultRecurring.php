<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Riko Adi Setiawan">
    <title>Result Credit Card Recurring</title>

	<!-- CSS -->
	<link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

	<!-- Images -->
	<link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>
<body>

	<div id="payMethod-form" class="form-style-8">
		<form action="<?php echo site_url();?>RegistRecurringToken" method="post">
			<h2><img class="img-valign" style="width: 60px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">Result Credit Card Recurring</h2>
			<div class="group">
				<input type="text" name="" value="<?php echo $_REQUEST['tXid']; ?>" />
				<span class="highlight"></span>
				<span class="bar"></span>
				<label>Transaction ID</label>
			</div>

			<div class="group">
				<input type="text" style="text-transform: none;" name="" value="<?php echo $_REQUEST['referenceNo']; ?>" />
				<span class="highlight"></span>
				<span class="bar"></span>
				<label>Reference Number</label>
			</div>

			<div class="group">
				<input type="number" name="amt" value="<?php echo $_REQUEST['amt']; ?>" />
				<span class="highlight"></span>
				<span class="bar"></span>
				<label>Amount</label>
			</div>

			<?php if($_REQUEST['recurringToken'] == '' || $_REQUEST['recurringToken'] == null) {?>
				<div class="group" style="display: none;">
					<input type="text" style="text-transform:none" name="" value="">
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>Recurring Token</label>
				</div>
			<?php } else { ?>
				<div class="group">
					<input type="text" style="text-transform:none" name="recurringToken" value="<?= $_REQUEST['recurringToken'] ?>">
					<span class="highlight"></span>
					<span class="bar"></span>
					<label>Recurring Token</label>
				</div>
			<?php } ?>

			<div class="group">
                <input type="text" name="" value="<?= $_REQUEST['resultMsg'] ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Result Message</label>
            </div>
			
			<?php if($_REQUEST['recurringToken'] != '' || $_REQUEST['recurringToken'] != null) {?>
				<input type="submit" value="Regist Recurring Token"/><br>
			<?php } ?>
			<a href="<?php echo site_url().'welcome/recurring';?>"><input type="button" value="Back to Checkout" /></a>
		</form>
	</div>

</body>
</html>