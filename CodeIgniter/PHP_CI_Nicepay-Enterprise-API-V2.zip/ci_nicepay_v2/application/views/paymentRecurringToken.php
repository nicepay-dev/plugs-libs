<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" xmlns:v-on="http://www.w3.org/1999/xhtml" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
    <meta name="author" content="Riko Adi Setiawan">
    <title>NICEPAY - Secure Checkout</title>
    <!--<link rel='stylesheet' href='index.css' type='text/css'/>-->
    <link rel='stylesheet' href='http://localhost/ci_nicepay_v2/css/ccform.css' type='text/css'/>
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

    <!-- Images -->
	<link rel="shortcut icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
    <link rel="icon" href="<?php echo site_url();?>image/favicon.ico" type="image/x-icon" />
</head>

<body>

<!-- FORM CHECKOUT PAYMENT METHOD -->
<div id="payMethod-form" class="form-style-8">
    <a class="title-bar" href="index.php"><h2 style="text-align: center"><img class="img-valign" style="width: 75px; height:auto" src="<?php echo site_url();?>image/nicepay_logo.jpg" alt="">Credit Card Recurring V2 Direct</h2></a>
    <form action="<?php echo NICEPAY_PAYMENT_URL;?>" method="post">
        <input type="hidden" name="payMethod" value="01">
        <!--START FORM-->
        <div class="wrapper" id="app">
            <div class="card-form">
                <div class="card-form__inner" style="padding-top: 50px;">
                    <div class="card-form__row">
                        <div class="card-form__col">
                            <div class="card-input">
                                <label class="card-input__label">Payment Ref. No</label>
                                <input readonly type="text" class="card-input__input" autocomplete="off" value="<?= $_REQUEST['referenceNo'] ?>"/>
                            </div>
                        </div>
                        <div class="card-form__col">
                            <div class="card-input">
                                <label class="card-input__label">Transaction ID</label>
                                <input readonly type="text" class="card-input__input" value="<?= $_REQUEST['tXid'] ?>" name="tXid"/>
                                <input type="hidden" name="timeStamp" value="<?= $_REQUEST['timeStamp'] ?>" />
                                <input type="hidden" name="callBackUrl" value="<?= $_REQUEST['callBackUrl'] ?>" />
                                <input type="hidden" name="merchantToken" value="<?= $_REQUEST['merchantToken'] ?>" />
                            </div>
                        </div>
                    </div>
                    <div class="card-form__row">
                        <div class="card-form__col">
                            <div class="card-input">
                                <label class="card-input__label">Price</label>
                                <input readonly type="number" min="5" class="card-input__input" autocomplete="off" value="<?= $_REQUEST['amt'] ?>" name="amt"/>
                            </div>
                        </div>
                    </div>
                    <div class="card-form__row">
                        <div class="card-form__col">
                            <div class="card-input">
                                <label class="card-input__label">Recurring Token</label>
                                <input readonly type="text" class="card-input__input" autocomplete="off" value="<?= $_REQUEST['recurringToken'] ?>" name="recurringToken"/>
                            </div>
                        </div>
                    </div>
                    <!-- OPTIONAL UNTUK SETTINGAN PRODUCTION -->
                    <div class="card-form__row" style="display-none;">
                        <div class="card-form__col">
                            <div class="card-input">
                                <label class="card-input__label">CVV</label>
                                <input type="text" class="card-input__input" id="cardCvv" maxlength="4" value="" name="cardCvv" placeholder="123"/>
                                <span style="color: red;">*note "cvv code does not need to be sent if testing in development"</span>
                            </div>
                        </div>
                    </div>
                    <!-- OPTIONAL UNTUK SETTINGAN PRODUCTION -->
                        
                    <button class="card-form__button">Submit</button>
                </div>
            </div>
        </div>
    </form>
</div>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.5.1.min.js?ver=3.5"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.6.10/vue.min.js"></script>
<script type="text/javascript" src="https://unpkg.com/vue-the-mask@0.11.1/dist/vue-the-mask.js"></script>
<script type="text/javascript" src="http://localhost/ci_nicepay_v2/js/ccform.js"></script>

</body>
</html>