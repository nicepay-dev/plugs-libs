import json
from pydoc import doc
import random

from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.payMethod = "00"
NICEPay.currency = "IDR"
NICEPay.amt = "15000"
NICEPay.referenceNo = "Python20220622"
NICEPay.callBackUrl = "https://dev.nicepay.co.id/IONPAY_CLIENT/paymentResult.jsp"
NICEPay.goodsNm = "Test Transaction Nicepay"
NICEPay.billingNm = "Dobleh"
NICEPay.billingPhone = "12345678"
NICEPay.billingEmail = "email@merchant.com"
NICEPay.billingAddr = "Jalan Bukit Berbunga 22"
NICEPay.billingCity = "Jakarta"
NICEPay.billingState = "DKI Jakarta"
NICEPay.billingPostCd = "12345"
NICEPay.billingCountry = "Indonesia"
NICEPay.deliveryNm = "email@merchant.com"
NICEPay.deliveryPhone = "12345678"
NICEPay.deliveryAddr = "Jalan Bukit Berbunga 22"
NICEPay.deliveryCity = "Jakarta"
NICEPay.deliveryState = "DKI Jakarta"
NICEPay.deliveryPostCd = "12345"
NICEPay.deliveryCountry = "Indonesia"
NICEPay.dbProcessUrl = "http://ptsv2.com/t/alfred/post"
NICEPay.vat = ""
NICEPay.fee = ""
NICEPay.notaxAmt = ""
NICEPay.description = ""
NICEPay.reqDt = ""
NICEPay.reqTm = ""
NICEPay.reqDomain = "merchant.com"
NICEPay.reqServerIP = "127.0.0.1"
NICEPay.reqClientVer = ""
NICEPay.userIP = "127.0.0.1"
NICEPay.userSessionID = "697D6922C961070967D3BA1BA5699C2C"
NICEPay.userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/60.0.3112.101 Safari/537.36"
NICEPay.userLanguage = "ko-KR,en-US;q=0.8,ko;q=0.6,en;q=0.4"
NICEPay.cartData = "{\"count\":\"1\",\"item\":[{\"goods_id\":\"BB12345678\",\"goods_detail\":\"BB12345678\",\"goods_name\":\"Pasar Modern\",\"goods_amt\":\"15000\",\"goods_type\":\"Sembako\",\"goods_url\":\"http:\/\/merchant.com\/cellphones\/iphone5s_64g\",\"goods_quantity\":\"1\",\"goods_sellers_id\":\"SEL123\",\"goods_sellers_name\":\"Sellers 1\"}]}"
NICEPay.sellers = "[{\"sellersId\": \"SEL123\",\"sellersNm\": \"Sellers 1\",\"sellersEmail\":\"sellers@test.com\",\"sellersAddress\": {\"sellerNm\": \"Sellers\",\"sellerLastNm\": \"1\",\"sellerAddr\": \"jalan berbangsa 1\",\"sellerCity\":\"Jakarta Barat\",\"sellerPostCd\": \"12344\",\"sellerPhone\":\"08123456789\",\"sellerCountry\": \"ID\"}}]"
NICEPay.instmntType = "2"
NICEPay.instmntMon = "1"
NICEPay.recurrOpt = "0"
NICEPay.vacctValidDt = ""
NICEPay.vacctValidTm = ""
NICEPay.merFixAcctId = ""
NICEPay.mitraCd = ""
NICEPay.msId = ""
NICEPay.msFee = ""
NICEPay.msFeeType = ""
NICEPay.escrowCl = ""
NICEPay.shopId = ""
NICEPay.bankCd = ""

resultData = NICEPay.apiRequest()
result = json.loads(resultData)

params_list = ['resultCd', 'resultMsg', 'tXid', 'referenceNo', 'payMethod', 'amt', 'transDt', 'transTm'
    , 'description', 'currency', 'goodsNm', 'billingNm', 'payValidDt', 'payValidTm', 'paymentURL']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue