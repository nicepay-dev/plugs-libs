import json
from pydoc import doc
import random

from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.tXid = "IONPAYTEST00202207011059336370"
# payment method that can be canceled is 01 (CC), 05 (e-Wallet), 06 (payLoan)
NICEPay.payMethod = "01"
NICEPay.amt = "15000"

resultData = NICEPay.cancel()
result = json.loads(resultData)
params_list = ['tXid', 'resultCd', 'resultMsg']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue