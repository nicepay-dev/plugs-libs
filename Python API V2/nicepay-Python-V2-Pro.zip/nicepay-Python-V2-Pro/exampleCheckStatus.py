import json
from pydoc import doc
import random

from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.tXid = "IONPAYTEST00202207011059336370"
NICEPay.referenceNo = "Python20220622"
NICEPay.amt = "15000"

resultData = NICEPay.checkStatus()
result = json.loads(resultData)
params_list = ['tXid', 'iMid', 'currency', 'amt', 'instmntMon', 'instmntType', 'referenceNo', 'goodsNm', 'payMethod', 'billingNm', 'reqDt'
    ,'reqTm', 'status', 'resultCd', 'resultMsg', 'cardNo', 'preauthToken', 'acquBankCd', 'issuBankCd', 'vacctValidDt', 'vacctValidTm'
    ,'vacctNo', 'bankCd', 'payNo', 'mitraCd', 'receiptCode', 'cancelAmt', 'transDt', 'transTm', 'recurringToken', 'ccTransType'
    ,'payValidDt', 'payValidTm', 'mRefNo', 'acquStatus', 'acquStatus', 'cardExpYymm', 'acquBankNm', 'issuBankNm', 'depositDt'
    ,'depositTm', 'paymentExpDt', 'paymentExpTm', 'paymentTrxSn', 'cancelTrxSn', 'userId', 'shopId']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue