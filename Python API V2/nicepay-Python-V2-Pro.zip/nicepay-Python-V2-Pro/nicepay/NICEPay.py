import socket
import hashlib
from sqlite3 import Timestamp
import sys
import urllib.parse as urlparse
import http.client as httplib
import urllib
import calendar
import time
from datetime import datetime
import json

# Declare Mandatory Parameters
global iMid
global merchantKey
global payMethod
global amt
global referenceNo
global goodsNm
global billingNm
global billingPhone
global billingEmail
global billingAddr
global billingCity
global billingState
global billingPostCd
global billingCountry
global callBackUrl
global dbProcessUrl
global description
global merchantToken
global userIP
global cartData
global instmntType
global instmntMon
global bankCd
global tXid
global cancelType
global vacctNo
global startDt
global endDt
global customerId
global vacctValidDt
global vacctValidTm
global merFixAcctId
global mitraCd
global msId
global msFee
global msFeeType
global escrowCl
global shopId
global recurrOpt
global sellers
global userSessionID
global userAgent
global userLanguage
global reqDt
global reqTm
global reqDomain
global reqServerIP
global reqClientVer
global vat
global fee
global notaxAmt
global deliveryNm
global deliveryPhone
global deliveryAddr
global deliveryCity
global deliveryState
global deliveryPostCd
global deliveryCountry

dt = datetime.now()
ts = datetime.timestamp(dt)
date_time = datetime.fromtimestamp(ts)
datetimes = date_time.strftime("%Y%m%d%H%M%S")

currency = "IDR"
timeout_connect = 30
requestData = {}
resultData = {}

def getUserIp():
    return socket.gethostbyname(socket.gethostname())

def getMerchantToken():
    if not datetimes:
        sys.exit("Cannot set Merchant Token, please set param timestamp using NICEPay.timestamp = timestamp values")
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using NICEPay.iMid = iMid values")
    elif not referenceNo:
        sys.exit("Cannot set Merchant Token, please set param referenceNo using NICEPay.referenceNo = referenceNo values")
    elif not amt:
        sys.exit("Cannot set Merchant Token, please set param amt using NICEPay.amt = amt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using NICEPay.merchantKey = merchantKey values")
    else:
        mercToken = datetimes + iMid + referenceNo + amt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def getMerchantTokenCancel():
    if not datetimes:
        sys.exit("Cannot set Merchant Token, please set param timestamp using NICEPay.timestamp = timestamp values")
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using NICEPay.iMid = iMid values")
    elif not tXid:
        sys.exit("Cannot set Merchant Token, please set param referenceNo using NICEPay.tXid = tXid values")
    elif not amt:
        sys.exit("Cannot set Merchant Token, please set param amt using NICEPay.amt = amt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using NICEPay.merchantKey = merchantKey values")
    else:
        mercToken = datetimes + iMid + tXid + amt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def getMerchantTokenVaDeposit():
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using NICEPay.iMid = iMid values")
    elif not vacctNo:
        sys.exit("Cannot set Merchant Token, please set param vacctNo using NICEPay.vacctNo = vacctNo values")
    elif not startDt:
        sys.exit("Cannot set Merchant Token, please set param amt using NICEPay.startDt = startDt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using NICEPay.merchantKey = merchantKey values")
    else:
        mercToken = iMid + vacctNo + startDt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def getMerchantTokenCustDeposit():
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using NICEPay.iMid = iMid values")
    elif not customerId:
        sys.exit("Cannot set Merchant Token, please set param customerId using NICEPay.customerId = customerId values")
    elif not startDt:
        sys.exit("Cannot set Merchant Token, please set param amt using NICEPay.startDt = startDt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using NICEPay.merchantKey = merchantKey values")
    else:
        mercToken = iMid + customerId + startDt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def setParams():
    requestData["timeStamp"] = datetimes
    requestData["iMid"] = iMid
    requestData["payMethod"] = payMethod
    requestData["currency"] = currency
    requestData["amt"] = amt
    requestData["referenceNo"] = referenceNo
    requestData["callBackUrl"] = callBackUrl
    requestData["goodsNm"] = goodsNm
    requestData["billingNm"] = billingNm
    requestData["billingPhone"] = billingPhone
    requestData["billingEmail"] = billingEmail
    requestData["billingAddr"] = billingAddr
    requestData["billingCity"] = billingCity
    requestData["billingState"] = billingState
    requestData["billingPostCd"] = billingPostCd
    requestData["billingCountry"] = billingCountry
    requestData["deliveryNm"] = deliveryNm
    requestData["deliveryPhone"] = deliveryPhone
    requestData["deliveryAddr"] = deliveryAddr
    requestData["deliveryCity"] = deliveryCity
    requestData["deliveryState"] = deliveryState
    requestData["deliveryPostCd"] = deliveryPostCd
    requestData["deliveryCountry"] = deliveryCountry
    requestData["dbProcessUrl"] = dbProcessUrl
    requestData["vat"] = vat
    requestData["fee"] = fee
    requestData["notaxAmt"] = notaxAmt
    requestData["description"] = description
    requestData["merchantToken"] = getMerchantToken()
    requestData["reqDt"] = reqDt
    requestData["reqTm"] = reqTm
    requestData["reqDomain"] = reqDomain
    requestData["reqServerIP"] = reqServerIP
    requestData["reqClientVer"] = reqClientVer
    requestData["userIP"] = userIP
    requestData["userSessionID"] = userSessionID
    requestData["userAgent"] = userAgent
    requestData["userLanguage"] = userLanguage
    requestData["cartData"] = cartData
    requestData["sellers"] = sellers
    requestData["instmntType"] = instmntType
    requestData["instmntMon"] = instmntMon
    requestData["recurrOpt"] = recurrOpt
    requestData["bankCd"] = bankCd
    requestData["vacctValidDt"] = vacctValidDt
    requestData["vacctValidTm"] = vacctValidTm
    requestData["merFixAcctId"] = merFixAcctId
    requestData["mitraCd"] = mitraCd
    requestData["msId"] = msId
    requestData["msFee"] = msFee
    requestData["msFeeType"] = msFeeType
    requestData["escrowCl"] = escrowCl
    requestData["shopId"] = shopId

    return requestData

def setParamsCheckStatus():
    requestData["timeStamp"] = datetimes
    requestData['tXid'] = tXid
    requestData['iMid'] = iMid
    requestData['referenceNo'] = referenceNo
    requestData['amt'] = amt
    requestData['merchantToken'] = getMerchantToken()

    return requestData

def setParamsCancel():
    requestData["timeStamp"] = datetimes
    requestData['tXid'] = tXid
    requestData['preauthToken'] = ""
    requestData['payMethod'] = payMethod
    requestData['cancelType'] = "1"
    requestData['merchantToken'] = getMerchantTokenCancel()
    requestData['iMid'] = iMid
    requestData['amt'] = amt
    requestData['cancelMsg'] = "Request Cancel"
    requestData['cancelServerIp'] = ""
    requestData['cancelUserId'] = ""
    requestData['cancelUserIp'] = ""
    requestData['cancelUserInfo'] = ""
    requestData['cancelRetryCnt'] = ""
    requestData['worker'] = ""
    return requestData
    
def apiRequest():
    print(datetimes)
    setParams()
    apiUrl = "https://dev.nicepay.co.id/nicepay/redirect/v2/registration"
    print(apiUrl)
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = json.dumps(requestData)
    print(params)
    headers = {"Content-Type": "application/json"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse()
    resultData = readData.read()
    return resultData

def checkStatus():
    setParamsCheckStatus()
    apiUrl = "https://dev.nicepay.co.id/nicepay/direct/v2/inquiry"
    print(apiUrl)
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = json.dumps(requestData)
    print(params)
    headers = {"Content-Type": "application/json"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse()
    resultData = readData.read()
    return resultData

def cancel():
    setParamsCancel()
    apiUrl = "https://dev.nicepay.co.id/nicepay/direct/v2/cancel"
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = json.dumps(requestData)
    headers = {"Content-Type": "application/json"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse()
    resultData = readData.read()
    return resultData