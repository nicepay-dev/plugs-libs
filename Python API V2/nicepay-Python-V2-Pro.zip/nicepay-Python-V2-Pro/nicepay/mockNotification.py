import socket
import hashlib
import sys
import urllib.parse as urlparse
import http.client as httplib
import urllib

global iMid
global merchantKey
global tXid
global referenceNo
global amt
global merchantToken
global matchCl
global status
global bankCd
global vacctNo
global authNo
global apiUrl

requestData = {}
resultData = {}

def getMerchantToken():
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using requestVA.iMid = iMid values")
    elif not referenceNo:
        sys.exit("Cannot set Merchant Token, please set param referenceNo using requestVA.referenceNo = referenceNo values")
    elif not amt:
        sys.exit("Cannot set Merchant Token, please set param amt using requestVA.amt = amt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using requestVA.merchantKey = merchantKey values")
    else:
        mercToken = iMid + referenceNo + amt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def setParamsVA():
    requestData['tXid'] = tXid
    requestData['referenceNo'] = referenceNo
    requestData['amt'] = amt
    requestData['merchantToken'] = merchantToken
    requestData['matchCl'] = matchCl
    requestData['status'] = status
    requestData['bankCd'] = bankCd
    requestData['vacctNo'] = vacctNo
    return requestData

def checkParams(param):
    for (i, name) in enumerate(param):
        if not requestData[name]:
            sys.exit("Undefined mandatory parameter '" + name + "', please set param using mockNotification."+name+" = "+name+" values")

def apiRequestVA():
    setParamsVA()
    checkParams(requestData)
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = urllib.parse.urlencode(requestData)
    headers = {"Content-type": "application/x-www-form-urlencoded"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,30)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse()
    print(readData.status, readData.reason)
