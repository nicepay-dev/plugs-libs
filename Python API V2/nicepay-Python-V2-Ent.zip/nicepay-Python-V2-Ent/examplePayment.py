import json
from pydoc import doc
import random

from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "NORMALTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.tXid = "NORMALTEST02202207041005029190"
NICEPay.amt = "15000"
NICEPay.calBackUrl = "https://ptsv2.com/t/alfred/post"
NICEPay.referenceNo = "Python20220622"

#if using credit card
NICEPay.cardNo = "4111111111111111"
NICEPay.cardExpYymm = "2512"
NICEPay.cardCvv = "123"
NICEPay.cardHolderNm = "Nicepay Test"
NICEPay.recurringToken = ""
NICEPay.preauthToken = ""
NICEPay.clickPayNo = ""
NICEPay.clickPayToken = ""
NICEPay.billingCity = ""

resultData = NICEPay.payment()
result = json.loads(resultData)
params_list = ['tXid', 'iMid', 'currency', 'amt', 'instmntMon', 'instmntType', 'referenceNo', 'goodsNm', 'payMethod', 'billingNm', 'reqDt'
    ,'reqTm', 'status', 'resultCd', 'resultMsg', 'cardNo', 'preauthToken', 'acquBankCd', 'issuBankCd', 'vacctValidDt', 'vacctValidTm'
    ,'vacctNo', 'bankCd', 'payNo', 'mitraCd', 'receiptCode', 'cancelAmt', 'transDt', 'transTm', 'recurringToken', 'ccTransType'
    ,'payValidDt', 'payValidTm', 'mRefNo', 'acquStatus', 'acquStatus', 'cardExpYymm', 'acquBankNm', 'issuBankNm', 'depositDt'
    ,'depositTm', 'paymentExpDt', 'paymentExpTm', 'paymentTrxSn', 'cancelTrxSn', 'userId', 'shopId']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue