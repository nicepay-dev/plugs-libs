import json
from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "FIXOPEN001" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.customerId = "999969"
NICEPay.startDt = "20161101"
NICEPay.endDt = "20161130"
NICEPay.merchantToken = NICEPay.getMerchantTokenCustDeposit()

#Customer Id Deposit Request
resultCustDeposit = NICEPay.custDeposit()

#Customer Id Deposit Response
result = json.loads(resultCustDeposit)

#VA Deposit Response String Format
params_list = ['resultCd', 'resultMsg', 'tXid', 'iMid', 'currency', 'amt', 'instmntMon', 'instmntType'
    , 'referenceNo', 'goodsNm', 'payMethod', 'billingNm', 'merchantToken', 'reqDt', 'reqTm', 'status', 'bankCd',
               'vacctValidDt', 'vacctValidTm', 'vacctNo', 'customerId', 'depositCustomerIdInfo']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue
