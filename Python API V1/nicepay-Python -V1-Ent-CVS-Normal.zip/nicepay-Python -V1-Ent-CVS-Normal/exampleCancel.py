import json

from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.payMethod = "02"
NICEPay.amt = "1000"
NICEPay.tXid = "IONPAYTEST02201704051816030915"
NICEPay.cancelType = "1"
NICEPay.merchantToken = NICEPay.getMerchantTokenCancel()

#Cancel Request
resultCancel = NICEPay.cancel()

#Cancel Response
result = json.loads(resultCancel)

#Cancel Response String Format
params_list = ['resultCd', 'resultMsg', 'tXid', 'iMid', 'currency', 'amt', 'instmntMon', 'instmntType'
    , 'referenceNo', 'goodsNm', 'payMethod', 'billingNm', 'merchantToken', 'reqDt', 'reqTm', 'status', 'bankCd',
               'vacctValidDt', 'vacctValidTm', 'vacctNo', 'customerId', 'depositCustomerIdInfo', 'paymentType', 'cardToken', 'description', 'transDt', 'transTm']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue