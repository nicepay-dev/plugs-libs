import json

from nicepay import NICEPay

# Set MID & Merchant Key
NICEPay.iMid = "IONPAYTEST"  # Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A=="  # Set Merchant Key

# Set Mandatory Value
NICEPay.payMethod = "03"  # Set Payment Method
NICEPay.amt = "100"  # Total Gross Amount
NICEPay.referenceNo = "NiceTest00004"  # Invoice Number By Merchant
NICEPay.goodsNm = NICEPay.referenceNo  # Goods Name
NICEPay.billingNm = "John Doe"
NICEPay.billingPhone = "02112345678"
NICEPay.billingEmail = "john@example.com"
NICEPay.billingAddr = "Jl. Jend. Sudirman No. 28"
NICEPay.billingCity = "Jakarta Pusat"
NICEPay.billingState = "DKI Jakarta"
NICEPay.billingPostCd = "10210"
NICEPay.billingCountry = "Indonesia"
NICEPay.bankCd = "BMRI"
NICEPay.vacctValidDt = ""
NICEPay.vacctValidTm = ""
NICEPay.callBackUrl = "http://localhost/Development/index.php/ExampleCallback"
NICEPay.dbProcessUrl = "https://example.com/notification-handler.php"
NICEPay.description = "Payment Of Ref No." + NICEPay.referenceNo
NICEPay.merchantToken = NICEPay.getMerchantToken()
NICEPay.userIP = NICEPay.getUserIp()
NICEPay.cartData = "{}"  # Json Array Value
NICEPay.instmntMon = "1"
NICEPay.instmntType = "1"
NICEPay.cardCvv = "331"
NICEPay.ccOnePassToken = "87cd250951da85b68f09814e36ab9b7f587b8f0a846725d5fb71883460ebe879"

resultData = NICEPay.apiRequest()
result = json.loads(resultData)

# Payment Response String Format
try:
    result['resultCd']
except NameError:
    print("Connection Timeout. Please Try Again!")
else:
    if result['resultCd'] == '0000':
        params_list = ['resultCd', 'resultMsg', 'tXid', 'callbackUrl', 'currency', 'amt', 'instmntMon', 'instmntType'
            , 'referenceNo', 'goodsNm', 'payMethod', 'billingNm', 'merchantToken', 'reqDt', 'reqTm', 'status', 'bankCd',
                       'vacctValidDt', 'vacctValidTm', 'vacctNo', 'customerId', 'depositCustomerIdInfo', 'paymentType',
                       'authNo',
                       'cardToken', 'description', 'transDt', 'transTm', 'bankVacctNo', 'payNo', 'receiptCode']
        for key in params_list:
            try:
                print("\"" + key + ": \"" + result[key])
            except KeyError:
                continue
            except TypeError:
                continue
    else:
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])
