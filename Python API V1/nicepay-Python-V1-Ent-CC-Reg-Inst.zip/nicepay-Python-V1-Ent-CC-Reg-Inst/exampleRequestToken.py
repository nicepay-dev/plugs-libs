import json

#Import Library (Mandatory)
from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "BMRITEST01" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.cardNo = "5409120028181909" #Credit Card Number
NICEPay.cardExpYymm = "2006" #Format (mmyy : 2012)
NICEPay.amt = "100" #Total Gross Amount
NICEPay.referenceNo = "NiceTest00005" #Invoice Number By Merchant
NICEPay.merchantToken = NICEPay.getMerchantToken()

resultData = NICEPay.onePassToken()
jsonResult = resultData[1:-1]
result = json.loads(jsonResult)

#One Pass Token Response String Format
params_list = ['resultCd', 'resultMsg', 'tXid', 'iMid', 'currency', 'amt', 'instmntMon', 'instmntType'
    , 'referenceNo', 'goodsNm', 'payMethod', 'billingNm', 'merchantToken', 'reqDt', 'reqTm', 'status', 'bankCd',
               'vacctValidDt', 'vacctValidTm', 'vacctNo', 'customerId', 'depositCustomerIdInfo', 'paymentType', 'cardToken']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue
print("https://www.nicepay.co.id/nicepay/api/secureVeRequest.do?country=360&callbackUrl=http://localhost/Development/index.php/ExampleCallback&onePassToken=" + result['cardToken'])