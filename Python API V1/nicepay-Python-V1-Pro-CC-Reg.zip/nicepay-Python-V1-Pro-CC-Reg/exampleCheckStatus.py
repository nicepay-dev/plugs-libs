import json

from nicepay import NICEPay

#Set Parameters For Check Status
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key
NICEPay.amt = "100"
NICEPay.referenceNo = "379072"
NICEPay.merchantToken = NICEPay.getMerchantToken()
NICEPay.tXid = "IONPAYTEST02201609161449136760"

#Check Status Request
resultCheckStatus = NICEPay.checkStatus()

#Check Status Response
result = json.loads(resultCheckStatus)

#Check Payment Response String Format
params_list = ['resultCd', 'resultMsg', 'tXid', 'iMid', 'currency', 'amt', 'instmntMon', 'instmntType'
    , 'referenceNo', 'goodsNm', 'payMethod', 'billingNm', 'merchantToken', 'reqDt', 'reqTm', 'status', 'bankCd',
               'vacctValidDt', 'vacctValidTm', 'vacctNo', 'customerId', 'depositCustomerIdInfo', 'paymentType', 'cardToken', 'description', 'transDt', 'transTm']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue

