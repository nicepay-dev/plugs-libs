from nicepay import mockNotification

mockNotification.iMid = "IONPAYTEST"
mockNotification.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A=="
mockNotification.tXid = "IONPAYTEST02201609161449136760"
mockNotification.referenceNo = "379072"
mockNotification.amt = "100"
mockNotification.merchantToken = mockNotification.getMerchantToken()
mockNotification.matchCl = "1"
mockNotification.status = "0"
mockNotification.bankCd = "CENA"
mockNotification.vacctNo = "1449136760" #Only for VA
mockNotification.authNo = "" #Only for CC
mockNotification.apiUrl = "http://ptsv2.com/t/m6o0g-1578910815/post" #Url Get Notification, open this URL to check noti -> http://ptsv2.com/t/m6o0g-1578910815/

mockNotification.apiRequestVA()