import json
import random

from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.payMethod = "02" #Set Payment Method
NICEPay.amt = "1000" #Total Gross Amount
NICEPay.referenceNo = str(random.randrange(111111, 999999)) #Invoice Number By Merchant
NICEPay.goodsNm = NICEPay.referenceNo #Goods Name
NICEPay.billingNm = "John Doe"
NICEPay.billingPhone = "02112345678"
NICEPay.billingEmail = "john@example.com"
NICEPay.billingAddr = "Jl. Jend. Sudirman No. 28"
NICEPay.billingCity = "Jakarta Pusat"
NICEPay.billingState = "DKI Jakarta"
NICEPay.billingPostCd = "10210"
NICEPay.billingCountry = "Indonesia"
NICEPay.callBackUrl = "https://example.com/callbackUrl.php"
NICEPay.dbProcessUrl = "https://example.com/notification-handler.php"
NICEPay.description = "Payment Of Ref No." + NICEPay.referenceNo
NICEPay.merchantToken = NICEPay.getMerchantToken()
NICEPay.userIP = NICEPay.getUserIp()
NICEPay.cartData = "{}" #Json Array Value
NICEPay.bankCd = "CENA" #Bank Code VA

resultData = NICEPay.apiRequest()
result = json.loads(resultData)

params_list = ['resultCd', 'resultMsg', 'tXid', 'iMid', 'currency', 'amt', 'instmntMon', 'instmntType'
    , 'referenceNo', 'goodsNm', 'payMethod', 'billingNm', 'merchantToken', 'reqDt', 'reqTm', 'status', 'bankCd',
               'vacctValidDt', 'vacctValidTm', 'vacctNo', 'customerId', 'depositCustomerIdInfo', 'paymentType', 'cardToken', 'description', 'transDt', 'transTm']
for key in params_list:
    try:
        print("\"" + key + ": \"" + result[key])
    except KeyError:
        continue
    except TypeError:
        continue