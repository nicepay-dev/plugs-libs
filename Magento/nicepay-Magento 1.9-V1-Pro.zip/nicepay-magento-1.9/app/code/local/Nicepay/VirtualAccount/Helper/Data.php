<?php
class Nicepay_VirtualAccount_Helper_Data extends Mage_Core_Helper_Abstract
{

}