<?php
class Nicepay_CreditCard_Helper_Data extends Mage_Core_Helper_Abstract
{

}