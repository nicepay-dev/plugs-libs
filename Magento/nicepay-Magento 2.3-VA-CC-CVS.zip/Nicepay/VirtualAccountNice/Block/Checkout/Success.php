<?php
namespace Nicepay\VirtualAccountNice\Block\Checkout;

use Nicepay\VirtualAccountNice\Model\Ui\ConfigProvider;

class Success extends \Magento\Checkout\Block\Onepage\Success
{
    public function getOrder() {
        return $this->_checkoutSession->getLastRealOrder();
    }
	
	public function getBankDetail($bankCd) {
        return ConfigProvider::bankList($bankCd);
    }
}