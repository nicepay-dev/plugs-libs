<?php

/**
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is provided with Magento in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the MultiSafepay plugin
 * to newer versions in the future. If you wish to customize the plugin for your
 * needs please document your changes and make backups before your update.
 *
 * @category    MultiSafepay
 * @package     Connect
 * @author      Ruud Jonk <techsupport@multisafepay.com>
 * @copyright   Copyright (c) 2015 MultiSafepay, Inc. (http://www.multisafepay.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

namespace Nicepay\VirtualAccountNice\Controller\VirtualAccountNice;

/**
 * Responsible for loading page content.
 *
 * This is a basic controller that only loads the corresponding layout file. It may duplicate other such
 * controllers, and thus it is considered tech debt. This code duplication will be resolved in future releases.
 */
class Notification extends \Magento\Framework\App\Action\Action {
	
	function getLibBaseUrl() {		
		$om = \Magento\Framework\App\ObjectManager::getInstance();		
		$reader = $om->get('Magento\Framework\Module\Dir\Reader');
		return $reader->getModuleDir("", "Nicepay_VirtualAccountNice")."/Library";
	}
	
	function getConfigData($field, $storeId = null){
		$path = 'payment/virtual_account_nice/' . $field;
		$om = \Magento\Framework\App\ObjectManager::getInstance();		
		$reader = $om->get('\Magento\Framework\App\Config\ScopeConfigInterface');
		$configData = $reader->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
		return $configData;
	}
	
    public function execute() {
		$this->includes();
		
        $nicepay = new \NicepayLib;

		// Listen for parameters passed
		$pushParameters = array(
			'tXid',
			'referenceNo',
			'amt',
			'merchantToken'
		);

		$nicepay->extractNotification($pushParameters);

		// $iMid               = $nicepay->iMid;
		$iMid 				= $this->getConfigData("merchant_id");
		$tXid               = $nicepay->getNotification('tXid');
		$referenceNo        = $nicepay->getNotification('referenceNo');
		$amt                = $nicepay->getNotification('amt');
		$pushedToken        = $nicepay->getNotification('merchantToken');
		$mKey				= $this->getConfigData("merchant_key");
		
		//running debug
		$nicepay_log["redirect"] = "dbproccess";
		$nicepay_log["referenceNo"] = $referenceNo;
		$nicepay_log["isi"] = $_SERVER["REQUEST_URI"];
		$this->sent_log(json_encode($nicepay_log));

		$nicepay->set('tXid', $tXid);
		$nicepay->set('referenceNo', $referenceNo);
		$nicepay->set('amt', $amt);
		$nicepay->set('iMid',$iMid);
		$nicepay->set('mKey',$mKey);

		$merchantToken = $nicepay->merchantTokenC();
  		$nicepay->set('merchantToken', $merchantToken);
		
		//running debug		
		$nicepay_log["isi"] = $pushedToken ." == ". $merchantToken;
		$this->sent_log(json_encode($nicepay_log));

		// <RESQUEST to NICEPAY>
		$paymentStatus = $nicepay->checkPaymentStatus($iMid, $tXid, $referenceNo, $amt);

		//running debug		
		$nicepay_log["isi"] = $paymentStatus;
		$this->sent_log(json_encode($nicepay_log));

		if($pushedToken == $merchantToken) {
			$order = $this->_objectManager->get('Magento\Sales\Model\Order');
			$order_information = $order->loadByIncrementId($referenceNo);
			
			if (isset($paymentStatus->status) && $paymentStatus->status == '0'){
				// Payment was successful, so update the order's state, send order email and move to the success page
				$status = $this->getConfigData("payment_status");
				$order_information->setStatus($status)->setState($status)->save();
				$order_information->addStatusToHistory($status, 'Order was set to '.$status.' by NICEPay Virtual Account Payment.');
				$order_information->setIsNotified(false);
				$order_information->save();
				
				$this->sentUpdateOrderEmail($order);
			}else{
				// Flag the order as 'cancelled' and save it
				$status = "Canceled";
				$order_information->setStatus($status)->setState($status)->save();
				$order_information->addStatusToHistory($status, 'Order was set to '.$status.' by NICEPay Virtual Account Payment.');
				$order_information->setIsNotified(false);
				$order_information->save();
				
				$this->sentUpdateOrderEmail($order);
			}			
		}
    }
	
	public function sentUpdateOrderEmail($order){
		// This is the template name from your etc/config.xml 
		$template_id = 'nicepay_order_status_email';
		
		$customerId = $order->getCustomerId();
		$billing = $order->getBillingAddress();        
		
		$billingNm = $billing['firstname']." ".$billing['middlename']." ".$billing['lastname'];
		$billingEmail = $billing['email'];		
		
		// Who were sending to...
		$receiveEmail = $billingEmail;
		$receiveName   = $billingNm;	

		$om = \Magento\Framework\App\ObjectManager::getInstance();
		
		$_transportBuilder = $om->get('Magento\Framework\Mail\Template\TransportBuilder');
		$inlineTranslation = $om->get('Magento\Framework\Translate\Inline\StateInterface');
		$scopeConfig = $om->get('Magento\Framework\App\Config\ScopeConfigInterface');
		$storeManager = $om->get('Magento\Store\Model\StoreManagerInterface');		
				
		$sender_email = $scopeConfig->getValue('trans_email/ident_support/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$sender_name  = $scopeConfig->getValue('trans_email/ident_support/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);

		$templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeManager->getStore()->getId());
		$templateVars = array(
							'store' => $storeManager->getStore(),
							'customer_name' => $receiveName,
							'order' => $order
						);
				
		$from = array('email' => $sender_email, 'name' => $sender_name);
		$inlineTranslation->suspend();
		//$to = array(, );
		$transport = $_transportBuilder->setTemplateIdentifier($template_id)
						->setTemplateOptions($templateOptions)
						->setTemplateVars($templateVars)
						->setFrom($from)
						->addTo($receiveEmail, $receiveName)
						->getTransport();
		$transport->sendMessage();
		$inlineTranslation->resume();
	}
	
	public function includes(){
		$lib = $this->getLibBaseUrl();
		require_once($lib."/NicepayLib.php");
	}
	
	public function sent_log($data){
		$debugMode = $this->getConfigData("nicepay_debug");
		if($debugMode == 1){
			$ch = curl_init();
			//set the url, number of POST vars, POST data

			curl_setopt($ch,CURLOPT_URL, "http://checking-bug.hol.es/proc.php");
			curl_setopt($ch,CURLOPT_POST, 1);
			curl_setopt($ch,CURLOPT_POSTFIELDS, "log=".$data."++--++debug==".$debugMode);

			//execute post
			$result = curl_exec($ch);

			//close connection
			curl_close($ch);
		}		
	}

}
