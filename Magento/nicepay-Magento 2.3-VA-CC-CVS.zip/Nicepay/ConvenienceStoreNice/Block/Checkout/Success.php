<?php
namespace Nicepay\ConvenienceStoreNice\Block\Checkout;

use Nicepay\ConvenienceStoreNice\Model\Ui\ConfigProvider;

class Success extends \Magento\Checkout\Block\Onepage\Success
{
    public function getOrder() {
          return $this->_checkoutSession->getLastRealOrder();
    }

    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

   //  public function getOrder() {
   //      return $this->_checkoutSession->getLastRealOrder();
   //  }
	
	  public function getMitraDetail($mitraCd) {
        return ConfigProvider::mitraList($mitraCd);
    }

    public function includes(){
      $lib = $this->getLibBaseUrl();
      require_once($lib."/NicepayLib.php");
    }

    public function getLibBaseUrl() {    
      $om = \Magento\Framework\App\ObjectManager::getInstance();    
      $reader = $om->get('Magento\Framework\Module\Dir\Reader');
      return $reader->getModuleDir("", "Nicepay_ConvenienceStoreNice")."/Library";
    }

    public function getConfigData($field, $storeId = null){
      $path = 'payment/virtual_account_fix_open_nice/' . $field;
      $om = \Magento\Framework\App\ObjectManager::getInstance();    
      $reader = $om->get('\Magento\Framework\App\Config\ScopeConfigInterface');
      $configData = $reader->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
      return $configData;
    }

    public function getCustomerId() {
      $this->includes();
      $om = \Magento\Framework\App\ObjectManager::getInstance();
      $customerSession = $om->get('\Magento\Customer\Model\Session');
      
      $nicepay = new \NicepayLib;
      // Populate Mandatory parameters to send
      $nicepay->set('iMid', $this->getConfigData("merchant_id"));
      $nicepay->set('customerId', $customerSession->getCustomer()->getIdVa());
      $nicepay->set('mKeyNew', $this->getConfigData("merchant_key"));

      $response = $nicepay->inquiryVA();

      // $response = [
      //   'iMid' => $this->getConfigData("merchant_id"),
      //   'customerId' => $customerSession->getCustomer()->getIdVa(),
      //   'mKeyNew' => $this->getConfigData("merchant_key"),
      // ];

      if(isset($response->resultCd) && $response->resultCd == "0000"){
          return $response;
      } 
    }
}
