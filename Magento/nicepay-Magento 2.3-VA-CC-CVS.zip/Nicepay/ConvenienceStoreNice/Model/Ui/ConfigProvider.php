<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Nicepay\ConvenienceStoreNice\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Nicepay\ConvenienceStoreNice\Gateway\Http\Client\ClientMock;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    const CODE = 'convenience_store_nice';

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */

    public function getConfig(){
        return [
            'payment' => [
                self::CODE => [
                    'transactionResults' => $this->mitraList()
                ]
            ]
        ];
    }

	public static function mitraList($mitracd = null){
		$mitra = [
			'INDO' => [
				'label' => __('INDOMARET'),
				'content' => '<strong>INDOMARET</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Pilih pembayaran melalui "INDOMARET"</li>
								<li>Catat atau print "kode pembayaran"</li>
								<li>Bawa "kode pembayaran" tersebut ke gerai "INDOMARET"</li>
								<li>Informasikan "Nama Merchant" ke kasir</li>
								<li>Berikan "kode pembayaran" ke kasir</li>
								<li>Kasir akan memasukkan "kode pembayaran"</li>
								<li>Bayar sesuai "nominal"</li>
								<li>Ambil "tanda terima pembayaran"</li>
								<li>Selesai</li>
							  </ul>
							</div>'
			],
			'ALMA' => [
				'label' => __('ALFAMART'),
				'content' => '<strong >ALFA GROUP</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Pilih pembayaran melalui "Alfamart/Alfamidi/Dan+Dan/Lawson"</li>
								<li>Catat atau print "kode pembayaran"</li>
								<li>Bawa "kode pembayaran" tersebut ke gerai "Alfamart/Alfamidi/Dan+Dan/Lawson"</li>
								<li>Informasikan kepada kasir pembayaran menggunakan "NICEPay" + "Nama Merchant"</li>
								<li>Berikan "kode pembayaran" ke kasir</li>
								<li>Kasir akan memasukkan "kode pembayaran"</li>
								<li>Bayar sesuai "nominal"</li>
								<li>Ambil "tanda terima pembayaran"</li>
								<li>Selesai</li>
							  </ul>
							</div>'
			]
		];

		if($mitracd == null){
			return $mitra;
		}

		return $mitra[$mitracd];
	}

	public static function getRequestData(){
		return $_REQUEST;
	}
}
