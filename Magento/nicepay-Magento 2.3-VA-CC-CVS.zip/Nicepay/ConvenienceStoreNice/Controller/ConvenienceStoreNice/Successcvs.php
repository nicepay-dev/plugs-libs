<?php

/**
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is provided with Magento in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the MultiSafepay plugin
 * to newer versions in the future. If you wish to customize the plugin for your
 * needs please document your changes and make backups before your update.
 *
 * @category    MultiSafepay
 * @package     Connect
 * @author      Ruud Jonk <techsupport@multisafepay.com>
 * @copyright   Copyright (c) 2015 MultiSafepay, Inc. (http://www.multisafepay.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

namespace Nicepay\ConvenienceStoreNice\Controller\ConvenienceStoreNice;

use Nicepay\ConvenienceStoreNice\Model\Ui\ConfigProvider;

/**
 * Responsible for loading page content.
 *
 * This is a basic controller that only loads the corresponding layout file. It may duplicate other such
 * controllers, and thus it is considered tech debt. This code duplication will be resolved in future releases.
 */
class Successcvs extends \Magento\Framework\App\Action\Action {
	/**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;
    protected $_pageFactory;
    protected $resultPageFactory;
    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     */
    public function __construct(
       \Magento\Framework\App\Action\Context $context,
       \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
       \Magento\Framework\View\Result\PageFactory $resultPageFactory,
       \Magento\Framework\View\Result\PageFactory $_pageFactory)
    {
       $this->resultJsonFactory = $resultJsonFactory;
       $this->resultPageFactory = $resultPageFactory;
       $this->_pageFactory = $_pageFactory;
       parent::__construct($context);
    }
    /**
     * View  page action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
      $resultPage = $this->resultPageFactory->create();
      $resultPage->getConfig()->getTitle()->prepend(__('Custom Front View'));
      return $resultPage;
    }

    public function includes(){
      $lib = $this->getLibBaseUrl();
      require_once($lib."/NicepayLib.php");
    }

    public function getLibBaseUrl() {    
      $om = \Magento\Framework\App\ObjectManager::getInstance();    
      $reader = $om->get('Magento\Framework\Module\Dir\Reader');
      return $reader->getModuleDir("", "Nicepay_ConvenienceStoreNice")."/Library";
    }

    public function getConfigData($field, $storeId = null){
      $path = 'payment/virtual_account_fix_open_nice/' . $field;
      $om = \Magento\Framework\App\ObjectManager::getInstance();    
      $reader = $om->get('\Magento\Framework\App\Config\ScopeConfigInterface');
      $configData = $reader->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
      return $configData;
    }

    public function getCustomerId() {
      $this->includes();
      $om = \Magento\Framework\App\ObjectManager::getInstance();
      $customerSession = $om->get('\Magento\Customer\Model\Session');
      
      $nicepay = new \NicepayLib;
      // Populate Mandatory parameters to send
      $nicepay->set('iMid', $this->getConfigData("merchant_id"));
      $nicepay->set('customerId', $customerSession->getCustomer()->getIdVa());
      $nicepay->set('mKeyNew', $this->getConfigData("merchant_key"));

      $response = $nicepay->inquiryVA();

      return  $response;
    }

}
