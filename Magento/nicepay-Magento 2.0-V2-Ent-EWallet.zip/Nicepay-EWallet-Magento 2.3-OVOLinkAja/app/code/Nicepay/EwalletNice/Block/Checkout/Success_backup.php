<?php
namespace Nicepay\ConvenienceStoreNice\Block\Checkout;

use Nicepay\ConvenienceStoreNice\Model\Ui\ConfigProvider;

class Success extends \Magento\Checkout\Block\Onepage\Success
{

    public function getOrder() {
        return $this->_checkoutSession->getLastRealOrder();
    }
	
	public function getMitraDetail($mitraCd) {
        return ConfigProvider::mitraList($mitraCd);
    }
}
