<?php
namespace Nicepay\EwalletNice\Block\Checkout;

use Nicepay\EwalletNice\Model\Ui\ConfigProvider;

class Success extends \Magento\Checkout\Block\Onepage\Success
{
    public function getOrder() {
          return $this->_checkoutSession->getLastRealOrder();
    }

    public function getParams()
    {
        return $_REQUEST;
    }
}
