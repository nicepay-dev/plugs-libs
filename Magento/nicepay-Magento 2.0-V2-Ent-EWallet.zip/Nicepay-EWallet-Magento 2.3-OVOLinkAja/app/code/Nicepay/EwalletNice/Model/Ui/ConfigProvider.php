<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Nicepay\EwalletNice\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Nicepay\EwalletNice\Gateway\Http\Client\ClientMock;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    const CODE = 'ewallet_nice';

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */

    public function getConfig(){
        return [
            'payment' => [
                self::CODE => [
                    'transactionResults' => $this->mitraList()
                ]
            ]
        ];
    }

    public static function mitraList($mitracd = null){
        $mitra = [
            'OVOE' => [
                'label' => __('OVO'),
                'content' => '<strong>OVO</strong>'
            ],
            'LINK' => [
                'label' => __('LinkAja'),
                'content' => '<strong>LinkAja</strong>'
            ],
        ];

        if($mitracd == null){
            return $mitra;
        }

        return $mitra[$mitracd];
    }

    public static function getRequestData(){
        return $_REQUEST;
    }
}
