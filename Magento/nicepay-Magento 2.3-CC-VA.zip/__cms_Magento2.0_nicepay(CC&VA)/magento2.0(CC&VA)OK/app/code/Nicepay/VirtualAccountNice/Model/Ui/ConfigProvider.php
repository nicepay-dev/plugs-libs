<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Nicepay\VirtualAccountNice\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Nicepay\VirtualAccountNice\Gateway\Http\Client\ClientMock;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    const CODE = 'virtual_account_nice';

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */

    public function getConfig(){
        return [
            'payment' => [
                self::CODE => [
                    'transactionResults' => $this->bankList()
                ]
            ]
        ];
    }

	public static function bankList($bankcd = null){
		$bank = [
			'BMRI' => [
				'label' => __('Mandiri'),
				'content' => '<strong>ATM Mandiri</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Pilih menu "Bayar"</li>
								<li>Pilih menu "Multi Payment"</li>
								<li>Masukkan "70014" sebagai Kode Perusahaan / Institusi, kemudian pilih Benar</li>
								<li>Masukkan Transferpay Kode Bayar dengan Virtual Account yang sudah didapatkan</li>
								<li>Pilih YA setelah muncul konfirmasi pembayaran</li>
								<li>Periksa kembali Nominal Pembayaran Anda pada halaman Konfirmasi Pembayaran, kemudian pilih YA</li>
								<li>Ambil bukti pembayaran Anda dan Transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Mobile Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Mobile Banking</li>
								<li>Pilih menu "Bayar"</li>
								<li>Pilih menu "Multi Payment"</li>
								<li>Input Transferpay sebagai penyedia jasa</li>
								<li>Input Nomor Virtual Account, misal : 70014XXXXXXXXXXX</li>
								<li>Pilih Lanjut</li>
								<li>Input OTP dan PIN</li>
								<li>Pilih OK</li>
								<li>Ambil bukti pembayaran Anda dan Transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Internet Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Internet Banking</li>
								<li>Pilih menu "Bayar"</li>
								<li>Pilih menu "Multi Payment"</li>
								<li>Input Transferpay sebagai penyedia jasa</li>
								<li>Input Nomor Virtual Account, misal : 70014XXXXXXXXXXX sebagai Kode Bayar</li>
								<li>Ceklis IDR</li>
								<li>Klik Lanjutkan</li>
								<li>Bukti bayar ditampilkan</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<small>*Minimum pembayaran menggunakan Bank Transfer adalah Rp 10.000</small>'
			],
			'BBBA' => [
				'label' => __('Permata Bank'),
				'content' => '<strong >ATM Permata Bank</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Masukkan Nomor PIN</li>
								<li>Pilih menu "TRANSAKSI LAINNYA"</li>
								<li>Pilih menu "PEMBAYARAN"</li>
								<li>Pilih "Pembayaran Lain-Lain"</li>
								<li>Pilih "VIRTUAL ACCOUNT";</li>
								<li>Masukkan 16 digit kode bayar (virtual account)<br/>Contoh : 8625xxxxx</li>
								<li>Pada layar akan tampil konfirmasi pembayaran</li>
								<li>Pilih "BENAR" untuk konfirmasi pembayaran</li>
								<li>Pilih "YA" agar struk / bukti transaksi keluar</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Mobile Banking Permata</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Mobile Banking</li>
								<li>Pilih menu "Pembayaran Tagihan"</li>
								<li>Pilih menu "Virtual Account"</li>
								<li>Masukkan 16 digit kode bayar (virtual account)<br/>Misal : 8625xxxxx</li>
								<li>Masukkan Nominal Pembayaran</li>
								<li>Klik Kirim dan Input Token</li>
								<li>Pada layar akan tampil konfirmasi pembayaran</li>
								<li>Pilih "BENAR" untuk konfirmasi pembayaran</li>
								<li>Bukti transaksi akan ditampilkan</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Internet Banking Permata</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Internet Banking</li>
								<li>Pilih menu "Pembayaran Tagihan"</li>
								<li>Pilih menu "Virtual Account"</li>
								<li>Masukkan 16 digit kode bayar (virtual account)<br/>Misal : 8625xxxxx</li>
								<li>Masukkan Nominal Pembayaran</li>
								<li>Klik Kirim dan Input Token</li>
								<li>Pada layar akan tampil konfirmasi pembayaran</li>
								<li>Klik Kirim untuk konfirmasi pembayaran</li>
								<li>Bukti transaksi akan ditampilkan</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<small>*Minimum pembayaran menggunakan Bank Transfer adalah Rp 10.000</small>'
			],
			'IBBK' => [
				'label' => __('Maybank'),
				'content' => '<strong >Maybank</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Pilih menu "Pembayaran / TOP UP Pulsa"</li>
								<li>Pilih menu "Virtual Account"</li>
								<li>Masukkan Nomor Virtual Account misal : 7812XXXXXXXXXXXX, kemudian pilih "BENAR"</li>
								<li>Periksa kembali Nominal Pembayaran Anda pada halaman Konfirmasi Pembayaran</li>
								<li>Kemudian Pilih "YA"</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<small>*Minimum pembayaran menggunakan Bank Transfer adalah Rp 10.000</small>'
			],
			'BNIN' => [
				'label' => __('BNI'),
				'content' => '<strong>ATM BNI</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Pilih menu "Menu Lain"</li>
								<li>Pilih menu "Transfer"</li>
								<li>Pilih menu "Sumber Rekening"</li>
								<li>Pilih menu "ke Rekening BNI"</li>
								<li>Pilih tipe akun Anda, misal "Rekening Tabungan"</li>
								<li>Masukkan Nomor Virtual Account, misal 8848XXXXXXXXXXXX</li>
								<li>Masukkan nominal pembayaran, kemudian pilih "BENAR"</li>
								<li>Pilih "YA" untuk konfirmasi pembayaran</li>
								<li>Ambil bukti pembayaran Anda dan transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Mobile Banking BNI</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Mobile Banking</li>
								<li>Pilih menu "Transfer"</li>
								<li>Pilih menu "Within Bank"</li>
								<li>Pilih menu "Adhoc Beneficiary"</li>
								<li>Input Nomor Order, misal. Invoice-1234 sebagai Nickname</li>
								<li>Masukkan 16 digit nomor virtual account<br/>Misal : 8848xxxxx</li>
								<li>Masukkan email anda</li>
								<li>Hilangkan centang Add to Favorite list lalu klik Continue</li>
								<li>Masukkan Nominal Pembayaran pada field Amount</li>
								<li>Pilih Continue dan input password anda</li>
								<li>Bukti transaksi akan ditampilkan</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Internet Banking BNI</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Internet Banking</li>
								<li>Pilih menu "Info dan Administrasi"</li>
								<li>Pilih menu "Atur rekening Tujuan"</li>
								<li>Input Nomor Order, misal. Invoice-1234 sebagai Nama Singkat lalu lanjutkan</li>
								<li>Masukkan 16 digit nomor virtual account <br/>Misal : 8848xxxxxxxx</li>
								<li>Klik Lanjutkan</li>
								<li>Input Token lalu Process</li>
								<li>Pilih Transfer rekening antar BNI</li>
								<li>Pilih Nomor Order, misal. Invoice-1234</li>
								<li>Masukkan Nominal Pembayaran</li>
								<li>Bukti transaksi akan ditampilkan</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<small>*Minimum pembayaran menggunakan Bank Transfer adalah Rp 10.000</small>'
			],
			'HNBN' => [
				'label' => __('KEB Hana Bank'),
				'content' => '<strong>ATM KEB Hana</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Pilih menu "Pembayaran"</li>
								<li>Pilih menu "Lainnya"</li>
								<li>Masukkan Nomor Virtual Account, misal 9772XXXXXXXXXXXX</li>
								<li>Pilih "BENAR"</li>
								<li>Pilih "YA" untuk konfirmasi pembayaran</li>
								<li>Ambil bukti pembayaran Anda dan transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Internet Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Internet Banking</li>
								<li>Pilih menu "Transfer"</li>
								<li>Pilih "Withdrawal Account Information"</li>
								<li>Pilih Account Number Anda</li>
								<li>Masukkan nomor virtual account <br/>Misal : 9772XXXXXXXXXXXX</li>
								<li>Masukkan Nominal Pembayaran, misal : 10000</li>
								<li>Klik Submit</li>
								<li>Input SMS Pin</li>
								<li>Bukti transaksi akan ditampilkan</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<small>*Minimum pembayaran menggunakan Bank Transfer adalah Rp 10.000</small>'
			],
			'CENA' => [
				'label' => __('Bank BCA'),
				'content' => '<strong>ATM BANK BCA</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Input kartu ATM dan PIN anda.</li>
								<li>Pilih menu Transaksi Lainnya</li>
								<li>Pilih Transfer</li>
								<li>Pilih "Ke rekening BCA Virtual Account"</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Pilih Benar</li>
								<li>Pilih Ya</li>
								<li>Ambil bukti bayar</li>
								<li>Selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Internet Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Internet Banking</li>
								<li>Pilih Transaksi Dana</li>
								<li>Pilih Transfer Ke BCA Virtual Account</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Klik Lanjutkan</li>
								<li>Input Respon KeyBCA Appli 1</li>
								<li>Klik Kirim</li>
								<li>Bukti transaksi akan ditampilkan</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Mobile Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Mobile Banking</li>
								<li>Pilih m-Transfer</li>
								<li>Pilih BCA Virtual Account</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Klik Send</li>
								<li>Informasi Virtual Account akan ditampilkan</li>
								<li>Klik Ok</li>
								<li>Input PIN Mobile Banking</li>
								<li>Bukti pembayaran akan ditampilkan dan transaksi selesai.</li>
							  </ul>
							</div>'
			],
			'BRIN' => [
				'label' => __('Bank Rakyat Indonesia'),
				'content' => '<strong>ATM BANK BRI</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Input kartu ATM dan PIN anda.</li>
								<li>Pilih menu Transaksi Lainnya</li>
								<li>Pilih Menu Pembayaran</li>
								<li>Pilih Menu Lain-lain</li>
								<li>Pilih Menu BRIVA</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Pilih Ya</li>
								<li>Ambil bukti bayar</li>
								<li>Selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Internet Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Internet Banking</li>
								<li>Pilih Pembayaran</li>
								<li>Pilih BRIVA</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Klik Kirim</li>
								<li>Masukkan Password</li>
								<li>Masukkan mToken</li>
								<li>Klik Kirim</li>
								<li>Bukti transaksi akan ditampilkan</li>
								<li>Transaksi selesai</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Mobile Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login BRI Mobile</li>
								<li>Pilih Mobile Banking BRI</li>
								<li>Pilih Pembayaran</li>
								<li>Pilih Menu BRIVA</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Masukkan Nominal misal. 10000</li>
								<li>Klik Kirim</li>
								<li>Masukkan PIN Mobile</li>
								<li>Klik Kirim</li>
								<li>Bukti Bayar akan dikirim melalui SMS</li>
								<li>Selesai</li>
							  </ul>
							</div>'
			],
			'BNIA' => [
				'label' => __('Bank CIMB NIAGA'),
				'content' => '<strong>ATM BANK CIMB</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Input kartu ATM dan PIN anda.</li>
								<li>Pilih menu Pembayaran</li>
								<li>Pilih Menu Lanjut</li>
								<li>Pilih Menu Virtual Account</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Pilih Proses</li>
								<li>Data Virtual Account akan ditampilkan</li>
								<li>Pilih Proses</li>
								<li>Ambil bukti bayar anda dan transaksi selesai.</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Internet Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Internet Banking</li>
								<li>Pilih Bayar Tagihan</li>
								<li>Rekening Sumber - Pilih yang akan Anda digunakan</li>
								<li>Jenis Pembayaran - Pilih Virtual Account</li>
								<li>Untuk Pembayaran - Pilih Masukkan Nomor Virtual Account</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Isi Remark Jika diperlukan</li>
								<li>Klik Lanjut</li>
								<li>Data Virtual Account akan ditampilkan</li>
								<li>Masukkan mPin</li>
								<li>Klik Kirim</li>
								<li>Bukti bayar akan ditampilkan dan transaksi selesai.</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Mobile Banking</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login Go Mobile</li>
								<li>Pilih Menu Transfer</li>
								<li>Pilih Menu Transfer ke CIMB Niaga Lain</li>
								<li>Pilih Sumber Dana yang akan digunakan</li>
								<li>Input Nomor Virtual Account, misal. 123456789012XXXX</li>
								<li>Masukkan Nominal misal. 10000</li>
								<li>Klik Lanjut</li>
								<li>Data Virtual Account akan ditampilkan</li>
								<li>Masukkan PIN Mobile</li>
								<li>Klik Konfirmasi</li>
								<li>Bukti bayar akan dikirim melalui SMS dan transaksi selesai</li>
							  </ul>
							</div>'
			],
			'BDIN' => [
				'label' => __('Bank Danamon Indonesia'),
				'content' => '<strong>ATM BANK Danamon</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Input PIN ATM Anda</li>
								<li>Pilih menu Pembayaran >>> Virtual Account</li>
								<li>Masukkan nomor Virtual Account</li>
								<li>Masukkan Nominal</li>
								<li>Pada layar konfirmasi pembayaran, pastikan transaksi sudah benar -> pilih Ya untuk memproses transaksi</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Internet Banking Bank Lain</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Masuk ke menu "transfer ke bank lain"</li>
								<li>Pilih transfer online</li>
								<li>Pilih Bank tujuan, Bank Danamon</li>
								<li>Masukkan 16 Digit nomor Virtual Account</li>
								<li>Masukkan nominal pembayaran</li>
								<li>Pada layar konfirmasi pembayaran, harap pastikan nama tujuan dan nominal transaksi sudah tepat</li>
								<li>Konfirmasi pembayaran</li>
							  </ul>
							</div>
							<br><br><strong id="h4thanks">Mobile Banking Aplikasi D-Mobile</strong>
							<div style="border:1px solid #cccccc;padding:10px 20px 0;">
							  <ul style="list-style-type: disc">
								<li>Login pada Aplikasi D-MOBILE</li>
								<li>Pilih Virtual Account</li>
								<li>Masukkan 16 Digit nomor Virtual Account</li>
								<li>Masukkan Nominal</li>
								<li>Pada layar konfirmasi pembayaran, pastikan transaksi sudah benar -> pilih Ya untuk memproses transaksi.</li>
							  </ul>
							</div>'
			]
		];

		if($bankcd == null){
			return $bank;
		}

		return $bank[$bankcd];
	}

	public static function getRequestData(){
		return $_REQUEST;
	}
}
