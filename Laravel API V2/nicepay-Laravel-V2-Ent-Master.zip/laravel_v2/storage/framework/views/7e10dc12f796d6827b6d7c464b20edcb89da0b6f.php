<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NICEPAY - Secure Checkout</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/index.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>

<body>

<!-- NAVIGATION PANE -->
<div class="nav flex-center">
    <input class="tablinks" type="button" onclick="window.location='<?php echo e(url("/")); ?>'" id="home-btn" value="<<" />
    <input class="tablinks" type="button" onclick="openCity(event, 'payMethod-form')" id="payMethod-btn" value="Convenience Store" />
    <input class="tablinks" type="button" onclick="openCity(event, 'check-form')" id="check-btn" value="Check Payment" />
    <input class="tablinks" type="button" onclick="openCity(event, 'cancel-form')" id="cancel-btn" value="Cancel Payment" />
</div>

<!-- FORM CHECKOUT PAYMENT METHOD -->
<div id="payMethod-form" class="form-style-8">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="Logo">Convenience Store V1 Professional</div>
    <form action="/requestCVS" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="payMethod" value="03">

        <div class="group">
            <div class="row">
                <div class="column left"><img class="img-valign" style="width: 150px; height:auto" src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone11-select-2019-family?wid=882&amp;hei=1058&amp;fmt=jpeg&amp;qlt=80&amp;op_usm=0.5,0.5&amp;.v=1567022175704" alt="Logo"></div>
                <div class="column right"><p style="text-align: justify">iPhone 11 succeeds the iPhone XR, and it features a 6.1-inch LCD display that Apple calls a "Liquid Retina HD Display." It features a 1792 x 828 resolution at 326ppi, a 1400:1 contrast ratio, 625 nits max brightness, True Tone support for adjusting the white balance to the ambient lighting, and wide color support for true-to-life colors.</p></div>
            </div>
        </div>

        <div class="group">
            <input type="text" name="referenceNo"  value="<?php echo e(uniqid('NCPAY-', true)); ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Reference Number</label>
        </div>

        <div class="group">
            <input type="number" min="1" name="amt" value="15000" />
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Price</label>
        </div>

        <div class="group">
            <input type="number" min="1" name="payValidDt" value="<?php echo e(date("Ymd")); ?>" />
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Validation Date</label>
        </div>

        <div class="group">
            <input type="number" min="1" name="payValidTm" value="235959" />
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Validation Time</label>
        </div>


        <input class="help-btn" type="button" onclick="window.location='https://docs.nicepay.co.id/api-v1-ID.html#convenience-store'" id="home-btn" value="?" />
        <input type="submit" value="Checkout" />
    </form>
</div>

<!-- FORM CHECK PAYMENT -->
<div id="check-form" class="form-style-8">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="">Check Payment V1</div>
    <form action="checkPayment.php" method="post">
        <input type="hidden" name="payMethod" value="03">

        <div class="group">
            <input type="text" name="tXid"/>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Transaction ID</label>
        </div>

        <div class="group">
            <input type="text" name="referenceNo" value="99999" />
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Reference Number</label>
        </div>

        <div class="group">
            <input type="number" min="1" name="amt" value="15000" />
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Amount</label>
        </div>
        <input class="help-btn" type="button" onclick="window.location='https://docs.nicepay.co.id/api-v1-ID.html#cek-status-transaksi'" id="home-btn" value="?" />
        <input type="submit" value="check Payment" />
    </form>
</div>

<!-- FORM CANCEL -->
<div id="cancel-form" class="form-style-8">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="">Cancel V1</div>
    <form action="cancel.php" method="post">
        <input type="hidden" name="payMethod" value="03">

        <div class="group">
            <input type="text" name="tXid"/>
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Transaction ID</label>
        </div>

        <div class="group">
            <input type="number" min="1" name="amt" value="15000" />
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Amount</label>
        </div>

        <input type="radio" name="cancelType" value="1" checked>Full Cancellation
        <input type="radio" name="cancelType" value="2">Partial Cancellation
        <br >
        <input class="help-btn" type="button" onclick="window.location='https://docs.nicepay.co.id/api-v1-ID.html#membatalkan-transaksi'" id="home-btn" value="?" />
        <input style="margin-top:5% !important;" type="submit" value="cancel Transaction" />
    </form>
</div>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.5.1.min.js?ver=3.5"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('/js/index.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\laragon\www\Journey\resources\views\cvs.blade.php ENDPATH**/ ?>