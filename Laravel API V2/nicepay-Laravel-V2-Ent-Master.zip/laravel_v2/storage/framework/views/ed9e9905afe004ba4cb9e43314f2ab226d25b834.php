<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Payment Status</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/index.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>

<body>

<div class="form-style-8" style="margin-top:5%;">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="">Your Payment...</div>
    <?php if(isset($resultCd) && $resultCd == "0000"): ?>
        <form action="cancelPayment" method="post">
            <?php echo csrf_field(); ?>
            <div class="group">
                <input type="text" name="tXid" value="<?php echo e($tXid); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction ID</label>
            </div>

            <div class="group">
                <input type="hidden" name="payMethod" value="<?php echo e(Session::get('payMethod')); ?>">
                <?php if(Session::get('payMethod') === "01"): ?>
                    <input type="text" name="" value="Credit Card">
                <?php elseif(Session::get('payMethod') === "02"): ?>
                    <input type="text" name="" value="Virtual Account">
                <?php elseif(Session::get('payMethod') === "03"): ?>
                    <input type="text" name="" value="Convenience Store">
                <?php elseif(Session::get('payMethod') === "04"): ?>
                    <input type="text" name="" value="Click Pay">
                <?php elseif(Session::get('payMethod') === "05"): ?>
                    <input type="text" name="" value="E-Wallet">
                <?php elseif(Session::get('payMethod') === "06"): ?>
                    <input type="text" name="" value="Pay Loan">
                <?php endif; ?>
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Payment Method</label>
            </div>

            <div class="group">
                <input type="text" name="amt" value="<?php echo e($amt); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Amount</label>
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="<?php echo e($resultMsg); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Status Payment</label>
            </div>

            <div class="group">
                <input type="text" name="reqDt" value="<?php echo e($reqDt); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Request Date</label>
            </div>

            <div class="group">
                <input type="text" name="reqTm" value="<?php echo e($reqTm); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Request Time</label>
            </div>

            <div class="group">
                <input type="text" name="transDt" value="<?php echo e($transDt); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction Date</label>
            </div>

            <div class="group" style="margin-bottom: 5% !important;">
                <input type="text" name="transTm" value="<?php echo e($transTm); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction Time</label>
            </div>

            <input type="radio" name="cancelType" value="1" checked>Full Cancellation
            <input type="radio" name="cancelType" value="2">Partial Cancellation
            <br >

            <input style="margin-top:5% !important;" type="submit" value="Cancel Transaction"/>
        </form>
        <br>
        <form action="index.html" method="get">
            <input type="submit" value="Back To Checkout" formaction="/"/>
        </form>

    <?php elseif(isset($resultCd)): ?>
        <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="">Error!</div>
        <form action="index.html" method="get">
            <?php echo csrf_field(); ?>
            <div class="group">
                <input type="text" name="tXid" value="<?php echo e($resultCd); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Code</label>
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="<?php echo e($resultMsg); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Message</label>
            </div>
            <input type="submit" value="Back To Checkout" formaction="/" />
        </form>
    <?php endif; ?>

</div>
</body>
</html>
<?php /**PATH C:\laragon\www\Journey\resources\views/checkPaymentResult.blade.php ENDPATH**/ ?>