<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cancellation Result</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/index.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>
<body>

<div class="form-style-8" style="margin-top:5%;">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="">Error!</div>
    <form action="index.html" method="get">
        <?php echo csrf_field(); ?>
        <?php if(null==Session::get('msg')): ?>
        <?php echo e($msg); ?>

        <?php elseif(null!=Session::get('msg')): ?>
            <?php echo e(Session::get('msg')); ?>

        <?php endif; ?>
            <br>
        <input style="margin-top:5% !important;" type="submit" value="Back To Checkout" formaction="/" />
    </form>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\Journey\resources\views\otherError.blade.php ENDPATH**/ ?>