package com.nicepay.demo.lib;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.catalina.connector.ClientAbortException;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class NicepayLib {

	public static final String urlRealRegis = "https://www.nicepay.co.id/nicepay/direct/v2/registration";
	public static final String urlRealRegisV1 = "https://www.nicepay.co.id//nicepay/api/orderRegist.do";

	public static final String urlLocalRegis = "https://dev.nicepay.co.id/nicepay/direct/v2/registration";
	public static final String urlLocalRegisV1 = "https://dev.nicepay.co.id/nicepay/api/orderRegist.do";
	public static final String urlLocalCheckPayment = "https://dev.nicepay.co.id/nicepay/api/onePassStatus.do";
	public static final String urlLocalCancelPayment = "https://dev.nicepay.co.id/nicepay/api/onePassAllCancel.do";

	private boolean bDebug;
	private String merchantID = "";
	private String merchantKey = "";
	private String merchantToken = "";
	private Hashtable<String, String> htRequest;
	private Hashtable<String, String> htResponse;
	private String responseString = "";
	private common cmn;
	private int functionType = 0;

	private String timeStamp = "";
	private String payMethod = "";
	private String currency = "IDR";
	private String amt = "";
	private String instmntType = "0";
	private String instmntMon = "0";
	private String referenceNo = "";
	private String goodsNm = "";
	private String billingNm = "";
	private String billingPhone = "";
	private String billingEmail = "";
	private String billingAddr = "";
	private String billingCity = "";
	private String billingState = "";
	private String billingPostCd = "";
	private String billingCountry = "";
	private String deliveryNm = "";
	private String deliveryPhone = "";
	private String deliveryAddr = "";
	private String deliveryCity = "";
	private String deliveryState = "";
	private String deliveryPostCd = "";
	private String deliveryCountry = "";
	private String dbProcessUrl = "";
	private String vat = "0";
	private String fee = "0";
	private String notaxAmt = "0";
	private String description = "";
	private String reqDt = "";
	private String reqTm = "";
	private String reqDomain = "";
	private String reqServerIP = "";
	private String reqClientVer = "1.16";
	private String userIP = "";
	private String userSessionID = "";
	private String userAgent = "";
	private String userLanguage = "";
	private String cartData = "{}";
	private String sellers = "";
	private String merFixAcctId = "";
	private String vacctValidDt = "";
	private String vacctValidTm = "";
	private String bankCd = "";
	private String cardNo = "";
	private String cardExpYymm = "";
	private String cardCvv = "";
	private String cavv = "";
	private String eci = "";
	private String xid = "";
	private String trxId = "";
	private String cancelType = "1";
	private String cancelMsg = "";
	private String cancelUserId = "";
	private String cancelUserInfo = "";
	private String cancelRetryCnt = "";
	private String worker = "";
	private String pan = "";
	private String cardExpiry = "";
	private String onePassToken = "";
	private String recurringToken = "";
	private String preauthToken = "";
	private String customerID = "";
	private String customerNm = "";
	private String vaNumber = "";
	private String fromDate = "";
	private String toDate = "";
	private String recurrOpt = "";
	private String cardHolderNm = "";
	private String callBack = "";
	private String callBackUrl = "";

	// CVS
	private String mitraCd = "";
	private String payValidDt = "";
	private String payValidTm = "";

	// clickpay
	private String clickPayNo = "";
	private String dataField3 = "";
	private String clickPayToken = "";

	public NicepayLib(String MID, String merchantKeyFilePath, boolean bDebug) throws IOException {
		setbDebug(bDebug);
		setMerchantID(MID);
		setMerchantKey(merchantKeyFilePath);

		htRequest = new Hashtable<String, String>();
		// htResponse = new Hashtable<String, String>();
		cmn = new common();
	}

	public String makeToken() throws Exception {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		String textToken = merchantID + merchantKey;
		System.out.println("TEST TOKEN " + textToken);

		md.update(textToken.getBytes("UTF-8"));
		merchantToken = String.format("%064x", new java.math.BigInteger(1, md.digest()));

		return merchantToken;
	}

	// Special for registration
	public String makeToken(String customerID) throws Exception {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		String textToken = merchantID + customerID + merchantKey;

		md.update(textToken.getBytes("UTF-8"));
		merchantToken = String.format("%064x", new java.math.BigInteger(1, md.digest()));

		return merchantToken;
	}

	public String makeToken(String amount, String ReferenceNo, String timeStamp) throws Exception {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		String textToken = timeStamp + merchantID + ReferenceNo + amount + merchantKey;

		md.update(textToken.getBytes("UTF-8"));
		merchantToken = String.format("%064x", new java.math.BigInteger(1, md.digest()));

		return merchantToken;
	}

	public String makeTokenV1(String amount, String ReferenceNo) throws Exception {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		String textToken = merchantID + ReferenceNo + amount + merchantKey;

		md.update(textToken.getBytes("UTF-8"));
		merchantToken = String.format("%064x", new java.math.BigInteger(1, md.digest()));

		return merchantToken;
	}
	public String makeTokenCancel(String trxId, String amt) throws Exception {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		String textToken = merchantID + trxId + amt + merchantKey;

		md.update(textToken.getBytes("UTF-8"));
		merchantToken = String.format("%064x", new java.math.BigInteger(1, md.digest()));

		return merchantToken;
	}

	/**
	 * @return the bDebug
	 */
	public boolean isbDebug() {
		return bDebug;
	}

	/**
	 * @param bDebug the bDebug to set
	 */
	public void setbDebug(boolean bDebug) {
		this.bDebug = bDebug;
	}

	/**
	 * @return the merchantID
	 */
	public String getMerchantID() {
		return merchantID;
	}

	/**
	 * @param merchantID the merchantID to set
	 */
	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	/**
	 * @return the merchantKey
	 */
	public String getMerchantKey() {
		return merchantKey;
	}

	/**
	 * @param merchantKey the merchantKey to set
	 */
	public void setMerchantKey(String merchantKey) {
		this.merchantKey = merchantKey;
	}

	/**
	 * @return the merchantToken
	 */
	public String getMerchantToken() {
		return merchantToken;
	}

	/**
	 * @param merchantToken the merchantToken to set
	 */
	public void setMerchantToken(String merchantToken) {
		this.merchantToken = merchantToken;
	}

	/**
	 * @return the htRequest
	 */
	public Hashtable<String, String> getHtRequest() {
		return htRequest;
	}

	/**
	 * @param htRequest the htRequest to set
	 */
	public void setHtRequest(Hashtable<String, String> htRequest) {
		this.htRequest = htRequest;
	}

	/**
	 * @return the htResponse
	 */
	public Hashtable<String, String> getHtResponse() {
		return htResponse;
	}

	/**
	 * @param htResponse the htResponse to set
	 */
	public void setHtResponse(Hashtable<String, String> htResponse) {
		this.htResponse = htResponse;
	}

	/**
	 * @return the responseString
	 */
	public String getResponseString() {
		return responseString;
	}

	/**
	 * @param responseString the responseString to set
	 */
	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}

	/**
	 * @return the functionType
	 */
	public int getFunctionType() {
		return functionType;
	}

	/**
	 * @param functionType the functionType to set
	 */
	public void setFunctionType(int functionType) {
		this.functionType = functionType;
	}

	/**
	 * @return the callBack
	 */
	public String getCallBack() {
		return callBack;
	}

	/**
	 * @param callBack the callBack to set
	 */
	public void setCallBack(String callBack) {
		this.callBack = callBack;
	}

	/**
	 * @return the callBackUrl
	 */
	public String getCallBackUrl() {
		return callBackUrl;
	}

	/**
	 * @param callBackUrl the callBackUrl to set
	 */
	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the payMethod
	 */
	public String getPayMethod() {
		return payMethod;
	}

	/**
	 * @param payMethod the payMethod to set
	 */
	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the amt
	 */
	public String getAmt() {
		return amt;
	}

	/**
	 * @param amt the amt to set
	 */
	public void setAmt(String amt) {
		this.amt = amt;
	}

	/**
	 * @return the instmntType
	 */
	public String getInstmntType() {
		return instmntType;
	}

	/**
	 * @param instmntType the instmntType to set
	 */
	public void setInstmntType(String instmntType) {
		this.instmntType = instmntType;
	}

	/**
	 * @return the instmntMon
	 */
	public String getInstmntMon() {
		return instmntMon;
	}

	/**
	 * @param instmntMon the instmntMon to set
	 */
	public void setInstmntMon(String instmntMon) {
		this.instmntMon = instmntMon;
	}

	/**
	 * @return the referenceNo
	 */
	public String getReferenceNo() {
		return referenceNo;
	}

	/**
	 * @param referenceNo the referenceNo to set
	 */
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	/**
	 * @return the goodsNm
	 */
	public String getGoodsNm() {
		return goodsNm;
	}

	/**
	 * @param goodsNm the goodsNm to set
	 */
	public void setGoodsNm(String goodsNm) {
		this.goodsNm = goodsNm;
	}

	/**
	 * @return the billingNm
	 */
	public String getBillingNm() {
		return billingNm;
	}

	/**
	 * @param billingNm the billingNm to set
	 */
	public void setBillingNm(String billingNm) {
		this.billingNm = billingNm;
	}

	/**
	 * @return the billingPhone
	 */
	public String getBillingPhone() {
		return billingPhone;
	}

	/**
	 * @param billingPhone the billingPhone to set
	 */
	public void setBillingPhone(String billingPhone) {
		this.billingPhone = billingPhone;
	}

	/**
	 * @return the billingEmail
	 */
	public String getBillingEmail() {
		return billingEmail;
	}

	/**
	 * @param billingEmail the billingEmail to set
	 */
	public void setBillingEmail(String billingEmail) {
		this.billingEmail = billingEmail;
	}

	/**
	 * @return the billingAddr
	 */
	public String getBillingAddr() {
		return billingAddr;
	}

	/**
	 * @param billingAddr the billingAddr to set
	 */
	public void setBillingAddr(String billingAddr) {
		this.billingAddr = billingAddr;
	}

	/**
	 * @return the billingCity
	 */
	public String getBillingCity() {
		return billingCity;
	}

	/**
	 * @param billingCity the billingCity to set
	 */
	public void setBillingCity(String billingCity) {
		this.billingCity = billingCity;
	}

	/**
	 * @return the billingState
	 */
	public String getBillingState() {
		return billingState;
	}

	/**
	 * @param billingState the billingState to set
	 */
	public void setBillingState(String billingState) {
		this.billingState = billingState;
	}

	/**
	 * @return the billingPostCd
	 */
	public String getBillingPostCd() {
		return billingPostCd;
	}

	/**
	 * @param billingPostCd the billingPostCd to set
	 */
	public void setBillingPostCd(String billingPostCd) {
		this.billingPostCd = billingPostCd;
	}

	/**
	 * @return the billingCountry
	 */
	public String getBillingCountry() {
		return billingCountry;
	}

	/**
	 * @param billingCountry the billingCountry to set
	 */
	public void setBillingCountry(String billingCountry) {
		this.billingCountry = billingCountry;
	}

	/**
	 * @return the deliveryNm
	 */
	public String getDeliveryNm() {
		return deliveryNm;
	}

	/**
	 * @param deliveryNm the deliveryNm to set
	 */
	public void setDeliveryNm(String deliveryNm) {
		this.deliveryNm = deliveryNm;
	}

	/**
	 * @return the deliveryPhone
	 */
	public String getDeliveryPhone() {
		return deliveryPhone;
	}

	/**
	 * @param deliveryPhone the deliveryPhone to set
	 */
	public void setDeliveryPhone(String deliveryPhone) {
		this.deliveryPhone = deliveryPhone;
	}

	/**
	 * @return the deliveryAddr
	 */
	public String getDeliveryAddr() {
		return deliveryAddr;
	}

	/**
	 * @param deliveryAddr the deliveryAddr to set
	 */
	public void setDeliveryAddr(String deliveryAddr) {
		this.deliveryAddr = deliveryAddr;
	}

	/**
	 * @return the deliveryCity
	 */
	public String getDeliveryCity() {
		return deliveryCity;
	}

	/**
	 * @param deliveryCity the deliveryCity to set
	 */
	public void setDeliveryCity(String deliveryCity) {
		this.deliveryCity = deliveryCity;
	}

	/**
	 * @return the deliveryState
	 */
	public String getDeliveryState() {
		return deliveryState;
	}

	/**
	 * @param deliveryState the deliveryState to set
	 */
	public void setDeliveryState(String deliveryState) {
		this.deliveryState = deliveryState;
	}

	/**
	 * @return the deliveryPostCd
	 */
	public String getDeliveryPostCd() {
		return deliveryPostCd;
	}

	/**
	 * @param deliveryPostCd the deliveryPostCd to set
	 */
	public void setDeliveryPostCd(String deliveryPostCd) {
		this.deliveryPostCd = deliveryPostCd;
	}

	/**
	 * @return the deliveryCountry
	 */
	public String getDeliveryCountry() {
		return deliveryCountry;
	}

	/**
	 * @param deliveryCountry the deliveryCountry to set
	 */
	public void setDeliveryCountry(String deliveryCountry) {
		this.deliveryCountry = deliveryCountry;
	}

	/**
	 * @return the dbProcessUrl
	 */
	public String getDbProcessUrl() {
		return dbProcessUrl;
	}

	/**
	 * @param dbProcessUrl the dbProcessUrl to set
	 */
	public void setDbProcessUrl(String dbProcessUrl) {
		this.dbProcessUrl = dbProcessUrl;
	}

	/**
	 * @return the vat
	 */
	public String getVat() {
		return vat;
	}

	/**
	 * @param vat the vat to set
	 */
	public void setVat(String vat) {
		this.vat = vat;
	}

	/**
	 * @return the fee
	 */
	public String getFee() {
		return fee;
	}

	/**
	 * @param fee the fee to set
	 */
	public void setFee(String fee) {
		this.fee = fee;
	}

	/**
	 * @return the notaxAmt
	 */
	public String getNotaxAmt() {
		return notaxAmt;
	}

	/**
	 * @param notaxAmt the notaxAmt to set
	 */
	public void setNotaxAmt(String notaxAmt) {
		this.notaxAmt = notaxAmt;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the reqDt
	 */
	public String getReqDt() {
		return reqDt;
	}

	/**
	 * @param reqDt the reqDt to set
	 */
	public void setReqDt(String reqDt) {
		this.reqDt = reqDt;
	}

	/**
	 * @return the reqTm
	 */
	public String getReqTm() {
		return reqTm;
	}

	/**
	 * @param reqTm the reqTm to set
	 */
	public void setReqTm(String reqTm) {
		this.reqTm = reqTm;
	}

	/**
	 * @return the reqDomain
	 */
	public String getReqDomain() {
		return reqDomain;
	}

	/**
	 * @param reqDomain the reqDomain to set
	 */
	public void setReqDomain(String reqDomain) {
		this.reqDomain = reqDomain;
	}

	/**
	 * @return the reqServerIP
	 */
	public String getReqServerIP() {
		return reqServerIP;
	}

	/**
	 * @param reqServerIP the reqServerIP to set
	 */
	public void setReqServerIP(String reqServerIP) {
		this.reqServerIP = reqServerIP;
	}

	/**
	 * @return the reqClientVer
	 */
	public String getReqClientVer() {
		return reqClientVer;
	}

	/**
	 * @param reqClientVer the reqClientVer to set
	 */
	public void setReqClientVer(String reqClientVer) {
		this.reqClientVer = reqClientVer;
	}

	/**
	 * @return the userIP
	 */
	public String getUserIP() {
		return userIP;
	}

	/**
	 * @param userIP the userIP to set
	 */
	public void setUserIP(String userIP) {
		this.userIP = userIP;
	}

	/**
	 * @return the userSessionID
	 */
	public String getUserSessionID() {
		return userSessionID;
	}

	/**
	 * @param userSessionID the userSessionID to set
	 */
	public void setUserSessionID(String userSessionID) {
		this.userSessionID = userSessionID;
	}

	/**
	 * @return the userAgent
	 */
	public String getUserAgent() {
		return userAgent;
	}

	/**
	 * @param userAgent the userAgent to set
	 */
	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	/**
	 * @return the userLanguage
	 */
	public String getUserLanguage() {
		return userLanguage;
	}

	/**
	 * @param userLanguage the userLanguage to set
	 */
	public void setUserLanguage(String userLanguage) {
		this.userLanguage = userLanguage;
	}

	/**
	 * @return the cartData
	 */
	public String getCartData() {
		return cartData;
	}

	/**
	 * @param cartData the cartData to set
	 */
	public void setCartData(String cartData) {
		this.cartData = cartData;
	}

	/**
	 * @return the sellers
	 */
	public String getSellers() {
		return sellers;
	}

	/**
	 * @param sellers the sellers to set
	 */
	public void setSellers(String sellers) {
		this.sellers = sellers;
	}

	/**
	 * @return the merFixAcctId
	 */
	public String getMerFixAcctId() {
		return merFixAcctId;
	}

	/**
	 * @param merFixAcctId the merFixAcctId to set
	 */
	public void setMerFixAcctId(String merFixAcctId) {
		this.merFixAcctId = merFixAcctId;
	}

	/**
	 * @return the vacctValidDt
	 */
	public String getVacctValidDt() {
		return vacctValidDt;
	}

	/**
	 * @param vacctValidDt the vacctValidDt to set
	 */
	public void setVacctValidDt(String vacctValidDt) {
		this.vacctValidDt = vacctValidDt;
	}

	/**
	 * @return the vacctValidTm
	 */
	public String getVacctValidTm() {
		return vacctValidTm;
	}

	/**
	 * @param vacctValidTm the vacctValidTm to set
	 */
	public void setVacctValidTm(String vacctValidTm) {
		this.vacctValidTm = vacctValidTm;
	}

	/**
	 * @return the bankCd
	 */
	public String getBankCd() {
		return bankCd;
	}

	/**
	 * @param bankCd the bankCd to set
	 */
	public void setBankCd(String bankCd) {
		this.bankCd = bankCd;
	}

	/**
	 * @return the cardNo
	 */
	public String getCardNo() {
		return cardNo;
	}

	/**
	 * @param cardNo the cardNo to set
	 */
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	/**
	 * @return the cardExpYymm
	 */
	public String getCardExpYymm() {
		return cardExpYymm;
	}

	/**
	 * @param cardExpYymm the cardExpYymm to set
	 */
	public void setCardExpYymm(String cardExpYymm) {
		this.cardExpYymm = cardExpYymm;
	}

	/**
	 * @return the cardCvv
	 */
	public String getCardCvv() {
		return cardCvv;
	}

	/**
	 * @param cardCvv the cardCvv to set
	 */
	public void setCardCvv(String cardCvv) {
		this.cardCvv = cardCvv;
	}

	/**
	 * @return the cavv
	 */
	public String getCavv() {
		return cavv;
	}

	/**
	 * @param cavv the cavv to set
	 */
	public void setCavv(String cavv) {
		this.cavv = cavv;
	}

	/**
	 * @return the eci
	 */
	public String getEci() {
		return eci;
	}

	/**
	 * @param eci the eci to set
	 */
	public void setEci(String eci) {
		this.eci = eci;
	}

	/**
	 * @return the xid
	 */
	public String getXid() {
		return xid;
	}

	/**
	 * @param xid the xid to set
	 */
	public void setXid(String xid) {
		this.xid = xid;
	}

	/**
	 * @return the trxId
	 */
	public String getTrxId() {
		return trxId;
	}

	/**
	 * @param trxId the trxId to set
	 */
	public void setTrxId(String trxId) {
		this.trxId = trxId;
	}

	/**
	 * @return the cancelType
	 */
	public String getCancelType() {
		return cancelType;
	}

	/**
	 * @param cancelType the cancelType to set
	 */
	public void setCancelType(String cancelType) {
		this.cancelType = cancelType;
	}

	/**
	 * @return the cancelMsg
	 */
	public String getCancelMsg() {
		return cancelMsg;
	}

	/**
	 * @param cancelMsg the cancelMsg to set
	 */
	public void setCancelMsg(String cancelMsg) {
		this.cancelMsg = cancelMsg;
	}

	/**
	 * @return the cancelUserId
	 */
	public String getCancelUserId() {
		return cancelUserId;
	}

	/**
	 * @param cancelUserId the cancelUserId to set
	 */
	public void setCancelUserId(String cancelUserId) {
		this.cancelUserId = cancelUserId;
	}

	/**
	 * @return the cancelUserInfo
	 */
	public String getCancelUserInfo() {
		return cancelUserInfo;
	}

	/**
	 * @param cancelUserInfo the cancelUserInfo to set
	 */
	public void setCancelUserInfo(String cancelUserInfo) {
		this.cancelUserInfo = cancelUserInfo;
	}

	/**
	 * @return the cancelRetryCnt
	 */
	public String getCancelRetryCnt() {
		return cancelRetryCnt;
	}

	/**
	 * @param cancelRetryCnt the cancelRetryCnt to set
	 */
	public void setCancelRetryCnt(String cancelRetryCnt) {
		this.cancelRetryCnt = cancelRetryCnt;
	}

	/**
	 * @return the worker
	 */
	public String getWorker() {
		return worker;
	}

	/**
	 * @param worker the worker to set
	 */
	public void setWorker(String worker) {
		this.worker = worker;
	}

	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}

	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}

	/**
	 * @return the cardExpiry
	 */
	public String getCardExpiry() {
		return cardExpiry;
	}

	/**
	 * @param cardExpiry the cardExpiry to set
	 */
	public void setCardExpiry(String cardExpiry) {
		this.cardExpiry = cardExpiry;
	}

	/**
	 * @return the onePassToken
	 */
	public String getOnePassToken() {
		return onePassToken;
	}

	/**
	 * @param onePassToken the onePassToken to set
	 */
	public void setOnePassToken(String onePassToken) {
		this.onePassToken = onePassToken;
	}

	/**
	 * @return the recurringToken
	 */
	public String getRecurringToken() {
		return recurringToken;
	}

	/**
	 * @param recurringToken the recurringToken to set
	 */
	public void setRecurringToken(String recurringToken) {
		this.recurringToken = recurringToken;
	}

	/**
	 * @return the preauthToken
	 */
	public String getPreauthToken() {
		return preauthToken;
	}

	/**
	 * @param preauthToken the preauthToken to set
	 */
	public void setPreauthToken(String preauthToken) {
		this.preauthToken = preauthToken;
	}

	/**
	 * @return the customerID
	 */
	public String getCustomerID() {
		return customerID;
	}

	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	/**
	 * @return the customerNm
	 */
	public String getCustomerNm() {
		return customerNm;
	}

	/**
	 * @param customerNm the customerNm to set
	 */
	public void setCustomerNm(String customerNm) {
		this.customerNm = customerNm;
	}

	/**
	 * @return the vaNumber
	 */
	public String getVaNumber() {
		return vaNumber;
	}

	/**
	 * @param vaNumber the vaNumber to set
	 */
	public void setVaNumber(String vaNumber) {
		this.vaNumber = vaNumber;
	}

	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the recurrOpt
	 */
	public String getRecurrOpt() {
		return recurrOpt;
	}

	/**
	 * @param recurrOpt the recurrOpt to set
	 */
	public void setRecurrOpt(String recurrOpt) {
		this.recurrOpt = recurrOpt;
	}

	/**
	 * @return the cardHolderNm
	 */
	public String getCardHolderNm() {
		return cardHolderNm;
	}

	/**
	 * @param cardHolderNm the cardHolderNm to set
	 */
	public void setCardHolderNm(String cardHolderNm) {
		this.cardHolderNm = cardHolderNm;
	}

	/**
	 * @return the mitraCd
	 */
	public String getMitraCd() {
		return mitraCd;
	}

	/**
	 * @param mitraCd the mitraCd to set
	 */
	public void setMitraCd(String mitraCd) {
		this.mitraCd = mitraCd;
	}

	/**
	 * @return the payValidDt
	 */
	public String getPayValidDt() {
		return payValidDt;
	}

	/**
	 * @param payValidDt the payValidDt to set
	 */
	public void setPayValidDt(String payValidDt) {
		this.payValidDt = payValidDt;
	}

	/**
	 * @return the payValidTm
	 */
	public String getPayValidTm() {
		return payValidTm;
	}

	/**
	 * @param payValidTm the payValidTm to set
	 */
	public void setPayValidTm(String payValidTm) {
		this.payValidTm = payValidTm;
	}

	/**
	 * @return the clickPayNo
	 */
	public String getClickPayNo() {
		return clickPayNo;
	}

	/**
	 * @param clickPayNo the clickPayNo to set
	 */
	public void setClickPayNo(String clickPayNo) {
		this.clickPayNo = clickPayNo;
	}

	/**
	 * @return the dataField3
	 */
	public String getDataField3() {
		return dataField3;
	}

	/**
	 * @param dataField3 the dataField3 to set
	 */
	public void setDataField3(String dataField3) {
		this.dataField3 = dataField3;
	}

	/**
	 * @return the clickPayToken
	 */
	public String getClickPayToken() {
		return clickPayToken;
	}

	/**
	 * @param clickPayToken the clickPayToken to set
	 */
	public void setClickPayToken(String clickPayToken) {
		this.clickPayToken = clickPayToken;
	}

	public void setReq(String name, String value) {
		htRequest.put(name, value);
	}

	public String getReq(String name) {
		return htResponse.get(name);
	}

	public void register() throws Exception {
		setFunctionType(1);

		// Mandatory Field
		HashMap<String, String> dataMapper = new HashMap<String, String>();
		dataMapper.put("timeStamp", timeStamp);
		dataMapper.put("iMid", merchantID);
		dataMapper.put("payMethod", payMethod);
		dataMapper.put("currency", currency);
		dataMapper.put("amt", amt);
		dataMapper.put("referenceNo", referenceNo);
		dataMapper.put("goodsNm", goodsNm);
		dataMapper.put("billingNm", billingNm);
		dataMapper.put("billingPhone", billingPhone);
		dataMapper.put("billingEmail", billingEmail);
		dataMapper.put("billingAddr", billingAddr);
		dataMapper.put("billingCity", billingCity);
		dataMapper.put("billingState", billingState);
		dataMapper.put("billingPostCd", billingPostCd);
		dataMapper.put("billingCountry", billingCountry);
		dataMapper.put("deliveryNm", deliveryNm);
		dataMapper.put("deliveryPhone", deliveryPhone);
		dataMapper.put("deliveryAddr", deliveryAddr);
		dataMapper.put("deliveryCity", deliveryCity);
		dataMapper.put("deliveryState", deliveryState);
		dataMapper.put("deliveryPostCd", deliveryPostCd);
		dataMapper.put("deliveryCountry", deliveryCountry);
		dataMapper.put("dbProcessUrl", dbProcessUrl);
		dataMapper.put("vat", vat);
		dataMapper.put("fee", fee);
		dataMapper.put("notaxAmt", notaxAmt);
		dataMapper.put("description", description);
		dataMapper.put("merchantToken", merchantToken);
		dataMapper.put("userIP", userIP);
		dataMapper.put("cartData", cartData);
		dataMapper.put("sellers", sellers);
		dataMapper.put("recurrOpt", recurrOpt);

		// Optional Field
		dataMapper.put("reqDt", reqDt);
		dataMapper.put("reqTm", reqTm);
		dataMapper.put("reqDomain", reqDomain);
		dataMapper.put("reqServerIP", reqServerIP);
		dataMapper.put("reqClientVer", reqClientVer);
		dataMapper.put("userSessionID", userSessionID);
		dataMapper.put("userAgent", userAgent);
		dataMapper.put("userLanguage", userLanguage);
		// setReq("merFixAcctId", merFixAcctId);
		// setReq("vacctValidDt", vacctValidDt);
		// setReq("vacctValidTm", vacctValidTm);

		dataMapper.put("instmntType", instmntType);

		// Specific Field
		if (payMethod.equals("01")) {
			dataMapper.put("cardCvv", cardCvv);
			dataMapper.put("instmntMon", instmntMon);
			dataMapper.put("onePassToken", onePassToken);
		} else if (payMethod.equals("02")) {
			dataMapper.put("bankCd", bankCd);
		} else if (payMethod.equals("03")) {
			dataMapper.put("mitraCd", mitraCd);
			dataMapper.put("payValidDt", payValidDt);
			dataMapper.put("payValidTm", payValidTm);
		} else if (payMethod.equals("04")) {
			dataMapper.put("mitraCd", mitraCd);
			dataMapper.put("clickPayNo", clickPayNo);
			dataMapper.put("dataField3", dataField3);
			dataMapper.put("clickPayToken", clickPayToken);
		} else if (payMethod.equals("06")) {
			dataMapper.put("mitraCd", mitraCd);
			dataMapper.put("payValidDt", payValidDt);
			dataMapper.put("payValidTm", payValidTm);
			dataMapper.put("instmntMon", instmntMon);
		} else if (payMethod.equals("05")) {
			dataMapper.put("mitraCd", mitraCd);
			dataMapper.put("payValidDt", payValidDt);
			dataMapper.put("payValidTm", payValidTm);
			dataMapper.put("instmntMon", instmntMon);
		} else {
			dataMapper.put("mitraCd", mitraCd);
			dataMapper.put("bankCd", bankCd);
			dataMapper.put("cardCvv", cardCvv);
			dataMapper.put("instmntType", instmntType);
			dataMapper.put("instmntMon", instmntMon);
			dataMapper.put("onePassToken", onePassToken);
			dataMapper.put("payValidDt", payValidDt);
			dataMapper.put("payValidTm", payValidTm);
		}

		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(dataMapper);

		System.out.println("Test :  " + jsonInString);

		sendToPG(getFunctionType(), jsonInString);
	}

	public void registerV2() throws Exception {
		setFunctionType(2);

		// Mandatory Field
		setReq("iMid", merchantID);
		setReq("payMethod", payMethod);
		setReq("currency", currency);
		setReq("amt", amt);
		setReq("referenceNo", referenceNo);
		setReq("goodsNm", goodsNm);
		setReq("billingNm", billingNm);
		setReq("billingPhone", billingPhone);
		setReq("billingEmail", billingEmail);
		setReq("billingAddr", billingAddr);
		setReq("billingCity", billingCity);
		setReq("billingState", billingState);
		setReq("billingPostCd", billingPostCd);
		setReq("billingCountry", billingCountry);
		setReq("deliveryNm", deliveryNm);
		setReq("deliveryPhone", deliveryPhone);
		setReq("deliveryAddr", deliveryAddr);
		setReq("deliveryCity", deliveryCity);
		setReq("deliveryState", deliveryState);
		setReq("deliveryPostCd", deliveryPostCd);
		setReq("deliveryCountry", deliveryCountry);
		setReq("dbProcessUrl", dbProcessUrl);
		setReq("vat", vat);
		setReq("fee", fee);
		setReq("notaxAmt", notaxAmt);
		setReq("description", description);
		setReq("merchantToken", merchantToken);
		setReq("userIP", userIP);
		setReq("cartData", cartData);
		setReq("sellers", sellers);
		setReq("recurrOpt", recurrOpt);

		// Optional Field
		setReq("reqDt", reqDt);
		setReq("reqTm", reqTm);
		setReq("reqDomain", reqDomain);
		setReq("reqServerIP", reqServerIP);
		setReq("reqClientVer", reqClientVer);
		setReq("userSessionID", userSessionID);
		setReq("userAgent", userAgent);
		setReq("userLanguage", userLanguage);
		// setReq("merFixAcctId", merFixAcctId);
		// setReq("vacctValidDt", vacctValidDt);
		// setReq("vacctValidTm", vacctValidTm);

		setReq("instmntType", instmntType);
		setReq("callBackUrl", callBack);

		// Specific Field
		if (payMethod.equals("01")) {
			setReq("cardCvv", cardCvv);
			setReq("instmntMon", instmntMon);
			setReq("onePassToken", onePassToken);
		} else if (payMethod.equals("02")) {
			setReq("bankCd", bankCd);
		} else if (payMethod.equals("03")) {
			setReq("mitraCd", mitraCd);
			setReq("payValidDt", payValidDt);
			setReq("payValidTm", payValidTm);
		} else if (payMethod.equals("04")) {
			setReq("mitraCd", mitraCd);
			setReq("clickPayNo", clickPayNo);
			setReq("dataField3", dataField3);
			setReq("clickPayToken", clickPayToken);
		} else if (payMethod.equals("06")) {
			setReq("mitraCd", mitraCd);
			setReq("payValidDt", payValidDt);
			setReq("payValidTm", payValidTm);
			setReq("instmntMon", instmntMon);
		} else {
			setReq("mitraCd", mitraCd);
			setReq("bankCd", bankCd);
			setReq("cardCvv", cardCvv);
			setReq("instmntType", instmntType);
			setReq("instmntMon", instmntMon);
			setReq("onePassToken", onePassToken);
			setReq("payValidDt", payValidDt);
			setReq("payValidTm", payValidTm);
		}

		List<NameValuePair> json = cmn.ListParam(htRequest);
		htRequest.clear();

		sendToPG2(getFunctionType(), json);
	}

	public void checkPaymentStatus() throws Exception {
		setFunctionType(3);

		setReq("tXid", trxId);
		setReq("amt", amt);
		setReq("referenceNo", referenceNo);
		setReq("merchantKey", merchantKey);
		setReq("iMid", merchantID);
		setReq("merchantToken", makeTokenV1(amt,referenceNo));

		List<NameValuePair> json = cmn.ListParam(htRequest);
		htRequest.clear();

		sendToPG2(getFunctionType(), json);
	}
	public void cancelPayment() throws Exception {
		setFunctionType(4);

		setReq("iMid", merchantID);
		setReq("merchantKey", merchantKey);
		setReq("merchantToken", makeTokenCancel(trxId, amt));
		setReq("tXid", trxId);
		setReq("amt", amt);
		setReq("payMethod", payMethod);
		setReq("cancelType", cancelType);

		List<NameValuePair> json = cmn.ListParam(htRequest);
		htRequest.clear();

		sendToPG2(getFunctionType(), json);
	}

	public void sendToPG(int instructionType, String param) throws SecurityException, IOException {
		// When use HTTPClient 4.3
		/*
		 * RequestConfig requestConfig = RequestConfig.custom() .setSocketTimeout(30000)
		 * .setConnectTimeout(30000) .build();
		 */
		try {
			String url;

			if (isbDebug()) {
				switch (instructionType) {
				case 1:
					url = urlLocalRegis;
					break;
				case 2:
					url = urlLocalRegisV1;
					break;
				case 3:
					url = urlLocalCheckPayment;
					break;
				case 4:
					url = urlLocalCancelPayment;
					break;
				default:
					url = urlLocalRegis;
					break;
				}
			} else {
				switch (instructionType) {
				case 1:
					url = urlRealRegis;
					break;
				case 2:
					url = urlRealRegisV1;
					break;
				default:
					url = urlRealRegis;
					break;
				}
			}

			// When use HTTPClient 4.2
			HttpParams params = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(params, 90 * 1000);
			HttpConnectionParams.setSoTimeout(params, 30 * 1000);
			HttpClient httpclient = new DefaultHttpClient(params);
			
			System.out.println("url :"+url);

			// UrlEncodedFormEntity entity = new UrlEncodedFormEntity(param, "UTF-8");
			HttpPost httpPost = new HttpPost(url);
			StringEntity paramNew = new StringEntity(param);
			System.out.println("Param: " + param);
			System.out.println("Param New: " + paramNew);
			httpPost.addHeader("content-type", "application/json");
			httpPost.setEntity(paramNew);
			// httpPost.setConfig(requestConfig); //When use HTTPClient 4.3

			HttpResponse response = null;

			try {
				response = httpclient.execute(httpPost);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("wait 2sec");
				Thread.sleep(2000);
				response = httpclient.execute(httpPost);
			}

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}

			System.out.println("Result Value : " + instructionType);
			if (instructionType == 5) {
				// for remove length
				setResponseString(result.toString().substring(4));
			} else if (instructionType == 12) {

				if (result.toString().startsWith("(")) {
					result.delete(0, 1);
				}
				if (result.toString().endsWith(")")) {
					result.delete(result.length() - 1, result.length());
				}
				setResponseString(result.toString());
			} else {
				setResponseString(result.toString());
			}

			setHtResponse(cmn.parseJSON(getResponseString()));

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (ClientAbortException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	public void sendToPG2(int instructionType, List<NameValuePair> json) throws SecurityException, IOException {
		try {
			String url;

			if (isbDebug()) {
				switch (instructionType) {
					case 1:
						url = urlLocalRegis;
						break;
					case 2:
						url = urlLocalRegisV1;
						break;
					case 3:
						url = urlLocalCheckPayment;
						break;
					case 4:
						url = urlLocalCancelPayment;
						break;
					default:
						url = urlLocalRegis;
						break;
				}
			} else {
				switch (instructionType) {
				case 1:
					url = urlRealRegis;
					break;
				case 2:
					url = urlRealRegisV1;
					break;
				default:
					url = urlRealRegis;
					break;
				}
			}

			// When use HTTPClient 4.2
			HttpParams params = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(params, 90 * 1000);
			HttpConnectionParams.setSoTimeout(params, 30 * 1000);
			HttpClient httpclient = new DefaultHttpClient(params);

			UrlEncodedFormEntity entity = new UrlEncodedFormEntity(json, "UTF-8");
			HttpPost httpPost = new HttpPost(url);
			httpPost.setEntity(entity);
			System.out.println("entity : " + json);
			// httpPost.setConfig(requestConfig); //When use HTTPClient 4.3

			HttpResponse response = null;

			try {
				response = httpclient.execute(httpPost);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("wait 2sec");
				Thread.sleep(2000);
				response = httpclient.execute(httpPost);
			}

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}

			System.out.println("Result Value : " + result);
			if (instructionType == 5) {
				// for remove length
				setResponseString(result.toString().substring(4));
			} else if (instructionType == 12) {

				if (result.toString().startsWith("(")) {
					result.delete(0, 1);
				}
				if (result.toString().endsWith(")")) {
					result.delete(result.length() - 1, result.length());
				}
				setResponseString(result.toString());
			} else {
				setResponseString(result.toString());
			}

			if(instructionType == 3 || instructionType == 4){
				setHtResponse(cmn.parseJSON(getResponseString()));
			} else {
				setHtResponse(cmn.parseJSON2(getResponseString()));
			}

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (ClientAbortException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	public String Get(String string) {
		return null;
	}
}