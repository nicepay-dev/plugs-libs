package com.nicepay.demo.controller;

import com.nicepay.demo.lib.NicepayLib;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.Hashtable;

@Controller
public class EWalletController {


    @RequestMapping(value = "/eWalletSubmit", method = RequestMethod.POST)
    public ModelAndView sendRequest(HttpSession httpSession, Model model, @RequestParam("referenceNo") String referenceNo,
                                    @RequestParam("amt") String amt, String paymentExpDt, String paymentExpTm) throws Exception {
        Util util = new Util();

        String iMid = httpSession.getAttribute("iMid").toString();
        String merchantKey = httpSession.getAttribute("merchantKey").toString();
        NicepayLib nicePay = new NicepayLib(iMid, merchantKey, true);

        String timeStamp = util.timeUtil();

        nicePay.setTimeStamp(timeStamp);
        nicePay.setPayMethod("05");// SET THIS
        nicePay.setCurrency("IDR");
        nicePay.setAmt(amt);
        nicePay.setReferenceNo(referenceNo);
        nicePay.setGoodsNm("Test Transaction Ewallet");
        nicePay.setBillingNm("John Doe");
        nicePay.setBillingEmail("johndoe@nicepay.com");
        nicePay.setBillingPhone("081219836581");
        nicePay.setBillingAddr("Jalan Jend. Soedirman");
        nicePay.setBillingCity("Jakarta");
        nicePay.setBillingState("Jakarta");
        nicePay.setBillingPostCd("12345");
        nicePay.setBillingCountry("Indonesia");
        nicePay.setDeliveryNm("John Doe");
        nicePay.setDeliveryPhone("081211111111");
        nicePay.setDeliveryAddr("Jalan Jend. Soedirman");
        nicePay.setDeliveryCity("Jakarta");
        nicePay.setDeliveryState("Jakarta");
        nicePay.setDeliveryPostCd("12345");
        nicePay.setDeliveryCountry("Indonesia");
        nicePay.setDbProcessUrl("https://ptsv2.com/t/rizal/post");
        nicePay.setCallBack("http://localhost:8080/result");
        nicePay.setVat("0");
        nicePay.setFee("0");
        nicePay.setNotaxAmt("0");
        nicePay.setDescription("Test Transaction Ewallet");
        nicePay.setUserIP(util.ipUtil().getHostAddress());
        nicePay.setMerchantToken(nicePay.makeTokenV1(nicePay.getAmt(), nicePay.getReferenceNo()));
        nicePay.setCartData("{\"count\": \"1\",\"item\": [{\"img_url\": \"https://www.lecs.com/image/introduction/img_vmd020101.jpg\",\"goods_name\": \"Air Jordan III OG\",\"goods_detail\": \"An item of footwear intended to protect and comfort the human foot.\",\"goods_amt\":" + "\"" + amt + "\",\"goods_quantity\": \"1\"}]}");
        // Payment Page Optional Field
        //        nicePay.setReqDt(util.timeUtil().substring(0, 8));
        //        nicePay.setReqTm(util.timeUtil().substring(8, 14));
        nicePay.setReqDomain("nicepay.co.id");
        nicePay.setReqServerIP(util.ipUtil().getHostAddress());
        nicePay.setReqClientVer("");
        nicePay.setUserSessionID("697D6922C961070967D3BA1BA5699C2C");
        nicePay.setUserAgent("Mozilla");
        nicePay.setUserLanguage("en-US");

        //		   nicePay.setPayValidDt("");
        nicePay.setPayExpiredDt(util.addTenMinutes().substring(0, 8)); // set for DANA and LinkAja
        nicePay.setPayExpiredTm(util.addTenMinutes().substring(8, 14)); // default 5 minute

        //		   nicePay.setInstmntMon(instmntMon);
        //		   nicePay.setInstmntType(instmntType);
        //		   nicePay.setRecurrOpt("2");
        // 		   nicePay.setMitraCd(mitraCd);

        nicePay.registerV2();

        Hashtable<String, String> temp = nicePay.getHtResponse(); // JSON in HashTable<String, String> format

        System.out.println("Result Code : " + temp.get("resultCd"));
        System.out.println("Result Msg : " + temp.get("resultMsg"));
        System.out.println("TxID : " + temp.get("tXid"));
        System.out.println("Amount : " + temp.get("amt"));
        System.out.println("Reference No : " + temp.get("referenceNo"));
        System.out.println("RequestUrl : " + temp.get("requestURL"));
        //// End Testing
        //
        // // -------

/*        model.addAttribute("resultMsg", temp.get("resultMsg"));
        model.addAttribute("tXid", temp.get("tXid"));
        model.addAttribute("amt", temp.get("amt"));
        model.addAttribute("referenceNo", temp.get("referenceNo"));
        model.addAttribute("vacctValidDt", temp.get("vacctValidDt"));*/

        String redirectPaymentPage = temp.get("requestURL")+"?tXid="+temp.get("tXid")+"&optDisplayCB=1";

        return new ModelAndView("redirect:" + redirectPaymentPage);
    }   
}