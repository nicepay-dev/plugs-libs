// package com.nicepay.demo;

// import org.springframework.stereotype.Controller;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.ResponseBody;

// @Controller
// class Example {
//    @RequestMapping("/")
//    @ResponseBody
//    public String hello() {
//       return "Hello Spring Boot";
//    }
// }