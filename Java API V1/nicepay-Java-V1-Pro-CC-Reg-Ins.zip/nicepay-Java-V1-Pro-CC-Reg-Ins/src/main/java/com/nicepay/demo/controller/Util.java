package com.nicepay.demo.controller;

import org.springframework.stereotype.Controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


@Controller
public class Util {

    public String timeUtil() {
        Date begin = new Date();
        String time = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(begin);
        System.out.println("Transaction Time : " + time);
        return time;
    }

    public String calendarUtil() {
        Date begin = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(begin);
        cal.add(Calendar.MINUTE, 5);
        String newTime = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(cal.getTime());
        System.out.println("Expiry Time : " + newTime);
        return newTime;
    }

    public InetAddress ipUtil() {
        InetAddress ip = null;
        try {
            ip = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return ip;
    }

    public String bankName(String bankCd) {
        String bankName = "";
        if( bankCd.equals("BMRI") ){
            bankName = "Mandiri";
        } else if( bankCd.equals("BNIN") ){
            bankName = "BNI";
        } else if( bankCd.equals("BRIN") ){
            bankName = "BRI";
        } else if( bankCd.equals("IBBK") ){
            bankName = "Maybank";
        } else if( bankCd.equals("BBBA") ){
            bankName = "Permata";
        } else if( bankCd.equals("CENA") ){
            bankName = "BCA";
        } else if( bankCd.equals("HNBN") ){
            bankName = "Hana Indonesia";
        } else if( bankCd.equals("BNIA") ){
            bankName = "Cimb Niaga";
        } else if( bankCd.equals("BDIN") ){
            bankName = "Danamon";
        }

        return bankName;
    }
}
