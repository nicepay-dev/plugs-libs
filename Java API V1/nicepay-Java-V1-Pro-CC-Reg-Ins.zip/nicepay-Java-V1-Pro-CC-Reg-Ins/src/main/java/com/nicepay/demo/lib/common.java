package com.nicepay.demo.lib;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import org.apache.http.message.BasicNameValuePair;
import org.apache.http.NameValuePair;

public class common {
    
	
	public common(){
		super();
	}
	

	
	public List<NameValuePair> ListParam(Hashtable<String, String> ht) throws Exception {
		Object[] keyArray = ht.keySet().toArray();
		Object[] valueArray = ht.values().toArray();

		String[] strKeyArray = new String[keyArray.length];
		String[] strValueArray = new String[valueArray.length];
		List<NameValuePair> formParams = new ArrayList<NameValuePair>();
		
		for (int i = 0; i < keyArray.length; i++)
		{
			strKeyArray[i] = new String((String) keyArray[i]);
			strValueArray[i] = new String((String) valueArray[i]);
			formParams.add(new BasicNameValuePair(strKeyArray[i], strValueArray[i]));
		}
			    
	    return formParams;
	}
	
	public Hashtable<String, String> parseJSON(String str) throws Exception {
		Hashtable<String, String> result = new Hashtable<String, String>();
		
		String str2;
		str2 = str;
		// str2 = str.substring(4);   //wor
		JsonFactory factory = new JsonFactory();
		JsonParser  parser  = factory.createParser(str2);
		
		String val = "";
		String nm = "";
		JsonToken jsonToken = parser.getCurrentToken();
		System.out.println("jsonTo : " + jsonToken);
		while (jsonToken != JsonToken.END_OBJECT){		    
		    nm = parser.getCurrentName();
		    
		    if(jsonToken == JsonToken.START_ARRAY){
		    	val = "{";
		    	JsonToken jsonToken1 = jsonToken;
		    	
		    	while (jsonToken1 != JsonToken.END_ARRAY) {
		    		if(jsonToken1 == JsonToken.VALUE_STRING){
				    	val += "\"" + parser.getValueAsString() + "\",";
				    }else if (jsonToken1 == JsonToken.FIELD_NAME){
				    	val += "\"" + parser.getCurrentName() + "\":";
				    }
		    		
		    		jsonToken1 = parser.nextToken();

		    		if(jsonToken1 == JsonToken.END_ARRAY){
		    			val = val.substring(0, val.length()-1);
				    	val += "}";
				    	jsonToken = JsonToken.END_ARRAY;
				    }
		    	}
		    }
		    
		    if((jsonToken == JsonToken.VALUE_STRING) || (jsonToken == JsonToken.VALUE_NULL)){
		    	val = jsonToken == JsonToken.VALUE_NULL ? "" : parser.getValueAsString();
		    	result.put(nm, val);
		    }else if(jsonToken == JsonToken.END_ARRAY){
		    	result.put(nm, val);
		    }
		    jsonToken = parser.nextToken();
		}
					    
	    return result;
	}

	public Hashtable<String, String> parseJSON2(String str) throws Exception {
		Hashtable<String, String> result = new Hashtable<String, String>();
		
		String str2;
		str2 = str.substring(4);   //wor
		JsonFactory factory = new JsonFactory();
		JsonParser  parser  = factory.createParser(str2);
		
		String val = "";
		String nm = "";
		JsonToken jsonToken = parser.getCurrentToken();
		System.out.println("jsonTo : " + jsonToken);
		while (jsonToken != JsonToken.END_OBJECT){		    
		    nm = parser.getCurrentName();
		    
		    if(jsonToken == JsonToken.START_ARRAY){
		    	val = "{";
		    	JsonToken jsonToken1 = jsonToken;
		    	
		    	while (jsonToken1 != JsonToken.END_ARRAY) {
		    		if(jsonToken1 == JsonToken.VALUE_STRING){
				    	val += "\"" + parser.getValueAsString() + "\",";
				    }else if (jsonToken1 == JsonToken.FIELD_NAME){
				    	val += "\"" + parser.getCurrentName() + "\":";
				    }
		    		
		    		jsonToken1 = parser.nextToken();

		    		if(jsonToken1 == JsonToken.END_ARRAY){
		    			val = val.substring(0, val.length()-1);
				    	val += "}";
				    	jsonToken = JsonToken.END_ARRAY;
				    }
		    	}
		    }
		    
		    if((jsonToken == JsonToken.VALUE_STRING) || (jsonToken == JsonToken.VALUE_NULL)){
		    	val = jsonToken == JsonToken.VALUE_NULL ? "" : parser.getValueAsString();
		    	result.put(nm, val);
		    }else if(jsonToken == JsonToken.END_ARRAY){
		    	result.put(nm, val);
		    }
		    jsonToken = parser.nextToken();
		}
					    
	    return result;
	}
	
	public void printHTResult(Hashtable<String, String> result){
		Object[] keyArray = result.keySet().toArray();
		Object[] valueArray = result.values().toArray();

		String[] strKeyArray = new String[keyArray.length];
		String[] strValueArray = new String[valueArray.length];
		
		for (int i = 0; i < keyArray.length; i++)
		{
			strKeyArray[i] = new String((String) keyArray[i]);
			strValueArray[i] = new String((String) valueArray[i]);
			System.out.println(strKeyArray[i] + " : " + strValueArray[i]);
		}
	}

}