package com.nicepay.demo.controller;

import com.nicepay.demo.lib.NicepayLib;
import com.sun.org.apache.xpath.internal.operations.Mod;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Hashtable;

@Controller
public class StatusController {

    @RequestMapping(value = "/checkPayment")
    public ModelAndView checkPayment(HttpSession httpSession, Model model, @RequestParam String tXid,
                                     @RequestParam String amt,
                                     @RequestParam String referenceNo) throws Exception {
        String iMid = httpSession.getAttribute("iMid").toString();
        String merchantKey = httpSession.getAttribute("merchantKey").toString();

        NicepayLib nicePay = new NicepayLib(iMid, merchantKey, true);
        nicePay.setAmt(amt);
        nicePay.setTrxId(tXid);
        nicePay.setReferenceNo(referenceNo);

        nicePay.checkPaymentStatus();

        Hashtable<String, String> temp = nicePay.getHtResponse();
        model.addAttribute("result", temp);
        model.addAttribute("iMid", iMid);
        model.addAttribute("merchantKey", merchantKey);
        System.out.println("Temp: " + temp);

        ModelAndView modelAndView = new ModelAndView("otherErrorPage");
        String resultCd = temp.get("resultCd");
        System.out.println("Result: " + resultCd);

        if(resultCd.equals("0000")){
            modelAndView.setViewName("checkPaymentResult");
            return modelAndView;
        } else if (!resultCd.equals("0000")){
            modelAndView.setViewName("checkPaymentError");
            return modelAndView;
        }  else {
            model.addAttribute("errorMsg", "Connection Timeout. Please Try again.");
            return modelAndView;
        }
    }

    @RequestMapping(value = "/cancelPayment")
    public ModelAndView cancelPayment(HttpSession httpSession, Model model, @RequestParam String tXid,
                                     @RequestParam String amt,
                                     @RequestParam String cancelType,
                                     @RequestParam String payMethod) throws Exception {
        String iMid = httpSession.getAttribute("iMid").toString();
        String merchantKey = httpSession.getAttribute("merchantKey").toString();

        NicepayLib nicePay = new NicepayLib(iMid, merchantKey, true);

        nicePay.setAmt(amt);
        nicePay.setTrxId(tXid);
        nicePay.setPayMethod(payMethod);
        nicePay.setCancelType(cancelType);

        nicePay.cancelPayment();

        Hashtable<String, String> temp = nicePay.getHtResponse();
        model.addAttribute("result", temp);
        model.addAttribute("iMid", iMid);
        model.addAttribute("merchantKey", merchantKey);
        System.out.println("Temp: " + temp);

        ModelAndView modelAndView = new ModelAndView("otherErrorPage");
        String resultCd = temp.get("resultCd");
        System.out.println("Result: " + resultCd);

        if(resultCd.equals("0000")){
            modelAndView.setViewName("cancelResult");
            return modelAndView;
        } else if (!resultCd.equals("0000")){
            modelAndView.setViewName("cancelError");
            return modelAndView;
        }  else {
            model.addAttribute("errorMsg", "Connection Timeout. Please Try again.");
            return modelAndView;
        }
    }
}
