package com.nicepay.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.Map;

@Controller
public class WebController {

	@RequestMapping(value ={"","/","/index"})
	public ModelAndView index(HttpSession httpSession) {
        httpSession.setAttribute("iMid", "IONPAYTEST");
        httpSession.setAttribute("merchantKey", "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==");
      return new ModelAndView("index");
   }

    @RequestMapping(value = "/result", method = RequestMethod.GET)
    public String CreditCardRes(HttpSession httpSession, Model model, @RequestParam Map<String,String> query,
                                @RequestParam(required = false, defaultValue = "0") int offset,
                                @RequestParam(required = false, defaultValue = "10") int limit){
        model.addAttribute("result", query);
        model.addAttribute("iMid", httpSession.getAttribute("iMid"));
        model.addAttribute("merchantKey", httpSession.getAttribute("merchantKey"));
        return "result";
    }
}