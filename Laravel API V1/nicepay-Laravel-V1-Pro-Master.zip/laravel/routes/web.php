<?php
use Illuminate\Http\Request;
include_once(app_path() . '/Library/NicepayConfig.php');

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::view('/', 'welcome');
Route::view('cc', 'cc');
Route::view('va', 'va');
Route::view('cvs', 'cvs');
Route::view('cpay', 'cpay');
Route::view('ewallet', 'ewallet');
Route::view('payloan', 'payloan');

Route::any('result',function(Request $request){
    Session::flash('iMid', NICEPAY_IMID);
    Session::flash('merchantKey', NICEPAY_MERCHANT_KEY);
    return view ('result', $request->input());
});
Route::get('checkPaymentResult', function(Request $request){
    return view ('checkPaymentResult', $request->input());
})->name('checkPaymentResult');
Route::get('cancelResult', function(Request $request){
    return view ('cancelResult', $request->input());
})->name('cancelResult');
Route::get('otherError', function(Request $request){
    return view ('otherError', $request->input());
})->name('otherError');
Route::get('invoice', function(Request $request){
    return view ('invoice', $request->input());
})->name('invoice');


Route::post('chargeCC','ChargeCreditCard');
Route::post('requestVA','RequestVA');
Route::post('requestCVS','RequestCVS');
Route::post('requestCPay','RequestCPay');
Route::post('requestEWallet','RequestEWallet');
Route::post('requestPayloan','RequestPayloan');//NOT AVAILABLE in V1
Route::post('checkPayment','CheckPayment');
Route::post('cancelPayment', 'CancelPayment');
