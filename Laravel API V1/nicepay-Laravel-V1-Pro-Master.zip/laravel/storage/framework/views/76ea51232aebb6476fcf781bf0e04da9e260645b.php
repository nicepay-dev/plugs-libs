<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cancellation Result</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/index.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>
<body>

<div class="form-style-8" style="margin-top:5%;">
    <?php if(isset($resultCd) && $resultCd == "0000"): ?>
        <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="">Cancel Result</div>
        <div class="group">
            <input type="text" name="" value="<?php echo e($canceltXid); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Cancel Transaction ID</label>
        </div>
        <div class="group">
            <input type="text" name="" value="<?php echo e($resultMsg); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Message</label>
        </div>
        <div class="group">
            <input type="text" name="" value="<?php echo e($tXid); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Order Transaction ID</label>
        </div>
        <?php if(isset($amt)): ?>
            <div class="group">
                <input type="text" name="" value="<?php echo e($amt); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Cancel Amount</label>
            </div>
        <?php endif; ?>
        <div class="group">
            <input type="text" name="" value="<?php echo e($transDt); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Date</label>
        </div>
        <div class="group">
            <input type="text" name="" value="<?php echo e($transTm); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Time</label>
        </div>
    <?php elseif(isset($resultCd)): ?>
        <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="">Error!</div>
        <form action="index.html" method="get">
            <?php echo csrf_field(); ?>
            <div class="group">
                <input type="text" name="tXid" value="<?php echo e($resultCd); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Code</label>
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="<?php echo e($resultMsg); ?>">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Message</label>
            </div>
        </form>
    <?php endif; ?>
    <form action="/" method="get">
        <?php echo csrf_field(); ?>
        <input type="submit" value="Back To Checkout" formaction="/" />
    </form>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\Journey\resources\views\cancelResult.blade.php ENDPATH**/ ?>