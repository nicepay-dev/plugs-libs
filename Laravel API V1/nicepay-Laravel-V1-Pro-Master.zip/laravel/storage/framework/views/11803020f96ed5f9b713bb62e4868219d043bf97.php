<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Your order is being processed...</title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/css/index.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>

<body>

<div class="form-style-8" style="margin-top:5%;">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="<?php echo e(url('/img/nicepay_logo.jpg')); ?>" alt="">Thank You and Have a nice pay</div>
    <div class="group">
        <input type="text" name="" value="<?php echo e($resultMsg); ?>">
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Message</label>
    </div>
    <form action="/invoice" method="get">
        <?php echo csrf_field(); ?>
    <div class="group">
        <?php if(Session::get('payMethod') === "01"): ?>
            <input type="text" name="payMethod" value="Credit Card">
        <?php elseif(Session::get('payMethod') === "02"): ?>
            <input type="text" name="payMethod" value="Virtual Account">
        <?php elseif(Session::get('payMethod') === "03"): ?>
            <input type="text" name="payMethod" value="Convenience Store">
        <?php elseif(Session::get('payMethod') === "04"): ?>
            <input type="text" name="payMethod" value="Click Pay">
        <?php elseif(Session::get('payMethod') === "05"): ?>
            <input type="text" name="payMethod" value="E-Wallet">
        <?php elseif(Session::get('payMethod') === "06"): ?>
            <input type="text" name="payMethod" value="Pay Loan">
        <?php endif; ?>
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Payment Method</label>
    </div>
    <?php if(isset($bankVacctNo)): ?>
        <div class="group">
            <input type="text" name="bankVacctNo" value="<?php echo e($bankVacctNo); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Virtual Account No.</label>
        </div>
    <?php endif; ?>
    <?php if(isset($bankCd)): ?>
        <div class="group">
            <input type="text" name="bankCd" value="<?php echo e($bankCd); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Bank Code</label>
        </div>
    <?php endif; ?>
    <?php if(isset($mitraCd)): ?>
        <div class="group">
            <input type="text" name="mitraCd" value="<?php echo e($mitraCd); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Mitra Code</label>
        </div>
    <?php endif; ?>
    <?php if(isset($payNo)): ?>
        <div class="group">
            <input type="text" name="payNo" value="<?php echo e($payNo); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Payment Number</label>
        </div>
    <?php endif; ?>
    <div class="group">
        <input type="text" name="amount" value="<?php echo e($amount); ?>">
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Amount</label>
    </div>
    <div class="group">
        <input type="text" name="referenceNo" value="<?php echo e($referenceNo); ?>">
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Reference No</label>
    </div>
    <div class="group">
        <input type="text" name="tXid" value="<?php echo e($tXid); ?>">
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Transaction ID</label>
    </div>
    <?php if(isset($authNo)): ?>
        <div class="group">
            <input type="text" name="authNo" value="<?php echo e($authNo); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Auth</label>
        </div>
    <?php endif; ?>
    <div class="group">
        <input type="text" name="transDt" value="<?php echo e($transDt); ?>">
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Date</label>
    </div>
    <div class="group">
        <input type="text" name="transTm" value="<?php echo e($transTm); ?>">
        <span class="highlight"></span>
        <span class="bar"></span>
        <label>Time</label>
    </div>
    <?php if(isset($description)): ?>
        <div class="group">
            <input type="text" name="description" value="<?php echo e($description); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Description</label>
        </div>
    <?php endif; ?>
    <?php if(isset($cardNo)): ?>
        <div class="group">
            <input type="text" name="cardNo" value="<?php echo e($cardNo); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Card</label>
        </div>
    <?php endif; ?>
    <?php if(isset($vat)): ?>
        <div class="group">
            <input type="text" name="vat" value="<?php echo e($vat); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>VAT</label>
        </div>
    <?php endif; ?>
    <?php if(isset($fee)): ?>
        <div class="group">
            <input type="text" name="fee" value="<?php echo e($fee); ?>">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Fees</label>
        </div>
    <?php endif; ?>
        <input type="submit" value="Generate Invoice"/>
    </form>
    <br>
    <form action="/checkPayment" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="checkPayment" value="checkPayment">
        <input type="hidden" name="tXid" value="<?php echo e($tXid); ?>">
        <input type="hidden" name="iMid" value="<?php echo e(Session::get('iMid')); ?>">
        <input type="hidden" name="merchantKey" value="<?php echo e(Session::get('merchantKey')); ?>">
        <input type="hidden" name="amt" value="<?php echo e($amount); ?>">
        <input type="hidden" name="referenceNo" value="<?php echo e($referenceNo); ?>">
        <input type="hidden" name="payMethod" value="<?php echo e(Session::get('payMethod')); ?>">
        <input type="submit" value="Check Payment"/>
    </form>
    <br>
    <form action="/" method="get">
        <input type="submit" value="Back To Checkout" formaction="/" />
    </form>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\Journey\resources\views\result.blade.php ENDPATH**/ ?>