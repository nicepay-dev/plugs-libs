<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Your order is being processed...</title>
    <link rel="stylesheet" href="{{ URL::asset('/css/index.css') }}">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>

<body>

<div class="form-style-8" style="margin-top:5%;">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="{{ url('/img/nicepay_logo.jpg') }}" alt="">Thank You and Have a nice pay</div>
    @isset($resultMsg)
        <div class="group">
            <input type="text" name="" value="{{$resultMsg}}">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Message</label>
        </div>
    @endisset
    <form action="/invoice" method="get">
        @csrf
        <div class="group">
            @if(Session::get('payMethod') === "01")
                <input type="text" name="payMethod" value="Credit Card">
            @elseif(Session::get('payMethod') === "02")
                <input type="text" name="payMethod" value="Virtual Account">
            @elseif(Session::get('payMethod') === "03")
                <input type="text" name="payMethod" value="Convenience Store">
            @elseif(Session::get('payMethod') === "04")
                <input type="text" name="payMethod" value="Click Pay">
            @elseif(Session::get('payMethod') === "05")
                <input type="text" name="payMethod" value="E-Wallet">
            @elseif(Session::get('payMethod') === "06")
                <input type="text" name="payMethod" value="Pay Loan">
            @endif
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Payment Method</label>
        </div>
        @isset($bankVacctNo)
            <div class="group">
                <input type="text" name="bankVacctNo" value="{{$bankVacctNo}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Virtual Account No.</label>
            </div>
        @endisset
        @isset($bankCd)
            <div class="group">
                <input type="text" name="bankCd" value="{{$bankCd}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Bank Code</label>
            </div>
        @endisset
        @isset($mitraCd)
            <div class="group">
                <input type="text" name="mitraCd" value="{{$mitraCd}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Mitra Code</label>
            </div>
        @endisset
        @isset($payNo)
            <div class="group">
                <input type="text" name="payNo" value="{{$payNo}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Payment Number</label>
            </div>
        @endisset
        @isset($amount)
            <div class="group">
                <input type="text" name="amount" value="{{$amount}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Amount</label>
            </div>
        @endisset
        @isset($referenceNo)
            <div class="group">
                <input type="text" name="referenceNo" value="{{$referenceNo}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Reference No</label>
            </div>
        @endisset
        @isset($tXid)
            <div class="group">
                <input type="text" name="tXid" value="{{$tXid}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction ID</label>
            </div>
        @endisset
        @isset($authNo)
            <div class="group">
                <input type="text" name="authNo" value="{{$authNo}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Auth</label>
            </div>
        @endisset
        @isset($transDt)
            <div class="group">
                <input type="text" name="transDt" value="{{$transDt}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Date</label>
            </div>
        @endisset
        @isset($transTm)
            <div class="group">
                <input type="text" name="transTm" value="{{$transTm}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Time</label>
            </div>
        @endisset
        @isset($description)
            <div class="group">
                <input type="text" name="description" value="{{$description}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Description</label>
            </div>
        @endisset
        @isset($cardNo)
            <div class="group">
                <input type="text" name="cardNo" value="{{$cardNo}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Card</label>
            </div>
        @endisset
        @isset($vat)
            <div class="group">
                <input type="text" name="vat" value="{{$vat}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>VAT</label>
            </div>
        @endisset
        @isset($fee)
            <div class="group">
                <input type="text" name="fee" value="{{$fee}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Fees</label>
            </div>
        @endisset
        <input type="submit" value="Generate Invoice"/>
    </form>
    <br>
    @isset($tXid)
        <form action="/checkPayment" method="post">
            @csrf
            <input type="hidden" name="checkPayment" value="checkPayment">
            <input type="hidden" name="tXid" value="{{$tXid}}">
            <input type="hidden" name="iMid" value="{{Session::get('iMid')}}">
            <input type="hidden" name="merchantKey" value="{{Session::get('merchantKey')}}">
            <input type="hidden" name="amt" value="{{$amount}}">
            <input type="hidden" name="referenceNo" value="{{$referenceNo}}">
            <input type="hidden" name="payMethod" value="{{Session::get('payMethod')}}">
            <input type="submit" value="Check Payment"/>
        </form>
    @endisset
    <br>
    <form action="/" method="get">
        <input type="submit" value="Back To Checkout" formaction="/" />
    </form>
</div>
</body>
</html>
