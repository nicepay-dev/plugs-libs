<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cancellation Result</title>
    <link rel="stylesheet" href="{{ URL::asset('/css/index.css') }}">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>
<body>

<div class="form-style-8" style="margin-top:5%;">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="{{ url('/img/nicepay_logo.jpg') }}" alt="">Error!</div>
    <form action="index.html" method="get">
        @csrf
        @if(null==Session::get('msg'))
        {{$msg}}
        @elseif(null!=Session::get('msg'))
            {{Session::get('msg')}}
        @endif
            <br>
        <input style="margin-top:5% !important;" type="submit" value="Back To Checkout" formaction="/" />
    </form>
</div>
</body>
</html>
