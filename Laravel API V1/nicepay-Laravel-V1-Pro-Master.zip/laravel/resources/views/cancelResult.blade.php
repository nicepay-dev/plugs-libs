<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cancellation Result</title>
    <link rel="stylesheet" href="{{ URL::asset('/css/index.css') }}">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>
<body>

<div class="form-style-8" style="margin-top:5%;">
    @if(isset($resultCd) && $resultCd == "0000")
        <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="{{ url('/img/nicepay_logo.jpg') }}" alt="">Cancel Result</div>
        <div class="group">
            <input type="text" name="" value="{{$canceltXid}}">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Cancel Transaction ID</label>
        </div>
        <div class="group">
            <input type="text" name="" value="{{$resultMsg}}">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Message</label>
        </div>
        <div class="group">
            <input type="text" name="" value="{{$tXid}}">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Order Transaction ID</label>
        </div>
        @isset($amt)
            <div class="group">
                <input type="text" name="" value="{{$amt}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Cancel Amount</label>
            </div>
        @endisset
        <div class="group">
            <input type="text" name="" value="{{$transDt}}">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Date</label>
        </div>
        <div class="group">
            <input type="text" name="" value="{{$transTm}}">
            <span class="highlight"></span>
            <span class="bar"></span>
            <label>Time</label>
        </div>
    @elseif(isset($resultCd))
        <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="{{ url('/img/nicepay_logo.jpg') }}" alt="">Error!</div>
        <form action="index.html" method="get">
            @csrf
            <div class="group">
                <input type="text" name="tXid" value="{{$resultCd}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Code</label>
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="{{$resultMsg}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Message</label>
            </div>
        </form>
    @endif
    <form action="/" method="get">
        @csrf
        <input type="submit" value="Back To Checkout" formaction="/" />
    </form>
</div>
</body>
</html>
