<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thank You For Your Purchase!</title>
    <link href="https://fonts.googleapis.com/css?family=Libre+Barcode+128|VT323" rel="stylesheet">
    <style>
        * {
            margin: 0;
            box-sizing: border-box;
            font-family: "VT323", monospace;
            color: #1f1f1f;
        }

        .container {
            background: #f1f1f1;
            padding: 20px 10px;
        }

        .bold {
            font-weight: bold;
        }

        .center {
            text-align: center;
        }

        .receipt {
            width: 300px;
            min-height: 100vh;
            height: 100%;
            background: #fff;
            margin: 0 auto;
            box-shadow: 5px 5px 19px #ccc;
            padding: 10px;
        }

        .logo {
            text-align: center;
            padding: 20px;
        }

        .barcode {
            font-family: "Libre Barcode 128", cursive;
            font-size: 42px;
            text-align: center;
        }

        .address {
            text-align: center;
            margin-bottom: 10px;
        }

        .transactionDetails {
            display: flex;
            justify-content: space-between;
            margin: 0 10px 10px;
        }
        .transactionDetails .detail {
            text-transform: uppercase;
        }

        .centerItem {
            display: flex;
            justify-content: center;
            margin-bottom: 8px;
        }

        .survey {
            text-align: center;
            margin-bottom: 12px;
        }
        .survey .surveyID {
            font-size: 20px;
        }

        .paymentDetails {
            display: flex;
            justify-content: space-between;
            margin: 0 auto;
            width: 150px;
        }

        .creditDetails {
            margin: 10px auto;
            width: 230px;
            font-size: 14px;
            text-transform: uppercase;
        }

        .receiptBarcode {
            margin: 10px 0;
            text-align: center;
        }

        .returnPolicy {
            margin: 10px 20px;
            width: 220px;
            display: flex;
            justify-content: space-between;
        }

        .coupons {
            margin-top: 20px;
        }

        .tripSummary {
            margin: auto;
            width: 255px;
        }
        .tripSummary .item {
            display: flex;
            justify-content: space-between;
            margin: auto;
            width: 220px;
        }

        .feedback {
            margin: 20px auto;
        }
        .feedback h3.clickBait {
            font-size: 30px;
            font-weight: bold;
            text-align: center;
            margin: 10px 0;
        }
        .feedback h4.web {
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            margin: 10px 0;
        }
        .feedback .break {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin: 10px 0;
        }

        .couponContainer {
            border-top: 1px dashed #1f1f1f;
            margin-bottom: 20px;
        }
        .couponContainer .discount {
            font-size: 35px;
            text-align: center;
            margin-bottom: 10px;
        }
        .couponContainer .discountDetails {
            font-size: 20px;
            text-align: center;
            margin-bottom: 15px;
        }
        .couponContainer .barcode {
            margin: 10px 0 0;
        }
        .couponContainer .legal {
            font-size: 12px;
            margin-bottom: 12px;
        }
        .couponContainer .barcodeID {
            margin-bottom: 8px;
        }
        .couponContainer .expiration {
            display: flex;
            justify-content: space-between;
            margin: 10px;
        }
        .couponContainer .couponBottom {
            font-size: 13px;
            text-align: center;
        }
        .img-valign {
            vertical-align: middle;
            margin-right: 10px;
        }

    </style>
</head>

<body>
    <div class="receipt">
        <div><img class="img-valign" style="width: 60px; height:auto" src="{{ url('/img/nicepay_logo.jpg') }}" alt="">Thank You and Have a nice pay</div>
        <h1 class="logo">NICEPAY Store</h1>
        <div class="address">
            EightyEight@Kota Kasablanka, 29th Floor, Unit H, Jalan Casablanca, Kav 88, Tebet.
        </div>
        <div class="transactionDetails">
            {{--PAYMETHOD--}}
            @if(Session::get('payMethod') === "01")
                <div class="detail">Credit Card</div>
            @elseif(Session::get('payMethod') === "02")
                <div class="detail">Virtual Account</div>
            @elseif(Session::get('payMethod') === "03")
                <div class="detail">Convenience Store</div>
            @elseif(Session::get('payMethod') === "04")
                <div class="detail">Click Pay</div>
            @elseif(Session::get('payMethod') === "05")
                <div class="detail">E-Wallet</div>
            @elseif(Session::get('payMethod') === "06")
                <div class="detail">Pay Loan</div>
            @endif
            {{--mitraCd/BankCd--}}
            @isset($bankCd)
                <div class="detail">{{$bankCd}}</div>
            @endisset
            @isset($mitraCd)
                <div class="detail">{{$mitraCd}}</div>
            @endisset
        </div>
        <div class="transactionDetails">
            Helped by: NICEPAY
        </div>
        <div class="centerItem bold">
            <div class="item">#{{$referenceNo}}</div>
        </div>
        <div class="transactionDetails">
            <div class="detail">1</div>
            <div class="detail">iPhone 11</div>
            <div class="detail">{{$amount}}</div>
        </div>
        <div class="survey bold">
            <p>Transaction ID #</p>
            <p class="surveyID">{{$tXid}}</p>
        </div>
        <div class="paymentDetails bold">
            <div class="detail">TOTAL</div>
            <div class="detail">{{$amount}}</div>
        </div>
        <div class="paymentDetails">
            <div class="detail">CHARGE</div>
            <div class="detail">{{$amount}}</div>
        </div>
        @isset($bankVacctNo)
            <div class="paymentDetails">
                <div class="detail">Virtual Account #: {{$bankVacctNo}}</div>
                <div class="detail">VA: {{$bankCd}}</div>
            </div>
        @endisset
        @isset($cardNo)
            <div class="paymentDetails">
                <div class="detail">{{$cardNo}}</div>
                <div class="detail">Credit Card</div>
            </div>
        @endisset
        @isset($payNo)
            <div class="paymentDetails">
                <div class="detail">CVS Pay No: #{{$payNo}}</div>
                <div class="detail">{{$mitraCd}}</div>
            </div>
        @endisset
        <div class="creditDetails">
            <p>approved# 09773B</p>
            <p>ref# 013589</p>
            <p>tran type: SALE</p>
            <p>AID: 30000000090755</p>
            <p>TC: B7A2A4044AEE380A4</p>
            <p>CVM: 1e0300</p>
            <p>TMR(95): 0080081111</p>
            <p>TS(9B): E900</p>
            <p>Trans Date: {{$transDt}}</p>
            <p>Trans Time: {{$transTm}}</p>
        </div>

        <div class="paymentDetails">
            <div class="detail">CHANGE</div>
            <div class="detail">.00</div>
        </div>
        <div class="receiptBarcode">
            <div class="barcode">
                {{$amount}}
            </div>
            {{$tXid}}
        </div>
        <div class="returnPolicy bold">
            Returns with receipt, subject to NICEPAY Return Policy, thru 12/04/2020
        </div>
        <div class="returnPolicy">
            <div class="detail">October 5, 2020</div>
            <div class="detail">10:16 AM</div>
        </div>
        <div class="tripSummary">
            <div class="bold">Trip Summary:</div>
            <div class="item">
                <div>Today You Saved:</div>
                <div>.00</div>
            </div>
            <div class="item">
                <div>Savings Value</div>
                <div>0%</div>
            </div>
        </div>
        <div class="feedback">
            <div class="break">
                *************************************
            </div>
            <p class="center">
                We would love to hear your feedback on your recent experience with us. This survey will only take 1 minute to complete.
            </p>
            <h3 class="clickBait">Share Your Feedback</h3>
            <h4 class="web">https://nicepay.co.id/id/contact/</h4>
            <p class="center">
                HAVE A NICE PAY! :)
            </p>
            <div class="break">
                *************************************
            </div>
        </div></div>
</body>
</html>
