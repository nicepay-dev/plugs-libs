<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Gili and HanHan">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Payment Status</title>
    <link rel="stylesheet" href="{{ URL::asset('/css/index.css') }}">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>

<body>

<div class="form-style-8" style="margin-top:5%;">
    <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="{{ url('/img/nicepay_logo.jpg') }}" alt="">Your Payment...</div>
    @if(isset($resultCd) && $resultCd == "0000")
        <form action="cancelPayment" method="post">
            @csrf
            <div class="group">
                <input type="text" name="tXid" value="{{$tXid}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction ID</label>
            </div>

            <div class="group">
                <input type="hidden" name="payMethod" value="{{Session::get('payMethod')}}">
                @if(Session::get('payMethod') === "01")
                    <input type="text" name="" value="Credit Card">
                @elseif(Session::get('payMethod') === "02")
                    <input type="text" name="" value="Virtual Account">
                @elseif(Session::get('payMethod') === "03")
                    <input type="text" name="" value="Convenience Store">
                @elseif(Session::get('payMethod') === "04")
                    <input type="text" name="" value="Click Pay">
                @elseif(Session::get('payMethod') === "05")
                    <input type="text" name="" value="E-Wallet">
                @elseif(Session::get('payMethod') === "06")
                    <input type="text" name="" value="Pay Loan">
                @endif
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Payment Method</label>
            </div>

            <div class="group">
                <input type="text" name="amt" value="{{$amt}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Amount</label>
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="{{$resultMsg}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Status Payment</label>
            </div>

            <div class="group">
                <input type="text" name="reqDt" value="{{$reqDt}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Request Date</label>
            </div>

            <div class="group">
                <input type="text" name="reqTm" value="{{$reqTm}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Request Time</label>
            </div>

            <div class="group">
                <input type="text" name="transDt" value="{{$transDt}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction Date</label>
            </div>

            <div class="group" style="margin-bottom: 5% !important;">
                <input type="text" name="transTm" value="{{$transTm}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Transaction Time</label>
            </div>

            <input type="radio" name="cancelType" value="1" checked>Full Cancellation
            <input type="radio" name="cancelType" value="2">Partial Cancellation
            <br >

            <input style="margin-top:5% !important;" type="submit" value="Cancel Transaction"/>
        </form>
        <br>
        <form action="index.html" method="get">
            <input type="submit" value="Back To Checkout" formaction="/"/>
        </form>

    @elseif(isset($resultCd))
        <div class="main-title"><img class="img-valign" style="width: 60px; height:auto" src="{{ url('/img/nicepay_logo.jpg') }}" alt="">Error!</div>
        <form action="index.html" method="get">
            @csrf
            <div class="group">
                <input type="text" name="tXid" value="{{$resultCd}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Code</label>
            </div>

            <div class="group">
                <input type="text" name="resultMsg" value="{{$resultMsg}}">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label>Error Message</label>
            </div>
            <input type="submit" value="Back To Checkout" formaction="/" />
        </form>
    @endif

</div>
</body>
</html>
