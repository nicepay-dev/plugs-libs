<?php
// Text
// Heading
$_['heading_title']     = 'Thank you for shopping with us ';

// Text
$_['text_title']        = 'Nicepay Virtual Account';
$_['text_description']        = 'text_description';
$_['text_response']     = 'Response from Nicepay:';
$_['text_success']      = '... your payment was successfully received.';
$_['text_success_wait'] = '<b><span style="color: #FF0000">Please wait...</span></b> whilst we finish processing your order.<br>If you are not automatically re-directed in 10 seconds, please click <a href="%s">here</a>.';
$_['text_failure']      = 'Sorry! Your payment has failed! Please do re-checkout or contact administrator/support ';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">Please wait...</span></b><br>If you are not automatically re-directed in 10 seconds, please click <a href="%s">here</a>.';
$_['text_customer'] = '<p>You can view your order history by going to the <a href="%s">my account</a> page and by clicking on <a href="%s">history</a>.</p><p>If your purchase has an associated download, you can go to the account <a href="%s">downloads</a> page to view them.</p><p>Please direct any questions you have to the <a href="%s">store owner</a>.</p><p>Thanks for shopping with us online!</p>';
$_['text_guest']    = '<p>Your order has been successfully processed!</p><p>Please direct any questions you have to the <a href="%s">store owner</a>.</p><p>Thanks for shopping with us online!</p>';
?>
