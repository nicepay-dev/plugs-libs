<?php
/*
status code
1 pending
2 processing
3 shipped
5 complete
7 canceled
8 denied
9 canceled reversal
10 failed
11 refunded
12 reversed
13 chargeback
14 expired
15 processed
16 voided
*/


require_once(DIR_SYSTEM . 'library/NicepayDirect/NicepayLib.php');

class ControllerExtensionPaymentNicepaycvs extends Controller {

  private function nicepay(){
      $nicepay = new NicepayLib();
      $nicepay->iMid = $this->config->get('nicepaycvs_merchant_id');
      $nicepay->merchantKey = $this->config->get('nicepaycvs_merchant_key');
      return $nicepay;
  }

  public function index() {

    if ($this->request->server['HTTPS']) {
      $data['base'] = $this->config->get('config_ssl');
    } else {
      $data['base'] = $this->config->get('config_url');
    }

    $data['errors'] = array();
    $data['button_confirm'] = $this->language->get('button_confirm');

    $env = $this->config->get('nicepaycvs_environment') == 'production' ? true : false;
    // $data['mixpanel_key'] = $env == true ? "17253088ed3a39b1e2bd2cbcfeca939a" : "9dcba9b440c831d517e8ff1beff40bd9";
    // $data['merchant_id'] = $this->config->get('snap_merchant_id');
    
    $data['pay_type'] = 'nicepaycvs';
    $data['merchant_id'] = $this->config->get('nicepaycvs_merchant_id');
    $data['merchant_key'] = $this->config->get('nicepaycvs_merchant_key');
    // $data['text_loading'] = $this->language->get('text_loading');

    $data['process_order'] = $this->url->link('extension/payment/nicepaycvs/process_order'); 
     
    return $this->load->view('extension/payment/nicepaycvs', $data);
      
  }

  /**
   * Called when a customer checkouts.
   * If it runs successfully, it will redirect to VT-Web payment page.
   */
  public function process_order() {
    $this->load->model('extension/payment/nicepaycvs');
    $this->load->model('checkout/order');
    $this->load->model('extension/total/shipping');
    $this->load->language('extension/payment/nicepaycvs');

    $data['errors'] = array();

    $data['button_confirm'] = $this->language->get('button_confirm');

    // print_r($data['button_confirm']);die;

    $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
    //error_log(print_r($order_info,TRUE));

    $this->model_checkout_order->addOrderHistory($this->session->data['order_id'],1);
    /*$this->model_checkout_order->addOrderHistory($this->session->data['order_id'],
        $this->config->get('veritrans_vtweb_challenge_mapping'));*/
    

    // $transaction_details                 = array();
    // $transaction_details['order_id']     = $this->session->data['order_id'];
    // $transaction_details['gross_amount'] = $order_info['total'];

    $transaction_details = array();
    $transaction_details['mallId'] = $this->config->get('nicepaycvs_merchant_id');
    $transaction_details['invoiceNo'] = $this->config->get('nicepaycvs_display_name') . $this->session->data['order_id'];
    $transaction_details['amount'] = (int)$order_info['total'];
    $transaction_details['currencyCode'] = 360;

    $billing_address                 = array();
    $billing_address['first_name']   = $order_info['payment_firstname'];
    $billing_address['last_name']    = $order_info['payment_lastname'];
    $billing_address['address']      = $order_info['payment_address_1'];
    $billing_address['city']         = $order_info['payment_city'];
    $billing_address['postal_code']  = $order_info['payment_postcode'];
    $billing_address['phone']        = $order_info['telephone'];
    $billing_address['country_code'] = 'IDN';

    if ($this->cart->hasShipping()) {
      $shipping_address = array();
      $shipping_address['first_name']   = $order_info['shipping_firstname'];
      $shipping_address['last_name']    = $order_info['shipping_lastname'];
      $shipping_address['address']      = $order_info['shipping_address_1'];
      $shipping_address['city']         = $order_info['shipping_city'];
      $shipping_address['postal_code']  = $order_info['shipping_postcode'];
      $shipping_address['phone']        = $order_info['telephone'];
      $shipping_address['country_code'] = 'IDN';
    } else {
      $shipping_address = $billing_address;
    }

    $customer_details                     = array();
    $customer_details['billing_address']  = $billing_address;
    $customer_details['shipping_address'] = $shipping_address;
    $customer_details['first_name']       = $order_info['payment_firstname'];
    $customer_details['last_name']        = $order_info['payment_lastname'];
    $customer_details['email']            = $order_info['email'];
    $customer_details['phone']            = $order_info['telephone'];

    $products = $this->cart->getProducts();
    
    $item_details = array();
    $item_details2 = array();

    foreach ($products as $product) {
      if (($this->config->get('config_customer_price')
            && $this->customer->isLogged())
          || !$this->config->get('config_customer_price')) {
        $product['price'] = $this->tax->calculate(
            $product['price'],
            $product['tax_class_id'],
            $this->config->get('config_tax'));
      }

      $item = array(
          'goods_amt'    => $product['price'],
          'goods_name'     => substr($product['name'], 0, 49),
          'goods_detail'     => substr($product['name'], 0, 49),
          'img_url'  => HTTPS_SERVER. "image/". $product['image'],
        );

      $item2 = array(
          'id'       => $product['product_id'],
          'amt'    => $product['price'],
          'quantity' => $product['quantity'],
          'goods_name'     => substr($product['name'], 0, 49),
          'goods_detail'     => substr($product['name'], 0, 49),
          'img_url'  => HTTPS_SERVER. "image/". $product['image'],
        );
      $item_details[] = $item;
      $item_details2[] = $item2;
    }

    unset($product);

    $num_products = count($item_details);

    if ($this->cart->hasShipping()) {
      $shipping_info = $this->session->data['shipping_method'];
      if (($this->config->get('config_customer_price')
            && $this->customer->isLogged())
          || !$this->config->get('config_customer_price')) {
        $shipping_info['cost'] = $this->tax->calculate(
            $shipping_info['cost'],
            $shipping_info['tax_class_id'],
            $this->config->get('config_tax'));
      }

      $shipping_item = array(
          'img_url' => HTTPS_SERVER. "image/payment/nicepay/nicepay.png",
          'goods_name' => "SHIPPING",
          'goods_detail' => 1,
          'goods_amt' => $shipping_info['cost']
        );

      $shipping_item2 = array(
          'quantity' => 1,
          'amt' => $shipping_info['cost']
        );

      $item_details[] = $shipping_item;
      $item_details2[] = $shipping_item2;
    }

    foreach ($item_details as &$item) {
      $item['goods_amt'] = intval($item['goods_amt']);
    }
    unset($item);

    $transaction_details['amount'] = intval($transaction_details['amount']);

    $total_price = 0;
    foreach ($item_details2 as $item) {
      $total_price += $item['amt'] * $item['quantity'];
    }

    $order_total = $transaction_details['amount'];
    if (intval($total_price) != intval($transaction_details['amount'])) {
      $coupon_item = array(
          'img_url' => HTTPS_SERVER. "image/payment/nicepay/nicepay.png",
          'goods_name' => "COUPON",
          'goods_detail' => 1,
          'goods_amt' => $transaction_details['amount'] - $total_price
        );
      $item_details[] = $coupon_item;
      $order_total = intval($transaction_details['amount']) - intval($total_price);
    }

    $nicepaycvs = array();
    $nicepaycvs['transaction_details'] = $transaction_details;
    $nicepaycvs['item_details']        = $item_details;
    $nicepaycvs['customer_details']    = $customer_details;

    $countItemDet = count($item_details);
    $cartData = ["count" => $countItemDet, "item" => $nicepaycvs['item_details']];

    $billingName = $nicepaycvs['customer_details']['billing_address']['first_name'].' '.$nicepaycvs['customer_details']['billing_address']['last_name'];

    $shippingName = $nicepaycvs['customer_details']['shipping_address']['first_name'].' '.$nicepaycvs['customer_details']['shipping_address']['last_name'];
    
    // print_r($this->request->post);die;

    try {
      // Prepare Parameters
      $nicepay = $this->nicepay();

      // Populate Mandatory parameters to send
      $dateNow        = date('Ymd');
      $vaExpiryDate   = date('Ymd', strtotime($dateNow . ' +1 day'));
      $nicepay->set('timeStamp', date('YmdHis'));
      $nicepay->set('payMethod', '03');
      $nicepay->set('currency', 'IDR');
      $nicepay->set('cartData', json_encode($cartData));
      $nicepay->set('amt', $order_total); // Total gross amount //
      $nicepay->set('referenceNo', 'refNo:#'.$this->session->data['order_id']);
      $nicepay->set('description', 'Payment of invoice No '.$this->session->data['order_id']); // Transaction description
      $nicepay->set('mitraCd', $this->request->post['mitraCd']);

      $nicepay->dbProcessUrl = HTTP_SERVER . 'nicepay/nicepaycvs_dbprocessurl.php';
      $nicepay->set('billingNm', $billingName); // Customer name
      $nicepay->set('billingPhone', $nicepaycvs['customer_details']['billing_address']['phone']); // Customer phone number
      $nicepay->set('billingEmail', $nicepaycvs['customer_details']['email']); //
      $nicepay->set('billingAddr', $nicepaycvs['customer_details']['billing_address']['address']);
      $nicepay->set('billingCity', $nicepaycvs['customer_details']['billing_address']['city']);
      $nicepay->set('billingState', $nicepaycvs['customer_details']['billing_address']['city']);
      $nicepay->set('billingPostCd', $nicepaycvs['customer_details']['billing_address']['postal_code']);
      $nicepay->set('billingCountry', $nicepaycvs['customer_details']['billing_address']['country_code']);

      $nicepay->set('deliveryNm', $shippingName); // Delivery name
      $nicepay->set('deliveryPhone', $nicepaycvs['customer_details']['shipping_address']['phone']);
      // $nicepay->set('deliveryEmail', $nicepaycvs['customer_details']['email']);
      $nicepay->set('deliveryAddr', $nicepaycvs['customer_details']['shipping_address']['address']);
      $nicepay->set('deliveryCity', $nicepaycvs['customer_details']['shipping_address']['city']);
      $nicepay->set('deliveryState', $nicepaycvs['customer_details']['shipping_address']['city']);
      $nicepay->set('deliveryPostCd', $nicepaycvs['customer_details']['shipping_address']['postal_code']);
      $nicepay->set('deliveryCountry', $nicepaycvs['customer_details']['shipping_address']['country_code']);

      $nicepay->set('vacctValidDt', $vaExpiryDate); // Set VA expiry date example: +1 day
      $nicepay->set('vacctValidTm', date('His')); // Set VA Expiry Time

      // Send Data
      $response = $nicepay->requestCVS();

      if (isset($response->resultCd) && $response->resultCd == "0000") {
        $this->session->data["description"] = $response->description;
        $this->session->data["tXid"] = $response->tXid;
        $this->session->data["bank"] = $this->mitra_info($this->request->post['mitraCd'])["label"];
        $this->session->data["bankContent"] = $this->mitra_info($this->request->post['mitraCd'])["content"];
        $this->session->data["va"] = $response->payNo;
        $this->session->data["amount"] = $response->amt;
        $this->session->data["expDate"] = $vaExpiryDate;
        $this->session->data["billingEmail"] = $nicepaycvs['customer_details']['email'];
      
          $this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('nicepaycvs_order_status_id'), 'Payment was made using NicePay Transfer Payment. Order Invoice ID is '.$order_info['invoice_prefix'].$order_info['order_id'].'. Transaction ID is '.$response->tXid, false);

          $this->cart->clear();

          $this->response->redirect($this->url->link('extension/payment/nicepaycvs_response&'.http_build_query($response)));
      }
      // error_log(print_r($payloads,TRUE));
      // $snapToken = Veritrans_Snap::getSnapToken($payloads);
      // error_log($snapToken);
      // //$this->response->setOutput($redirUrl);
      // $this->response->setOutput($snapToken);
    }
    catch (Exception $e) {
      $data['errors'][] = $e->getMessage();
      error_log($e->getMessage());
      echo $e->getMessage();
    }
  }

  public function mitra_info($mitraCd){
      
      $header = '
            <html>
            <body>

            <style>
            input[type="button"]{
              border : 2px solid;
              width : 100%;
            }
            </style>
            ';

            $footer = '
            <script>
            function atm() {
                var div_atm = document.getElementById("div_atm").style.display;
                if(div_atm == "block"){
                  document.getElementById("div_atm").style.display = "none";
                }else{
                  document.getElementById("div_atm").style.display = "block";
                }
            }
            function ib() {
                var div_ib = document.getElementById("div_ib").style.display;
                if(div_ib == "block"){
                  document.getElementById("div_ib").style.display = "none";
                }else{
                  document.getElementById("div_ib").style.display = "block";
                }
            }
            function mb() {
                var div_mb = document.getElementById("div_mb").style.display;
                if(div_mb == "block"){
                  document.getElementById("div_mb").style.display = "none";
                }else{
                  document.getElementById("div_mb").style.display = "block";
                }
            }
            function sms() {
                var div_sms = document.getElementById("div_sms").style.display;
                if(div_sms == "block"){
                  document.getElementById("div_sms").style.display = "none";
                }else{
                  document.getElementById("div_sms").style.display = "block";
                }
            }
            </script>

            </body>
            </html>
            ';

            $data = null;

            switch($mitraCd){
              case "ALMA" :
              $body = '
              <strong id="h4thanks"><input type="button" onclick="atm();" value="Bayar Melalui Alfamart"></strong>

              <div id="div_atm" style="border:2px solid #cccccc;padding:10px 30px 0; display:none">
                <ul style="list-style-type: disc">
                  <li>Pilih pembayaran melalui Alfamart / Alfamidi / Dan+Dan/ Lawson</li>
                  <li>Catat atau print kode pembayaran</li>
                  <li>Bawa kode pembayaran tersebut ke gerai Alfamart / Alfamidi / Dan+Dan / Lawson</li>
                  <li>Informasikan kepada kasir pembayaran menggunakan NICEPay + Nama Merchant</li>
                  <li>Berikan kode pembayaran ke kasir</li>
                  <li>Kasir akan memasukkan kode pembayaran</li>
                  <li>Bayar sesuai nominal</li>
                  <li>Ambil tanda terima pembayaran</li>
                  <li>Selesai</li>
                </ul>
              </div>

              <br />
              ';

              $data["content"] = "$header$body$footer";
              $data["label"] = "Alfamart";
              break;

              case "INDO" :
              $body = '
              <strong id="h4thanks"><input type="button" onclick="atm();" value="Bayar Melalui Indomaret"></strong>

              <div id="div_atm" style="border:2px solid #cccccc;padding:10px 30px 0; display:none">
                <ul style="list-style-type: disc">
                  <li>Pilih pembayaran melalui INDOMARET</li>
                  <li>Catat atau print kode pembayaran</li>
                  <li>Bawa kode pembayaran tersebut ke gerai INDOMARET</li>
                  <li>Informasikan Nama Merchant ke kasir</li>
                  <li>Berikan kode pembayaran ke kasir</li>
                  <li>Kasir akan memasukkan kode pembayaran</li>
                  <li>Bayar sesuai nominal</li>
                  <li>Ambil tanda terima pembayaran</li>
                  <li>Selesai</li>
                </ul>
              </div>

              <br />
              ';

              $data["content"] = "$header$body$footer";
              $data["label"] = "Indomaret";
              break;

            }

            return $data;
  }

  public function notificationHandler(){

    $nicepay = $this->nicepay();

    $this->load->model('checkout/order');

    // Listen for parameters passed
    $pushParameters = array(
      'tXid',
      'referenceNo',
      'amt',
      'merchantToken'
    );

    $nicepay->extractNotification($pushParameters);

    $iMid               = $nicepay->iMid;
    $tXid               = $nicepay->getNotification('tXid');
    $referenceNo        = $nicepay->getNotification('referenceNo');
    $amt                = $nicepay->getNotification('amt');
    $pushedToken        = $nicepay->getNotification('merchantToken');

    $nicepay->set('tXid', $tXid);
    $nicepay->set('referenceNo', $referenceNo);
    $nicepay->set('amt', $amt);
    $nicepay->set('iMid',$iMid);

    $merchantToken = $nicepay->merchantTokenC();
    $nicepay->set('merchantToken', $merchantToken);

    // <RESQUEST to NICEPAY>
    $paymentStatus = $nicepay->checkPaymentStatus($tXid, $referenceNo, $amt);

    $referenceNo = explode('#', $referenceNo);


    if($pushedToken == $merchantToken) {
    if (isset($paymentStatus->status) && $paymentStatus->status == '0'){
            $status_success = $this->config->get('nicepaycvs_success_status_id');
            $data_transaction = $this->model_checkout_order->getOrder(end($referenceNo));
            
            if($data_transaction["order_status_id"] != $status_success){
          echo "success : ".$paymentStatus->status;
          $this->model_checkout_order->addOrderHistory(end($referenceNo), $this->config->get('nicepaycvs_success_status_id'), 'Payment successfully through Nicepay Transfer Payment. With Order Number '. end($referenceNo) .'. Transaction ID is '.$tXid, TRUE);
            }
        }else{
             echo "Fail : ".$paymentStatus->status;
             //  die();
            $this->model_checkout_order->addOrderHistory(
                end($referenceNo),
                10,
                'Payment failed through Nicepay Credit Card. With Transaction ID '. end($referenceNo),
                TRUE
            );
        }     
    }
  } 
}
