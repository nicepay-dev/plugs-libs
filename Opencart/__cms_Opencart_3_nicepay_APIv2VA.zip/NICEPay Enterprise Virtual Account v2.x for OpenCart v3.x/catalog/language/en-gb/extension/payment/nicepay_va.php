<?php
// Text
$_['text_title'] = 'Bank Transfer Virtual Account (NICEPay)';