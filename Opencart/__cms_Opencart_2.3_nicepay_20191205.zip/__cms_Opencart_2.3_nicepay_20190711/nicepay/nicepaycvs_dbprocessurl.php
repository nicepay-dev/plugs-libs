<?php
  
  include("../config.php");

  function sent_dbproccessurl($url, $data){
    $ch = curl_init();

    //set the url, number of POST vars, POST data
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPGET, 1);
    curl_setopt($ch,CURLOPT_POSTFIELDS, $data);   

    //execute post
    $result = curl_exec($ch);

    //close connection
    curl_close($ch);
  }

  if(preg_match("/merchantToken/", json_encode($_REQUEST))){
    sent_dbproccessurl(HTTP_SERVER."index.php?route=extension/payment/nicepaycvs/notificationHandler", http_build_query($_REQUEST));
  }else{    
    exit;
  }
