package com.nicepay.pg.lib;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class NICEPayTestV2 {
	public static void main(String[] args) {
		try {
			int i = 100;
			// for (int j = 0; j < i; j++) {

			Date begin = new Date();
			String waktu = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(begin);
			System.out.println("Transaction Time : " + waktu);

			Calendar cal = Calendar.getInstance();
			cal.setTime(begin);
			cal.add(Calendar.MINUTE, 5);
			String newTime = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(cal.getTime());
			System.out.println("Expiry Time : " + newTime);
			String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(begin);
			System.out.println("time stamp : " + timestamp);

			InetAddress ip = null;

			String refNo = "OrdNo" + waktu.substring(0, 8) + waktu.substring(12);
			try {
				ip = InetAddress.getLocalHost();
				// System.out.println("Current IP address : " +
				// ip.getHostAddress());
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}

			// NICEPay nicePay = new
			// NICEPay("LAPAKTEST1","33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==",true);
			// NICEPay nicePay = new
			// NICEPay("CVS","b9CgNmvgmTykgEBVHLWXVzHzOvnWdM1n79OD5S7JAO5fTwwLNWwKtPoUDOcMKUqO4M2LSpRlBOvng4nEjKCc1g==");
			NICEPay nicePay = new NICEPay("IONPAYTEST",
					"33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==");

			// -----------------------------------------Regristation API Start-----------------------------------------

			nicePay.setPayMethod("01");
			nicePay.setTimeStamp(timestamp);
			nicePay.setCurrency("IDR");
			nicePay.setAmt("10000");
			nicePay.setReferenceNo(refNo);
			nicePay.setGoodsNm("Payment of TEST");
			nicePay.setBillingNm("MVA Testing");
			nicePay.setBillingEmail("parid@nicepay.co.id");
			nicePay.setBillingPhone("0123456789");
			nicePay.setBillingAddr("Jalan Jend. Soedirman");
			nicePay.setBillingCity("Jakarta");
			nicePay.setBillingState("Jakarta");
			nicePay.setBillingPostCd("12345");
			nicePay.setBillingCountry("Indonesia");
			nicePay.setDeliveryNm("NICEPAY");
			nicePay.setDeliveryPhone("622112345678");
			nicePay.setDeliveryAddr("Jalan Jend. Soedirman");
			nicePay.setDeliveryCity("Jakarta");
			nicePay.setDeliveryState("Jakarta");
			nicePay.setDeliveryPostCd("12345");
			nicePay.setDeliveryCountry("Indonesia");
			//
			nicePay.setCallBackUrl("http://ptsv2.com/t/testV2/post");
			nicePay.setDbProcessUrl("http://ptsv2.com/t/testV2/post");
			nicePay.setVat("0");
			nicePay.setFee("0");
			nicePay.setNotaxAmt("0");
			nicePay.setDescription("Payment of " + "Test001");
			nicePay.setUserIP(ip.getHostAddress());
			nicePay.setMerchantToken(
					nicePay.makeToken(nicePay.getTimeStamp(), nicePay.getAmt(), nicePay.getReferenceNo()));

			// System.out.println("test Token :" +nicePay.getMerchantToken());
			// nicePay.setCartData("{\"count\": \"2\",\"item\":
			// [{\"img_url\":
			// \"http://img.aaa.com/ima1.jpg\",\"goods_name\": \"Item 1
			// Name\",\"goods_detail\": \"Item 1 Detail\",\"goods_amt\":
			// \"700\"},{\"img_url\":
			// \"http://img.aaa.com/ima2.jpg\",\"goods_name\": \"Item 2
			// Name\",\"goods_detail\": \"Item 2 Detail\",\"goods_amt\":
			// \"300\"}]}");
			nicePay.setCartData("{}");

			// Payment Optional Field
			// nicePay.setReqDt(waktu.substring(0, 8));
			// nicePay.setReqTm(waktu.substring(8,14));
			// nicePay.setReqDomain("ahe.com");
			// nicePay.setReqServerIP(ip.getHostAddress());
			// nicePay.setReqClientVer("");
			// nicePay.setUserSessionID("asasas");
			// nicePay.setUserAgent("Mozilla");
			// nicePay.setUserLanguage("en-US");
			// nicePay.setMerFixAcctId("546258"); //9880001165512007
			// nicePay.setVacctValidDt(newTime.substring(0,8));
			// nicePay.setVacctValidTm(newTime.substring(8,14));
			// nicePay.setVacctValidDt("20190420");
			// nicePay.setVacctValidTm("142900");

			// Payment Spesific Field
			//// VA only
			// nicePay.setMerFixAcctId("230934"); //9880001165512007
			nicePay.setBankCd("BMRI");

			// CVS Only
			// nicePay.setMitrACD("ALMA");
			// NICEPAY.SETPAYVALIDDT("20190422");
			// NICEPAY.SETPAYVALIDTM("190000");

			// clickpay only
			nicePay.setMitraCd("OVOE");
			// nicePay.setClickPayNo("4617007700000039");
			// nicePay.setDataField3("123");
			// nicePay.setClickPayToken("000000");

			//// CC only
			nicePay.setInstmntMon("1");
			nicePay.setInstmntType("0");
			nicePay.setCardNo("5243254563453245");
			nicePay.setCardExpYymm("2203");
			nicePay.setCardCvv("424");
			// nicePay.setCavv("");
			// nicePay.setEci("");
			// System.out.println("Card Token : " +
			// nicePay.Get("cardToken"));
			// nicePay.setXid("");
			//
			// nicePay.setOnePassToken("4e937baf5d1d0e599c59e137d53edddd583f61dd1a96b9df568eea021f904f27");
			// nicePay.setOnePassToken(nicePay.Get("cardToken"));
			// nicePay.setLoging(true);
			// nicePay.setLogPath("C:\\test\\");
			//
			// Request Payment

//			nicePay.regristV2();
			// -----------------------------------------Regristation API End-----------------------------------------

			// -----------------------------------------Payment API V2 Start-----------------------------------------
			// nicePay.setPayMethod("01");

			// for test Enc Decr
			// CryptoRSA ac = new CryptoRSA(true);
			// String keyBytesPublic
			// ="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCihYcT862uLW7U3xEIZT62CeVYHzE9t0/Q8g+y5S88bzqdM0bAG4C25q6CMC6QI8OliNJ2mgXO+WOMRG+dFK61cgvJPz2XzITqy2ey0cQTPig9ydVBbPphtcg3TJTPchh0lAt7bQZqguqZQdajUebTFI1p/b6lT+XJNC31AxvzlQIDAQAB";

			// iso test data
			// String cardNo = "4546332287652768";
			// String exp = "2203";
			// String cvv = "424";
			// String cardHolderNm = "Parid Test";

			// Migs test Data
			String cardNo = "4512111111111111";
			String exp = "2205";
			String cvv = "101";
			String cardHolderNm = "Parid Test";

			// String encryptedCardNo =
			// Base64.getEncoder().encodeToString(ac.encryptString(cardNo, keyBytesPublic));
			// String encryptedexp =
			// Base64.getEncoder().encodeToString(ac.encryptString(exp, keyBytesPublic));
			// String encryptedCvv =
			// Base64.getEncoder().encodeToString(ac.encryptString(cvv, keyBytesPublic));
			// String encryptedCardHolderNm =
			// Base64.getEncoder().encodeToString(ac.encryptString(cardHolderNm,
			// keyBytesPublic));
			// System.out.println(encryptedCardNo);
			// System.out.println(encryptedexp);
			// System.out.println(encryptedCvv);
			// System.out.println(encryptedCardHolderNm);

			nicePay.setTimeStamp(timestamp);
			nicePay.setReferenceNo("OrdNo2022052758489");// fill from register param response 
			nicePay.setTrxId("IONPAYTEST01202205271921014203"); // fill from register param response

			// Encrypt
			// nicePay.setCardNo(encryptedCardNo);
			// nicePay.setCardExpYymm(encryptedexp);
			// nicePay.setCardCvv(encryptedCvv);
			// nicePay.setCardHolderNm(encryptedCardHolderNm);
			// nicePay.setEncrypted("1");
			// nicePay.setPublicKey("73c0b264e705f8d080427aa137a4475cdd2455dcf7eae22c9cc6d6ad3097e2af");

			// Normal
			nicePay.setCardNo(cardNo);
			nicePay.setCardExpYymm(exp);
			nicePay.setCardCvv(cvv);
			nicePay.setCardHolderNm(cardHolderNm);

			// reccuring
			// nicePay.setRecurringToken("asdfa6125t3");
			// nicePay.setPreauthToken("fc7a369a5da61915f5ece1286550fe13f4527ecdb7f67f019ec3c7cf120cb742");

			// Click pay
			// nicePay.setClickPayNo("123123123");
			// nicePay.setDataField3("123ads");
			// nicePay.setClickPayToken("1231asdasd");
			// nicePay.setMerchantToken("e70e3361d1ef1a83245c5f899994a444e1c5e497f41d7ad02306cad0f27bc23d");

			nicePay.setMerchantToken(
					nicePay.makeToken(nicePay.getTimeStamp(), nicePay.getAmt(), nicePay.getReferenceNo()));
			

			nicePay.setCallBackUrl("https://hookb.in/ZrRJpwyQ");

//			 nicePay.paymentV2();
			// -----------------------------------------Payment API V2 End-----------------------------------------
			
			// -----------------------------------------Inquiry Status Start-----------------------------------------
			
			nicePay.setTimeStamp(timestamp);
			nicePay.setTrxId("IONPAYTEST01202205270751383967"); // fill from register param response
			nicePay.setReferenceNo("ECOM20220527075129326");// fill from register param response 
			nicePay.setAmt("6241400");
			nicePay.setMerchantToken(
					nicePay.makeToken(nicePay.getTimeStamp(), nicePay.getAmt(), nicePay.getReferenceNo()));
			
			 nicePay.inquiry();
			// -----------------------------------------Inquiry Status Start-----------------------------------------
			
			// -----------------------------------------Cancel Start-----------------------------------------
			nicePay.setTimeStamp(timestamp);
			nicePay.setCancelMsg("test Cancel tid");
			nicePay.setPayMethod("01");
			nicePay.setCancelType("1");
			nicePay.setTrxId("IONPAYTEST01202205270751383967"); // fill from register param response
			nicePay.setReferenceNo("ECOM20220527075129326");// fill from register param response 
			nicePay.setAmt("6241400");
			nicePay.setMerchantToken(
						nicePay.makeToken(nicePay.getTimeStamp(), nicePay.getAmt(), nicePay.getTrxId()));
				
//			nicePay.cancel();
			// -----------------------------------------Cancel End-----------------------------------------

			System.out.println("Response: " + nicePay.getResponseString());
//			 common x = new common();
//			 x.printHTResult(nicePay.getHtResponse());

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}
}
