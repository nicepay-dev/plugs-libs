package com.nicepay.pg.lib;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.io.InputStream;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.xml.bind.DatatypeConverter;


public class CryptoRSA {
	
	private Cipher cipher;
	
	public CryptoRSA(boolean isNoPadding) throws NoSuchAlgorithmException, NoSuchPaddingException {
		if(isNoPadding){
			this.cipher = Cipher.getInstance("RSA/ECB/NoPadding");
		}else{
			this.cipher = Cipher.getInstance("RSA");
		}
	}
	
	public PrivateKey getPrivate(byte[] key) throws Exception {
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(key));
		KeyFactory kf = KeyFactory.getInstance("RSA");
		return kf.generatePrivate(spec);
	}
	
	public PublicKey getPublic(byte[] key) throws Exception {
		X509EncodedKeySpec spec = new X509EncodedKeySpec(Base64.getDecoder().decode(key));
		KeyFactory kf = KeyFactory.getInstance("RSA");
		return kf.generatePublic(spec);
	}
	
	public PublicKey getPublic2(byte[] key) throws Exception {
		CertificateFactory fact = CertificateFactory.getInstance("X.509");
//		FileInputStream is = new FileInputStream (filename);
		InputStream is = new ByteArrayInputStream(key);
		X509Certificate cer = (X509Certificate) fact.generateCertificate(is);
		return cer.getPublicKey();
	}
	
	public byte[] encryptText(byte[] msg, PublicKey key) 
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			UnsupportedEncodingException, IllegalBlockSizeException, 
			BadPaddingException, InvalidKeyException {
		this.cipher.init(Cipher.ENCRYPT_MODE, key);
		return cipher.doFinal(msg);
	}
	
	public byte[] decryptText(byte[] msg, PrivateKey key)
			throws InvalidKeyException, UnsupportedEncodingException, 
			IllegalBlockSizeException, BadPaddingException {
		this.cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] result= cipher.doFinal(msg);
		return result;
	}
	
	
//	Mulai Sini
	public static PublicKey getPublicKey(String base64PublicKey){
        PublicKey publicKey = null;
        try{
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return publicKey;
    }
	
	public static PrivateKey getPrivateKey(String base64PrivateKey){
        PrivateKey privateKey = null;
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        try {
            privateKey = keyFactory.generatePrivate(keySpec);
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return privateKey;
    }
	
	public static byte[] encryptString(String data, String publicKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
        return cipher.doFinal(data.getBytes());
    }

    public static String decryptTest(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return new String(cipher.doFinal(data));
    }
    
    public static String decryptString(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        return decryptTest(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(base64PrivateKey));
    }
	
	public static void main(String[] args) throws Exception {
		CryptoRSA krip = new CryptoRSA(false);
//		byte[] keyBytesPrivate = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAInn5SXdY5cS5A3Xeb7NL3ubQG5MOD/1htRkqiRzEjsfaOkzYAslTVWvkTIxnf1CBXBiPu+JmU5QEk0fdWw582l7gW+YXR76gNLGUIEF7ZKSYfKprhlygSce9dj9H6G8yxae3RpeAfhOKIYfH/0lekKpkSlgLG0WLErwt/1tx+P1AgMBAAECgYArB5l/fBnUDMft7bsGJv3W4rVy9QNkKZc9dH+GSgV5Py67/RTNxYDg6Jw0fjjeyhfqXi1nDpcwUVm0iMlZ0Kc7XxaJrHQeq7WY2Jw54xivIKIndCpU+js9j6mHQtvzyPL/fuYdx5bVADNsNsMhiDRFbZ65Fr9Z/HOoCwO+D/CmrQJBANldBvJkyd6UXmDwUVojZRq9YaeFyiqxCH2HYY2Di2mMhVf6cZUGd7T5JO7dH/IcGHtDlmUXduQzQ9X4zSL6KA8CQQCiazTYUufO6o6u5guMwrndB8DDo/hXhYJh/zL3CXt0WOOnIsxEeWXlIdqeuV1gw5Xbk277oJBX70glAKY2UE+7AkEAymsmd/7CO2RCC9ZgfCewFNm+IkqmfWFFvdigUS/qWU3CM68HrTdLrR3Ddio4gLgHWGsVmGjkkBjpmE7NgkAhowJBAIOKGcldE5ozww0JCK+egVLuVYLdCGMxoI/nVApYpqBq4SzadN68BvcUfO9xppuYq4Simg62UlC1XROCvBpe3sMCQHadocSOmsh7bPMra9owfyTFYiNHYZ9/ynuqW08eR04BClEji82ucMEB3kyE5uOdZIR75qVWWiQfC3IUoBMHGGE=".getBytes("UTF-8");
//		byte[] keyBytesPrivate = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKKFhxPzra4tbtTfEQhlPrYJ5VgfMT23T9DyD7LlLzxvOp0zRsAbgLbmroIwLpAjw6WI0naaBc75Y4xEb50UrrVyC8k/PZfMhOrLZ7LRxBM+KD3J1UFs+mG1yDdMlM9yGHSUC3ttBmqC6plB1qNR5tMUjWn9vqVP5ck0LfUDG/OVAgMBAAECgYAAuRO9FVDiic1Vi+JZUBQeVkEQ21qqQUizaS4doYs7P6h8W7v3+EU3k5q5ZJngbM2i/9/QVciIbm+03MN5Akck8LwwtgeaCjlwGVaianeysoS6/6O7kujNvjTtqL3TZccx03C3LR2irXeLR9FKLApTK3t6N6k23zwX153Kp6DCIQJBANgUqSWa5Jt5jkhJoDUSLR4t8NfOLy7ncBEYY/Ey5WgAosgqTZaYnnK/zT2iL9Qm7nefRcYdV8+aMt/MXsIzlckCQQDAi9ZwHmUEMTAKss6dahmRZ+dYLvwEuTaJdgvYpPBMxzR3R9h1EJsIa7TeLedYyJtQMzDbk17JRJydSylolkVtAkEAtsHSxnGZhT5sbwuGqxxyeKIWoBBNq/gnuu3MKgcILMzM4UuWUBdJfHhpGQYCOgerjhVyKDxNNtOOz+bFBrAmsQJAeJ/iYnEYNc0e3MTyHbnXdLmUPDGLHuZtXSZ/+2QxSthNbSCsYYJarabUM5Csa3mZm1/Gjvi/G/YI652nvmbN7QJAUWusTqf3g3/X6Mwpoxz3ekZh0U59yTQIjgha4L4baOlBm9KulwZFcMUiPHfwyEVk46/TPe/7O0JJLgE93eeOUg==".getBytes("UTF-8");
//		PrivateKey privateKey = krip.getPrivate(keyBytesPrivate);
//		byte[] keyBytesPublic = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCJ5+Ul3WOXEuQN13m+zS97m0BuTDg/9YbUZKokcxI7H2jpM2ALJU1Vr5EyMZ39QgVwYj7viZlOUBJNH3VsOfNpe4FvmF0e+oDSxlCBBe2SkmHyqa4ZcoEnHvXY/R+hvMsWnt0aXgH4TiiGHx/9JXpCqZEpYCxtFixK8Lf9bcfj9QIDAQAB".getBytes();
//		byte[] keyBytesPublic = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCihYcT862uLW7U3xEIZT62CeVYHzE9t0/Q8g+y5S88bzqdM0bAG4C25q6CMC6QI8OliNJ2mgXO+WOMRG+dFK61cgvJPz2XzITqy2ey0cQTPig9ydVBbPphtcg3TJTPchh0lAt7bQZqguqZQdajUebTFI1p/b6lT+XJNC31AxvzlQIDAQAB".getBytes();
//		PublicKey publicKey = krip.getPublic(keyBytesPublic);
//		String msg = "1111111111111111";
//		byte[] encrypted_msg = krip.encryptText(msg.getBytes(), publicKey);
//		String base64 = Base64.getEncoder().encodeToString(encrypted_msg) ;
//		byte[] decrypted_msg = krip.decryptText(base64.getBytes(), privateKey);
		
		String keyBytesPrivate = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKKFhxPzra4tbtTfEQhlPrYJ5VgfMT23T9DyD7LlLzxvOp0zRsAbgLbmroIwLpAjw6WI0naaBc75Y4xEb50UrrVyC8k/PZfMhOrLZ7LRxBM+KD3J1UFs+mG1yDdMlM9yGHSUC3ttBmqC6plB1qNR5tMUjWn9vqVP5ck0LfUDG/OVAgMBAAECgYAAuRO9FVDiic1Vi+JZUBQeVkEQ21qqQUizaS4doYs7P6h8W7v3+EU3k5q5ZJngbM2i/9/QVciIbm+03MN5Akck8LwwtgeaCjlwGVaianeysoS6/6O7kujNvjTtqL3TZccx03C3LR2irXeLR9FKLApTK3t6N6k23zwX153Kp6DCIQJBANgUqSWa5Jt5jkhJoDUSLR4t8NfOLy7ncBEYY/Ey5WgAosgqTZaYnnK/zT2iL9Qm7nefRcYdV8+aMt/MXsIzlckCQQDAi9ZwHmUEMTAKss6dahmRZ+dYLvwEuTaJdgvYpPBMxzR3R9h1EJsIa7TeLedYyJtQMzDbk17JRJydSylolkVtAkEAtsHSxnGZhT5sbwuGqxxyeKIWoBBNq/gnuu3MKgcILMzM4UuWUBdJfHhpGQYCOgerjhVyKDxNNtOOz+bFBrAmsQJAeJ/iYnEYNc0e3MTyHbnXdLmUPDGLHuZtXSZ/+2QxSthNbSCsYYJarabUM5Csa3mZm1/Gjvi/G/YI652nvmbN7QJAUWusTqf3g3/X6Mwpoxz3ekZh0U59yTQIjgha4L4baOlBm9KulwZFcMUiPHfwyEVk46/TPe/7O0JJLgE93eeOUg==";
		String keyBytesPublic = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCihYcT862uLW7U3xEIZT62CeVYHzE9t0/Q8g+y5S88bzqdM0bAG4C25q6CMC6QI8OliNJ2mgXO+WOMRG+dFK61cgvJPz2XzITqy2ey0cQTPig9ydVBbPphtcg3TJTPchh0lAt7bQZqguqZQdajUebTFI1p/b6lT+XJNC31AxvzlQIDAQAB";
		String msg = "5325079579750960";
		
		try {
            String encryptedString = Base64.getEncoder().encodeToString(encryptString(msg, keyBytesPublic));
            System.out.println(encryptedString);
            String decryptedString = krip.decryptString(encryptedString, keyBytesPrivate);
            System.out.println(decryptedString);
        } catch (NoSuchAlgorithmException e) {
            System.err.println(e.getMessage());
        }
		
		
		
		
//		System.out.println("Original Message: " + msg
//			+ "\nEncrypted Message: " + DatatypeConverter.printHexBinary(encrypted_msg)
//			+ "\nEncrypted Message base64: " + Base64.getEncoder().encodeToString(encrypted_msg)
//			+ "\nDecrypted Message: " + new String(decrypted_msg)
//			);
	}
}
