package com.nicepay.pg.lib;


public class HexCoder {
	public static String encode(byte[] in) {
		StringBuilder sb = new StringBuilder();
		
		for (int i = 0; i < in.length; i++) {
			int ch = ((in[i] & 0xF0) >> 4) & 0x0F;
			
			if (ch >= 0 && ch <= 9)
				sb.append((char) ('0' + ch));
			else if (ch >= 10)
				sb.append((char) ('A' + ch - 10));

			ch = in[i] & 0x0F;
			
			if (ch >= 0 && ch <= 9)
				sb.append((char) ('0' + ch));
			else if (ch >= 10)
				sb.append((char) ('A' + ch - 10));
		}
		return sb.toString();
	}
	
	public static byte[] decode(String in) {
		return decode(in.getBytes());
	}
	
	public static byte[] decode(byte[] in) {
		byte[] out = new byte[in.length / 2];
		
		for (int i = 0; i < in.length; i++) {
			if (i % 2 == 0) {
				if (in[i] >= '0' && in[i] <= '9')
					out[i/2] = (byte) ((in[i] - '0') << 4);
				else if (in[i] >= 'A' && in[i] <= 'F')
					out[i/2] = (byte) ((in[i] - 'A' + 10) << 4);
				else if (in[i] >= 'a' && in[i] <= 'f')
					out[i/2] = (byte) ((in[i] - 'a' + 10) << 4);
				else
					out[i/2] = 0;
			}
			else {
				if (in[i] >= '0' && in[i] <= '9')
					out[i/2] |= (byte) (in[i] - '0');
				else if (in[i] >= 'A' && in[i] <= 'F')
					out[i/2] |= (byte) (in[i] - 'A' + 10);
				else if (in[i] >= 'a' && in[i] <= 'f')
					out[i/2] |= (byte) (in[i] - 'a' + 10);
				else
					out[i/2] |= 0;
			}
		}
		return out;
	}

	
}
