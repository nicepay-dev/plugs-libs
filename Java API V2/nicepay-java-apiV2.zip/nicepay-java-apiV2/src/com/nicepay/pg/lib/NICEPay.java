package com.nicepay.pg.lib;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
//import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;


//import org.apache.commons.logging.Log;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
//import org.apache.http.client.ResponseHandler;
//import org.apache.http.client.config.RequestConfig; //When use HTTPClient 4.3
//import org.apache.http.impl.client.HttpClientBuilder; //When use HTTPClient 4.3
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
//import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient; //When use HTTPClient 4.2
import org.apache.http.params.BasicHttpParams; //When use HTTPClient 4.2
import org.apache.http.params.HttpConnectionParams; //When use HTTPClient 4.2
import org.apache.http.params.HttpParams; //When use HTTPClient 4.2
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.ObjectMapper;



public class NICEPay {

	
	
	/**
	 * @param args
	 */

	// Version 2 prod
		public static final String urlRealRegristation = "http://api.nicepay.co.id/nicepay/direct/v2/registration";
//		public static final String urlRealRegristation = "https://api.nicepay.co.id/nicepay/api/ewalletTrans.do";
		public static final String urlRealPaymentV2 = "https://api.nicepay.co.id/nicepay/direct/v2/payment";
		public static final String urlRealInquiry= "https://dev.nicepay.co.id/nicepay/direct/v2/inquiry";
		public static final String urlRealCancel= "https://dev.nicepay.co.id/nicepay/direct/v2/cancel";

		//Version 2 Dev
		public static final String urlLocalRegristation = "https://dev.nicepay.co.id/nicepay/direct/v2/registration";
		public static final String urlLocalPaymentV2 = "https://dev.nicepay.co.id/nicepay/direct/v2/payment";
		public static final String urlLocalInquiry = "https://dev.nicepay.co.id/nicepay/direct/v2/inquiry";
		public static final String urlLocalCancel = "https://dev.nicepay.co.id/nicepay/direct/v2/cancel";


	private boolean bDebug;
	private String merchantID = "";
	private String merchantKey = "";
	private String merchantToken = "";
	private Hashtable<String, String> htRequest;
	private Hashtable<String, String> htResponse;
	private String responseString = "";
	private common cmn;
	private int functionType = 0;

	private String payMethod = "";
	private String currency = "IDR";
	private String amt = "";
	private String instmntType = "0";
	private String instmntMon = "0";
	private String referenceNo = "";
	private String goodsNm = "";
	private String billingNm = "";
	private String billingPhone = "";
	private String billingEmail = "";
	private String billingAddr = "";
	private String billingCity = "";
	private String billingState = "";
	private String billingPostCd = "";
	private String billingCountry = "";
	private String deliveryNm = "";
	private String deliveryPhone = "";
	private String deliveryAddr = "";
	private String deliveryCity = "";
	private String deliveryState = "";
	private String deliveryPostCd = "";
	private String deliveryCountry = "";
	private String callBackUrl = "";
	private String dbProcessUrl = "";
	private String vat = "0";
	private String fee = "0";
	private String notaxAmt = "0";
	private String description = "";
	private String reqDt = "";
	private String reqTm = "";
	private String reqDomain = "";
	private String reqServerIP = "";
	private String reqClientVer = "1.16";
	private String userIP = "";
	private String userSessionID = "";
	private String userAgent = "";
	private String userLanguage = "";
	private String cartData = "{}";
	private String merFixAcctId = "";
	private String vacctValidDt = "";
	private String vacctValidTm = "";
	private String bankCd = "";
	private String cardNo = "";
	private String cardExpYymm = "";
	private String cardCvv = "";
	private String cavv = "";
	private String eci = "";
	private String xid = "";
	private String trxId = "";
	private String cancelType = "1";
	private String cancelMsg = "";
	private String cancelUserId = "";
	private String cancelUserInfo = "";
	private String cancelRetryCnt = "";
	private String cancelServerIp = "";
	private String cancelUserIp = "";
	private String worker = "";
	private String pan = "";
	private String cardExpiry = "";
	private String onePassToken = "";
	private String recurringToken = "";
	private String preauthToken = "";
	private String customerID = "";
	private String customerNm = "";
	private String vaNumber = "";
	private String fromDate = "";
	private String toDate = "";
	private String recurrOpt = "";
	private String cardHolderNm="";

	// CVS
	private String mitraCd = "";
	private String payValidDt = "";
	private String payValidTm = "";

	// clickpay
	private String clickPayNo = "";
	private String dataField3 = "";
	private String clickPayToken = "";
	
	//Version 2
	private String timeStamp  = "";
	
	//Encrypted
	private String encrypted  = "";
	private String publicKey  = "";

	public NICEPay(String MID, String merchantKeyFilePath) throws IOException {
		this(MID, merchantKeyFilePath, false);
	}

	public NICEPay(String MID, String merchantKeyFilePath, boolean bDebug) throws IOException {
		setbDebug(bDebug);
		setMerchantID(MID);
		setMerchantKey(merchantKeyFilePath);

		htRequest = new Hashtable<String, String>();
		// htResponse = new Hashtable<String, String>();
		cmn = new common();
	}

	
	
	public String getCardHolderNm() {
		return cardHolderNm;
	}

	public void setCardHolderNm(String cardHolderNm) {
		this.cardHolderNm = cardHolderNm;
	}

	public String getEncrypted() {
		return encrypted;
	}

	public void setEncrypted(String encrypted) {
		this.encrypted = encrypted;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public void setReq(String name, String value) {
		htRequest.put(name, value);
	}

	public String getReq(String name) {
		return htResponse.get(name);
	}

	public boolean isbDebug() {
		return bDebug;
	}

	public void setbDebug(boolean bDebug) {
		this.bDebug = bDebug;
	}

	public String getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	public String getMerchantKey() {
		return merchantKey;
	}

	public void setMerchantKey(String merchantKey) {
		this.merchantKey = merchantKey;
	}

	public String getMerchantToken() {
		return merchantToken;
	}

	public void setMerchantToken(String merchantToken) {
		this.merchantToken = merchantToken;
	}

	public Hashtable<String, String> getHtRequest() {
		return htRequest;
	}

	public void setHtRequest(Hashtable<String, String> htRequest) {
		this.htRequest = htRequest;
	}

	public Hashtable<String, String> getHtResponse() {
		return htResponse;
	}

	public void setHtResponse(Hashtable<String, String> htResponse) {
		this.htResponse = htResponse;
	}

	public String getResponseString() {
		return responseString;
	}

	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}

	public common getCmn() {
		return cmn;
	}

	public void setCmn(common cmn) {
		this.cmn = cmn;
	}

	public int getFunctionType() {
		return functionType;
	}

	public void setFunctionType(int functionType) {
		this.functionType = functionType;
	}

	public String getPayMethod() {
		return payMethod;
	}

	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public String getInstmntType() {
		return instmntType;
	}

	public void setInstmntType(String instmntType) {
		this.instmntType = instmntType;
	}

	public String getInstmntMon() {
		return instmntMon;
	}

	public void setInstmntMon(String instmntMon) {
		this.instmntMon = instmntMon;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getGoodsNm() {
		return goodsNm;
	}

	public void setGoodsNm(String goodsNm) {
		this.goodsNm = goodsNm;
	}

	public String getBillingNm() {
		return billingNm;
	}

	public void setBillingNm(String billingNm) {
		this.billingNm = billingNm;
	}

	public String getBillingPhone() {
		return billingPhone;
	}

	public void setBillingPhone(String billingPhone) {
		this.billingPhone = billingPhone;
	}

	public String getBillingEmail() {
		return billingEmail;
	}

	public void setBillingEmail(String billingEmail) {
		this.billingEmail = billingEmail;
	}

	public String getBillingAddr() {
		return billingAddr;
	}

	public void setBillingAddr(String billingAddr) {
		this.billingAddr = billingAddr;
	}

	public String getBillingCity() {
		return billingCity;
	}

	public void setBillingCity(String billingCity) {
		this.billingCity = billingCity;
	}

	public String getBillingState() {
		return billingState;
	}

	public void setBillingState(String billingState) {
		this.billingState = billingState;
	}

	public String getBillingPostCd() {
		return billingPostCd;
	}

	public void setBillingPostCd(String billingPostCd) {
		this.billingPostCd = billingPostCd;
	}

	public String getBillingCountry() {
		return billingCountry;
	}

	public void setBillingCountry(String billingCountry) {
		this.billingCountry = billingCountry;
	}

	public String getDeliveryNm() {
		return deliveryNm;
	}

	public void setDeliveryNm(String deliveryNm) {
		this.deliveryNm = deliveryNm;
	}

	public String getDeliveryPhone() {
		return deliveryPhone;
	}

	public void setDeliveryPhone(String deliveryPhone) {
		this.deliveryPhone = deliveryPhone;
	}

	public String getDeliveryAddr() {
		return deliveryAddr;
	}

	public void setDeliveryAddr(String deliveryAddr) {
		this.deliveryAddr = deliveryAddr;
	}

	public String getDeliveryCity() {
		return deliveryCity;
	}

	public void setDeliveryCity(String deliveryCity) {
		this.deliveryCity = deliveryCity;
	}

	public String getDeliveryState() {
		return deliveryState;
	}

	public void setDeliveryState(String deliveryState) {
		this.deliveryState = deliveryState;
	}

	public String getDeliveryPostCd() {
		return deliveryPostCd;
	}

	public void setDeliveryPostCd(String deliveryPostCd) {
		this.deliveryPostCd = deliveryPostCd;
	}

	public String getDeliveryCountry() {
		return deliveryCountry;
	}

	public void setDeliveryCountry(String deliveryCountry) {
		this.deliveryCountry = deliveryCountry;
	}

	public String getCallBackUrl() {
		return callBackUrl;
	}

	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}

	public String getDbProcessUrl() {
		return dbProcessUrl;
	}

	public void setDbProcessUrl(String dbProcessUrl) {
		this.dbProcessUrl = dbProcessUrl;
	}

	public String getVat() {
		return vat;
	}

	public void setVat(String vat) {
		this.vat = vat;
	}

	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getNotaxAmt() {
		return notaxAmt;
	}

	public void setNotaxAmt(String notaxAmt) {
		this.notaxAmt = notaxAmt;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReqDt() {
		return reqDt;
	}

	public void setReqDt(String reqDt) {
		this.reqDt = reqDt;
	}

	public String getReqTm() {
		return reqTm;
	}

	public void setReqTm(String reqTm) {
		this.reqTm = reqTm;
	}

	public String getReqDomain() {
		return reqDomain;
	}

	public void setReqDomain(String reqDomain) {
		this.reqDomain = reqDomain;
	}

	public String getReqServerIP() {
		return reqServerIP;
	}

	public void setReqServerIP(String reqServerIP) {
		this.reqServerIP = reqServerIP;
	}

	public String getReqClientVer() {
		return reqClientVer;
	}

	public void setReqClientVer(String reqClientVer) {
		this.reqClientVer = reqClientVer;
	}

	public String getUserIP() {
		return userIP;
	}

	public void setUserIP(String userIP) {
		this.userIP = userIP;
	}

	public String getUserSessionID() {
		return userSessionID;
	}

	public void setUserSessionID(String userSessionID) {
		this.userSessionID = userSessionID;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public String getUserLanguage() {
		return userLanguage;
	}

	public void setUserLanguage(String userLanguage) {
		this.userLanguage = userLanguage;
	}

	public String getCartData() {
		return cartData;
	}

	public void setCartData(String cartData) {
		this.cartData = cartData;
	}

	public String getMerFixAcctId() {
		return merFixAcctId;
	}

	public void setMerFixAcctId(String merFixAcctId) {
		this.merFixAcctId = merFixAcctId;
	}

	public String getVacctValidDt() {
		return vacctValidDt;
	}

	public void setVacctValidDt(String vacctValidDt) {
		this.vacctValidDt = vacctValidDt;
	}

	public String getVacctValidTm() {
		return vacctValidTm;
	}

	public void setVacctValidTm(String vacctValidTm) {
		this.vacctValidTm = vacctValidTm;
	}

	public String getBankCd() {
		return bankCd;
	}

	public void setBankCd(String bankCd) {
		this.bankCd = bankCd;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getCardExpYymm() {
		return cardExpYymm;
	}

	public void setCardExpYymm(String cardExpYymm) {
		this.cardExpYymm = cardExpYymm;
	}

	public String getCardCvv() {
		return cardCvv;
	}

	public void setCardCvv(String cardCvv) {
		this.cardCvv = cardCvv;
	}

	public String getCavv() {
		return cavv;
	}

	public void setCavv(String cavv) {
		this.cavv = cavv;
	}

	public String getEci() {
		return eci;
	}

	public void setEci(String eci) {
		this.eci = eci;
	}

	public String getXid() {
		return xid;
	}

	public void setXid(String xid) {
		this.xid = xid;
	}

	public String getTrxId() {
		return trxId;
	}

	public void setTrxId(String trxId) {
		this.trxId = trxId;
	}

	public String getCancelType() {
		return cancelType;
	}

	public void setCancelType(String cancelType) {
		this.cancelType = cancelType;
	}

	public String getCancelMsg() {
		return cancelMsg;
	}

	public void setCancelMsg(String cancelMsg) {
		this.cancelMsg = cancelMsg;
	}

	public String getCancelUserId() {
		return cancelUserId;
	}

	public void setCancelUserId(String cancelUserId) {
		this.cancelUserId = cancelUserId;
	}

	public String getCancelUserInfo() {
		return cancelUserInfo;
	}

	public void setCancelUserInfo(String cancelUserInfo) {
		this.cancelUserInfo = cancelUserInfo;
	}

	public String getCancelRetryCnt() {
		return cancelRetryCnt;
	}

	public void setCancelRetryCnt(String cancelRetryCnt) {
		this.cancelRetryCnt = cancelRetryCnt;
	}

	public String getWorker() {
		return worker;
	}

	public void setWorker(String worker) {
		this.worker = worker;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getCardExpiry() {
		return cardExpiry;
	}

	public void setCardExpiry(String cardExpiry) {
		this.cardExpiry = cardExpiry;
	}

	public String getOnePassToken() {
		return onePassToken;
	}

	public void setOnePassToken(String onePassToken) {
		this.onePassToken = onePassToken;
	}

	public String getRecurringToken() {
		return recurringToken;
	}

	public void setRecurringToken(String recurringToken) {
		this.recurringToken = recurringToken;
	}

	public String getPreauthToken() {
		return preauthToken;
	}

	public void setPreauthToken(String preauthToken) {
		this.preauthToken = preauthToken;
	}

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public String getCustomerNm() {
		return customerNm;
	}

	public void setCustomerNm(String customerNm) {
		this.customerNm = customerNm;
	}

	public String getVaNumber() {
		return vaNumber;
	}

	public void setVaNumber(String vaNumber) {
		this.vaNumber = vaNumber;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getRecurrOpt() {
		return recurrOpt;
	}

	public void setRecurrOpt(String recurrOpt) {
		this.recurrOpt = recurrOpt;
	}

	public String getMitraCd() {
		return mitraCd;
	}

	public void setMitraCd(String mitraCd) {
		this.mitraCd = mitraCd;
	}

	public String getPayValidDt() {
		return payValidDt;
	}

	public void setPayValidDt(String payValidDt) {
		this.payValidDt = payValidDt;
	}

	public String getPayValidTm() {
		return payValidTm;
	}

	public void setPayValidTm(String payValidTm) {
		this.payValidTm = payValidTm;
	}

	public String getClickPayNo() {
		return clickPayNo;
	}

	public void setClickPayNo(String clickPayNo) {
		this.clickPayNo = clickPayNo;
	}

	public String getDataField3() {
		return dataField3;
	}

	public void setDataField3(String dataField3) {
		this.dataField3 = dataField3;
	}

	public String getClickPayToken() {
		return clickPayToken;
	}

	public void setClickPayToken(String clickPayToken) {
		this.clickPayToken = clickPayToken;
	}
	
	

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
	public String getCancelServerIp() {
		return cancelServerIp;
	}

	public void setCancelServerIp(String cancelServerIp) {
		this.cancelServerIp = cancelServerIp;
	}

	public String getCancelUserIp() {
		return cancelUserIp;
	}

	public void setCancelUserIp(String cancelUserIp) {
		this.cancelUserIp = cancelUserIp;
	}

	//Versi2
	public String makeToken(String timeStamp ,String amount, String ReferenceNo) throws Exception {
		
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		String textToken = timeStamp+merchantID + ReferenceNo + amount + merchantKey;
//		 System.out.println("Text Token : " + textToken);

		md.update(textToken.getBytes("UTF-8"));
		merchantToken = String.format("%064x", new java.math.BigInteger(1, md.digest()));
//		 System.out.println("Merchant Token : " + merchantToken);

		return merchantToken;
		
	}
	
	
	
	
	public void sendwithJson(int instructionType, String param) throws SecurityException, IOException {
		// When use HTTPClient 4.3
		/*
		 * RequestConfig requestConfig = RequestConfig.custom()
		 * .setSocketTimeout(30000) .setConnectTimeout(30000) .build();
		 */
		try {
			String url;

			if (isbDebug()) {
				switch (instructionType) {
				case 1:
					url = urlLocalRegristation;
					break;
				case 2:
					url = urlLocalPaymentV2;
					break;
				case 3:
					url = urlLocalInquiry;
					break;
				case 4:
					url = urlLocalCancel;
					break;
				default:
					url = urlLocalInquiry;
					break;
				}
			} else {
				switch (instructionType) {
				case 1:
					url = urlRealRegristation;
					/* url = urlLocalPayment; */ break;
				case 2:
					url = urlRealPaymentV2;
					/* url = urlLocalStatus; */ break;
				case 3:
					url = urlRealInquiry;
					/* url = urlLocalStatus; */ break;
				case 4:
					url = urlRealCancel;
					/* url = urlLocalStatus; */ break;
				
				default:
					url = urlRealInquiry;
					/* url = urlLocalStatus; */ break;
				}
			}
			// System.out.println(url);

			// When use HTTPClient 4.3
			// HttpClient httpclient = HttpClientBuilder.create().build();

			// When use HTTPClient 4.2
			HttpParams params = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(params, 90 * 1000);
			HttpConnectionParams.setSoTimeout(params, 30 * 1000);
			HttpClient httpclient = new DefaultHttpClient(params);

//			UrlEncodedFormEntity entity = new UrlEncodedFormEntity(param, "UTF-8");
			// System.out.println("Param " + param);
			HttpPost httpPost = new HttpPost(url);
			 httpPost.setHeader("Content-type","application/json");
			 StringEntity postingString = new StringEntity(param);

			httpPost.setEntity(postingString);
			System.out.println("Url :" +httpPost);
			// httpPost.setConfig(requestConfig); //When use HTTPClient 4.3

			HttpResponse response = null;
			
			System.out.println("params :" +param);

			try {
				response = httpclient.execute(httpPost);
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("wait 2sec");
				Thread.sleep(2000);
				response = httpclient.execute(httpPost);
			}

			// System.out.println("Response Code : " + response.toString());

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			// System.out.println("Result Value : " + result);
			if (instructionType == 5) {
				// for remove length
				setResponseString(result.toString().substring(4));
			} else if (instructionType == 12) {

				if (result.toString().startsWith("(")) {
					result.delete(0, 1);
				}
				if (result.toString().endsWith(")")) {
					result.delete(result.length() - 1, result.length());
				}
				setResponseString(result.toString());
			} else {
				setResponseString(result.toString());
			}

			//

			// System.out.println("Response String : " + responseString);
			// System.out.println("Response String () : " +
			// getResponseString());

			/*
			 * ResponseHandler<String> responseHandler = new
			 * BasicResponseHandler(); responseString =
			 * httpclient.execute(httpPost, responseHandler);
			 */

			setHtResponse(cmn.parseJSON(getResponseString()));
			/*
			 * if(!exceptionFunctionValues.contains(instructionType)){
			 * setHtResponse(cmn.parseJSON(getResponseString())); }
			 */
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

	}

	
	public void sendToPGrespHmtl(int instructionType, List<NameValuePair> param) throws SecurityException, IOException {
		// When use HTTPClient 4.3
		/*
		 * RequestConfig requestConfig = RequestConfig.custom()
		 * .setSocketTimeout(30000) .setConnectTimeout(30000) .build();
		 */
		try {
			String url;

			if (isbDebug()) {
				switch (instructionType) {
				case 1:
					url = urlLocalRegristation;
					break;
				case 2:
					url = urlLocalPaymentV2;
					break;
				default:
					url = urlLocalPaymentV2;
					break;
				}
			} else {
				switch (instructionType) {
				case 1:
					url = urlRealRegristation;
					/* url = urlLocalPayment; */ break;
				case 2:
					url = urlRealPaymentV2;
					/* url = urlLocalStatus; */ break;
				default:
					url = urlRealInquiry;
					/* url = urlLocalStatus; */ break;
				}
			}
			// System.out.println(url);

			// When use HTTPClient 4.3
			// HttpClient httpclient = HttpClientBuilder.create().build();

			// When use HTTPClient 4.2
			HttpParams params = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(params, 90 * 1000);
			HttpConnectionParams.setSoTimeout(params, 30 * 1000);
			HttpClient httpclient = new DefaultHttpClient(params);

			UrlEncodedFormEntity entity = new UrlEncodedFormEntity(param, "UTF-8");
			// System.out.println("Param " + param);
			HttpPost httpPost = new HttpPost(url);
			 httpPost.setHeader("Content-type","application/x-www-form-urlencoded");

			httpPost.setEntity(entity);
			// httpPost.setConfig(requestConfig); //When use HTTPClient 4.3

			HttpResponse response = null;
						
//			System.out.println("params 2:" +entity);
			System.out.println("params :" +param);
			System.out.println("Url :" +httpPost);

			try {
				response = httpclient.execute(httpPost);
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("wait 2sec");
				Thread.sleep(2000);
				response = httpclient.execute(httpPost);
			}
			
			

			// System.out.println("Response Code : " + response.toString());

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			
			
			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			// System.out.println("Result Value : " + result);
			if (instructionType == 5) {
				// for remove length
				setResponseString(result.toString().substring(4));
				
			} else if (instructionType == 12) {

				if (result.toString().startsWith("(")) {
					result.delete(0, 1);
				}
				if (result.toString().endsWith(")")) {
					result.delete(result.length() - 1, result.length());
				}
				setResponseString(result.toString());
			} else {
				setResponseString(result.toString());
			}

			
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				setResponseString("{\"resultCd\":\"9999\"}");
				setHtResponse(cmn.parseJSON("{\"resultCd\":\"9999\"}"));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

	}


	public void regristV2() throws Exception {
		setFunctionType(1);
		
		Hashtable<String, String> table = new Hashtable<String, String>();
		// Mandatory Field
		table.put("iMid", merchantID);
		table.put("timeStamp", timeStamp );
		table.put("payMethod", payMethod);
		table.put("currency", currency);
		table.put("amt", amt);
		table.put("referenceNo", referenceNo);
		table.put("goodsNm", goodsNm);
		table.put("billingNm", billingNm);
		table.put("billingPhone", billingPhone);
		table.put("billingEmail", billingEmail);
		table.put("billingAddr", billingAddr);
		table.put("billingCity", billingCity);
		table.put("billingState", billingState);
		table.put("billingPostCd", billingPostCd);
		table.put("billingCountry", billingCountry);
//		table.put("deliveryNm", deliveryNm);
//		table.put("deliveryPhone", deliveryPhone);
//		table.put("deliveryAddr", deliveryAddr);
//		table.put("deliveryCity", deliveryCity);
//		table.put("deliveryState", deliveryState);
//		table.put("deliveryPostCd", deliveryPostCd);
//		table.put("deliveryCountry", deliveryCountry);
//		table.put("callBackUrl", callBackUrl);
		table.put("dbProcessUrl", dbProcessUrl);
//		table.put("vat", vat);
//		table.put("fee", fee);
//		table.put("notaxAmt", notaxAmt);
//		table.put("description", description);
		table.put("merchantToken", merchantToken);
		table.put("userIP", userIP);
		table.put("cartData", cartData);
//		table.put("recurrOpt", recurrOpt);

				// Optional Field
//		table.put("reqDt", reqDt);
//		table.put("reqTm", reqTm);
//		table.put("reqDomain", reqDomain);
//		table.put("reqServerIP", reqServerIP);
//		table.put("reqClientVer", reqClientVer);
//		table.put("userSessionID", userSessionID);
//		table.put("userAgent", userAgent);
//		table.put("userLanguage", userLanguage);
		table.put("merFixAcctId", merFixAcctId);
		table.put("vacctValidDt", vacctValidDt);
		table.put("vacctValidTm", vacctValidTm);
//
				// Specific Field
				if (payMethod.equals("01")) {
//					table.put("cardCvv", cardCvv);
					table.put("instmntMon", instmntMon);
					table.put("instmntType", instmntType);
//					table.put("onePassToken", onePassToken);
				} else if (payMethod.equals("02")) {
					table.put("bankCd", bankCd);
				} else if (payMethod.equals("03")) {
					table.put("mitraCd", mitraCd);
					table.put("payValidDt", payValidDt);
					table.put("payValidTm", payValidTm);
				} else if (payMethod.equals("04")) {
					table.put("mitraCd", mitraCd);
					table.put("clickPayNo", clickPayNo);
					table.put("dataField3", dataField3);
					table.put("clickPayToken", clickPayToken);
				} else {
					table.put("mitraCd", mitraCd);
					table.put("bankCd", bankCd);
					table.put("cardCvv", cardCvv);
					table.put("instmntType", instmntType);
					table.put("instmntMon", instmntMon);
					table.put("onePassToken", onePassToken);
					table.put("payValidDt", payValidDt);
					table.put("payValidTm", payValidTm);
				}
				
				
				ObjectMapper mapper = new ObjectMapper();
				String jsonInString = mapper.writeValueAsString(table);
				

				
//				List<NameValuePair> json = cmn.ListParam(htRequest);
//				htRequest.clear();
				
//				sendToPG(getFunctionType(),json);
				sendwithJson(getFunctionType(),jsonInString);
				
				
	}
	
	public void paymentV2() throws Exception {
		setFunctionType(2);

		// Mandatory Field
//		setReq("iMid", merchantID);
		setReq("timeStamp", timeStamp);
		setReq("tXid", trxId);
		setReq("cardNo", cardNo);
		setReq("cardExpYymm", cardExpYymm);
		setReq("cardCvv", cardCvv);
		setReq("recurringToken", recurringToken);
		setReq("preauthToken", preauthToken);
		setReq("clickPayNo", clickPayNo);
		setReq("dataField3", dataField3);
		setReq("clickPayToken", clickPayToken);
		
		setReq("encrypted", encrypted);
		setReq("publicKey", publicKey);
		setReq("cardHolderNm", cardHolderNm);
		
		
		setReq("callBackUrl", callBackUrl);
		
		setReq("merchantToken", merchantToken);
		

		List<NameValuePair> json = cmn.ListParam(htRequest);
		htRequest.clear();
		
//		System.out.println("Test V2 :"+json);
		
		sendToPGrespHmtl(getFunctionType(), json);

	
	}
	
	public void inquiry() throws Exception {
		setFunctionType(3);

		// Mandatory Field
		Hashtable<String, String> table = new Hashtable<String, String>();
		table.put("timeStamp", timeStamp);
		table.put("tXid", trxId);
		table.put("iMid", merchantID);
		table.put("referenceNo", referenceNo);
		table.put("amt", amt);
		table.put("merchantToken", merchantToken);
		
		
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(table);
//		System.out.println("Test V2 :"+json);
		sendwithJson(getFunctionType(),json);

	}
	
	
	public void cancel() throws Exception {
		setFunctionType(4);

		// Mandatory Field
		Hashtable<String, String> table = new Hashtable<String, String>();
		table.put("timeStamp", timeStamp);
		table.put("tXid", trxId);
		table.put("iMid", merchantID);
		table.put("payMethod", payMethod);
		table.put("cancelType", cancelType);
		table.put("merchantToken", merchantToken);
		table.put("amt", amt);
		table.put("cancelMsg", cancelMsg);
		table.put("preauthToken", preauthToken);
		table.put("referenceNo", referenceNo);
		table.put("fee", fee);
		table.put("vat", vat);
		table.put("notaxAmt", notaxAmt);
		table.put("cancelServerIp", cancelServerIp);
		table.put("cancelUserId", cancelUserId);
		table.put("cancelUserIp", cancelUserIp);
		table.put("cancelUserInfo", cancelUserInfo);
		table.put("cancelRetryCnt", cancelRetryCnt);
		table.put("worker", worker);
		
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(table);
//		System.out.println("Test V2 :"+json);
		sendwithJson(getFunctionType(),json);

	}

}