package com.nicepay.pg.lib;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public class common {
	
	public common(){
		super();
	}
	
	/*public String ToParam(Hashtable<String, String> ht) throws Exception {
		Object[] keyArray = ht.keySet().toArray();
		Object[] valueArray = ht.values().toArray();

		String[] strKeyArray = new String[keyArray.length];
		String[] strValueArray = new String[valueArray.length];
		String paramFin = "";
		
		for (int i = 0; i < keyArray.length; i++)
		{
			strKeyArray[i] = new String((String) keyArray[i]);
			strValueArray[i] = new String((String) valueArray[i]);
			if (i == (keyArray.length-1)){
				paramFin = paramFin + strKeyArray[i] + "=" + strValueArray[i];
			}else{
				paramFin = paramFin + strKeyArray[i] + "=" + strValueArray[i]+ "&";
			}
		}
			    
	    return paramFin;
	}*/
	
	public List<NameValuePair> ListParam(Hashtable<String, String> ht) throws Exception {
		Object[] keyArray = ht.keySet().toArray();
		Object[] valueArray = ht.values().toArray();

		String[] strKeyArray = new String[keyArray.length];
		String[] strValueArray = new String[valueArray.length];
		List<NameValuePair> formParams = new ArrayList<NameValuePair>();
		
		for (int i = 0; i < keyArray.length; i++)
		{
			strKeyArray[i] = new String((String) keyArray[i]);
			strValueArray[i] = new String((String) valueArray[i]);
			formParams.add(new BasicNameValuePair(strKeyArray[i], strValueArray[i]));
		}
			    
	    return formParams;
	}
	
	public Hashtable<String, String> parseJSON(String str) throws Exception {
		Hashtable<String, String> result = new Hashtable<String, String>();
		
		JsonFactory factory = new JsonFactory();
		JsonParser  parser  = factory.createParser(str);
		
		String val = "";
		String nm = "";
		JsonToken jsonToken = parser.getCurrentToken();

		while (jsonToken != JsonToken.END_OBJECT){
		//while (parser.nextToken() != null){
		    //jsonToken = parser.getCurrentToken();

		    //System.out.println(jsonToken + " : " + parser.getText());
		    //System.out.println("get current name : " + parser.getCurrentName());
		    //System.out.println("get current value : " + parser.getValueAsString());
		    
		    nm = parser.getCurrentName();
		    
		    if(jsonToken == JsonToken.START_ARRAY){
		    	val = "{";
		    	JsonToken jsonToken1 = jsonToken;
		    	
		    	while (jsonToken1 != JsonToken.END_ARRAY) {
		    		//jsonToken1 = parser.getCurrentToken();
		    		
				    // display msg1, msg2, msg3
		    		if(jsonToken1 == JsonToken.VALUE_STRING){
				    	val += "\"" + parser.getValueAsString() + "\",";
				    	//System.out.println(nm + " " + val);
				    }else if (jsonToken1 == JsonToken.FIELD_NAME){
				    	val += "\"" + parser.getCurrentName() + "\":";
				    	//System.out.println(nm + " " + val);
				    }
		    		
		    		jsonToken1 = parser.nextToken();

		    		if(jsonToken1 == JsonToken.END_ARRAY){
		    			val = val.substring(0, val.length()-1);
				    	val += "}";
				    	jsonToken = JsonToken.END_ARRAY;
				    	//System.out.println(nm + " " + val);
				    }
		    	}
		    }
		    
		    if((jsonToken == JsonToken.VALUE_STRING) || (jsonToken == JsonToken.VALUE_NULL)){
		    	val = jsonToken == JsonToken.VALUE_NULL ? "" : parser.getValueAsString();
		    	//result.put(parser.getCurrentName(), val);
		    	result.put(nm, val);
		    	//System.out.println("Masuk : " + nm + " " + val);
		    }else if(jsonToken == JsonToken.END_ARRAY){
		    	result.put(nm, val);
		    	//System.out.println("Masuk : " + nm + " " + val);
		    }
		    //System.out.println(nm + " " + val);
		    
		    jsonToken = parser.nextToken();
		}
					    
	    return result;
	}
	
	public void printHTResult(Hashtable<String, String> result){
		Object[] keyArray = result.keySet().toArray();
		Object[] valueArray = result.values().toArray();

		String[] strKeyArray = new String[keyArray.length];
		String[] strValueArray = new String[valueArray.length];
		
		for (int i = 0; i < keyArray.length; i++)
		{
			strKeyArray[i] = new String((String) keyArray[i]);
			strValueArray[i] = new String((String) valueArray[i]);
			System.out.println(strKeyArray[i] + " : " + strValueArray[i]);
		}
	}
}
