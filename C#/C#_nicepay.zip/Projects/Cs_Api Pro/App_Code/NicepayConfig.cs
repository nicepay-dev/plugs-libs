﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

public class NicepayConfig
{
    public const string NICEPAY_IMID = "IONPAYTEST"; // Merchant ID   // use VACCTCLOSE TO test cancel VA //IONPAYTEST
    public const string NICEPAY_MERCHANT_KEY = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==";
    public const string NICEPAY_CALLBACK_URL = "https://dev.nicepay.co.id/IONPAY_CLIENT/finalResult.jsp"; // Sett by merchant
    public const string NICEPAY_DBPROCESS_URL = "https://hookb.in/Z6OQ8j5N";  // Sett by merchant
    public const sbyte NICEPAY_TIMEOUT_CONNECT = 15;

    public const sbyte NICEPAY_TIMEOUT_READ = 25;
    public const string NICEPAY_PROGRAM = "NicepayLite";
    public const string NICEPAY_VERSION = "1.0";

    public const string NICEPAY_BUILDDATE = "20160805";
    public const string NICEPAY_REQ_CC_URL = "https://www.nicepay.co.id/nicepay/api/orderRegist.do";
    public const string NICEPAY_REQ_VA_URL = "https://dev.nicepay.co.id/nicepay/api/onePass.do";
    public const string NICEPAY_CANCEL_VA_URL = "https://www.nicepay.co.id/nicepay/api/onePassAllCancel.do";
    public const string NICEPAY_ORDER_STATUS_URL = "https://www.nicepay.co.id/nicepay/api/onePassStatus.do";
    public const string NICEPAY_CREATE_TOKEN_URL = "https://www.nicepay.co.id/nicepay/api/onePassToken.do";
    public const string NICEPAY_3DS_URL = "https://www.nicepay.co.id/nicepay/api/secureVeRequest.do";
    



    public const string NICEPAY_READ_TIMEOUT_ERR = "10200";
    public const sbyte NICEPAY_LOG_CRITICAL = 1;
    public const sbyte NICEPAY_LOG_ERROR = 2;
    public const sbyte NICEPAY_LOG_NOTICE = 3;
    public const sbyte NICEPAY_LOG_INFO = 5;

    public const sbyte NICEPAY_LOG_DEBUG = 7;

}