﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _3dsecure : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string resultCd = Request.QueryString["resultCd"];
        string resultMsg = Request.QueryString["resultMsg"];
        
        if (!string.IsNullOrEmpty(resultCd) && !string.IsNullOrEmpty(resultMsg))
        {

        }
        else
        {
            string message = "Wrong Credit Card Number or 3D Secure Not Supported. Please Contact Your Card Issuer.";
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "parent.$.featherlight.close();}";
            ClientScript.RegisterStartupScript(this.GetType(), "Error 3D Secure Parameter", script, true);
        }

    }
}