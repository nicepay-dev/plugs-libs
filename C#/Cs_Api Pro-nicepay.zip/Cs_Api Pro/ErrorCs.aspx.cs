﻿using System;

public partial class ErrorCs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string MyError = Request.QueryString["ErrorNo"];
        if (MyError != null)
        {
            string message = "Error Code" + Request.QueryString["ErrorNo"] + " " + Request.QueryString["ErrorMsg"];
            string url = "CS.aspx";
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "window.location.href = '";
            script += url;
            script += "'; }";
            ClientScript.RegisterStartupScript(this.GetType(), "Error Sending Parameter", script, true);
        }     
    
    }
}