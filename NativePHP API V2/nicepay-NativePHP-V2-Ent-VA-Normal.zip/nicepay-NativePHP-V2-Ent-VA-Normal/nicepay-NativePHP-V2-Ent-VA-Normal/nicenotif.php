<?php
// required headers
if ( $_SERVER['REQUEST_METHOD'] !='POST' && $_SERVER["CONTENT_TYPE"] != 'application/x-www-form-urlencoded' ) {

    header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
    echo json_encode(array("message" => "Wrong Method or Content Type"));
    die();

}

//Nicepay Lib
include_once 'lib/NicepayLib.php';
$nicepay = new NicepayLib();
$iMid = $nicepay->iMid;
$merchantKey = $nicepay->merchantKey;


// Parameters Needed (List the Parameters you would like to accept here, see the docs for more params.)
$pushParameters = array(
    'tXid',
    'referenceNo',
    'amt',
    'merchantToken',
);
//Extract Param
$nicepay->extractNotification($pushParameters);

if(!empty($nicepay->getNotification('tXid')) && !empty($nicepay->getNotification('referenceNo'))
    && !empty($nicepay->getNotification('amt')) && !empty($nicepay->getNotification('merchantToken'))){
    // set response code - 200 Success
    http_response_code(200);
    echo json_encode(array("message" => "Notification Received, All Parameters Accepted."));

    //Wrap extracted Param
    $tXid = $nicepay->getNotification('tXid');
    $referenceNo = $nicepay->getNotification('referenceNo');
    $amt = $nicepay->getNotification('amt');
    $pushedToken = $nicepay->getNotification('merchantToken');
    $timeStamp = date("Ymdhis");

    //Set Params for Token Validation
    $nicepay->set('iMid', $iMid);
    $nicepay->set('tXid', $tXid);
    $nicepay->set('mKey', $merchantKey);
    $nicepay->set('amt', $amt);
    $nicepay->set('referenceNo', $referenceNo);

    //Generate Internal Notification Token
    $merchantToken = $nicepay->merchantTokenNotif();

    //Send Inquiry Request to Nicepay
    $paymentStatus = $nicepay->checkPaymentStatus($timeStamp, $iMid, $tXid, $referenceNo, $amt);

    //Check If token is Valid
    if($pushedToken == $merchantToken) {

        //If Payment is Success
        if (isset($paymentStatus->status) && $paymentStatus->status == '0') {
            print_r("PAYMENT RECEIVED.");//NOTIF LOGIC HERE
        }
        else if(!isset($paymentStatus->status) && $paymentStatus->status != '0') { //If Payment is Failed
            print_r("PAYMENT FAILED.");//NOTIF LOGIC HERE
        }
    }


} // tell the user data is incomplete
else{

    // set response code - 400 bad request
    http_response_code(400);
    echo json_encode(array("message" => "Notification Parameters Incomplete."));
}



