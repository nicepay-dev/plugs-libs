<?php
session_start();
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 * Please do not modify this module.
 * This module may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 09.03.2016
 *
 * 09.03.2016 Update Log
 * Please contact it.support@ionpay.net for inquiry
 *
 * ____________________________________________________________
 */
// Include the Nicepay class
// Check Payment Status
include_once('lib/NicepayLib.php');

$nicepay = new NicepayLib();

if(!empty($_POST['tXid']) && !empty($_POST['tXid'])){

    // Populate Mandatory parameters to send
    $iMid = NICEPAY_IMID;
    $nicepay->set('merchantKey', NICEPAY_MERCHANT_KEY);
    $tXid = $_POST['tXid'];
    $amt = $_POST['amt'];
    $referenceNo = $_POST['referenceNo'];
    $timeStamp = date("Ymd").date("his");
    
    // <REQUEST to NICEPAY>
    $response = $nicepay->checkPaymentStatus($timeStamp, $iMid, $tXid, $referenceNo, $amt);
    // <RESPONSE from NICEPAY>
    if (isset($response->resultCd) && $response->resultCd == "0000") {
        header("Location: checkPaymentResult.php?tXid=".$response->tXid."&reqDt=".$response->reqDt."&reqTm=".$response->reqTm."&transDt=".$response->transDt."&transTm=".$response->transTm."&resultMsg=".$response->resultMsg."&amt=".$response->amt."&referenceNo=".$response->amt.$referenceNo);

    } elseif(isset($response->resultCd)) {
        header("Location: checkPaymentResultError.php?resultCd=".$response->resultCd."&resultMsg=".$response->resultMsg."&tXid=".$_POST['tXid']."");

    } else {
        header("Location: otherErrorPage.php?msg=Connection Timeout. Please Try again.");

    }
    // echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
    // echo "<pre>";
    // var_dump($response);
    // echo "</pre>";

} else {
    header("Location: otherErrorPage.php?msg=Please Set Amount, ReferenceNo and tXid.");
    // echo "Please set amount, referenceNo and tXid";
}

