<?php
session_start();
if (isset($_REQUEST['resultCd']) && $_REQUEST['resultCd'] == "0000") {
    header("Location: result.php"."?tXid=".$_REQUEST['tXid']."&referenceNo=".$_REQUEST['referenceNo']."&amt=".$_REQUEST['amt']."&description=".$_REQUEST['description']);
} elseif(isset($_REQUEST['resultCd'])) {
    header("Location: otherErrorPage.php?msg=Result: ".$_REQUEST['resultCd'].", ".$_REQUEST['resultMsg']);
} else {
    header("Location: otherErrorPage.php?msg=Connection Timeout. Please Try again.");
}