<?php
session_start();

// Include Config File
include_once "lib/NicepayConfig.php";

$X_CLIENT_KEY = "IONPAYTEST";

date_default_timezone_set('Asia/Jakarta');
$X_TIMESTAMP = date('c');

$authorization = "Bearer ".$_POST['accessToken'];
$channel = X_CLIENT_KEY.rand();
$external = "EXT".rand();
$partner = X_CLIENT_KEY.rand();
$secretClient = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==";
$body = '{"partnerReferenceNo":"RefnoTrx2023022831412308602932713","merchantId":"IONPAYTEST","subMerchantId":"","amount":{"value":"10000.00","currency":"IDR"},"urlParam":[{"url":"https://test1.bi.go.id/v1/test","type":"PAY_NOTIFY","isDeeplink":"Y"},{"url":"https://test2.bi.go.id/v1/test","type":"PAY_RETURN","isDeeplink":"Y"}],"externalStoreId":"","serviceCode":"","pointOfInitiation":"","additionalInfo":{"mitraCd":"ESHP","goodsNm":"John Doe","billingNm":"John Doe","billingPhone":"082111111111","callBackUrl":"https://merchant.com/api/callBackUrl/Callback","dbProcessUrl":"https://merchant.com/api/dbProcessUrl/Notif","cartData":"{\"count\":\"1\",\"item\":[{\"img_url\":\"http://merchant.com/cel lphones/iphone5s_64g\",\"goods_name\":\"iPhone 5S\",\"goods_detail\":\"iPhone 5S - BB123456\",\"goods_amt\":\"10000.00\",\"goods_quantity\":\"1\"}]}"}}';
$hashBody = strtolower(hash("SHA256", $body));

$stirgSign = "POST:/api/v1.0/debit/payment-host-to-host:".$_POST['accessToken'].":".$hashBody.":".$X_TIMESTAMP;
$bodyHasing = hash_hmac("sha512", $stirgSign, $secretClient, true);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, NICEPAY_PAYMENT_EWALLET_URL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'X-SIGNATURE: '.base64_encode($bodyHasing),
    'X-CLIENT-KEY: '.$X_CLIENT_KEY,
    'X-TIMESTAMP: '.$X_TIMESTAMP,
    'Authorization: '.$authorization,
    'CHANNEL-ID: '.$channel,
    'X-EXTERNAL-ID: '.$external,
    'X-PARTNER-ID: '.$X_CLIENT_KEY
));

$output = curl_exec($ch);
$data = json_decode($output);

$responseCode = $data->responseCode;
$responseMessage = $data->responseMessage;

if($responseCode == '5005400' || $responseCode == '5045400' || $responseCode == '2025400' || $responseCode == '4015400' 
|| $responseCode == '4005400' || $responseCode == '4035400' || $responseCode == '4045400' || $responseCode == '4095400' ) {
    $partnerReferenceNo = "";
    $originalReferenceNo = "";
} else {
    $responseCode = $data->responseCode;
    $partnerReferenceNo = $data->partnerReferenceNo;
    $originalReferenceNo = $data->originalReferenceNo;
    $appRedirectUrl = $data->appRedirectUrl;
    $webRedirectUrl = $data->webRedirectUrl;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <meta http-equiv="refresh" content="900; url=http://localhost/BI-SNAP-EWALLET-NativePHP/">
    <title>Result - Payment ShopeePay</title>

    <!-- CSS -->
	<link rel='stylesheet' href='index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Images -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <link rel="icon" href="favicon.ico" type="image/x-icon" />

    <style>
        input[type="text"],
        input[type="number"],select {
            font-size:16px;
            padding:10px 10px 10px 5px;
            display:block;
            width:100%;
            border:none;
            border-bottom:1px solid #34CACA;
            text-transform: none;
        }
        .label{
            width: 100%;position: relative;top: 0px;display: block;user-select: none;
        }
    </style>
</head>

<body>
    <div class="form-style-8">
        <h2>
            <img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">Result Ewallet - ShopeePay
        </h2>
        <div class="group mitra-cd">
            <label class="label">Response Code</label>
            <input readonly type="text" name="responseCode" id="responseCode" value="<?php echo $responseCode; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group mitra-cd">
            <label class="label">Response Message</label>
            <input readonly type="text" name="responseMessage" id="responseMessage" value="<?php echo $responseMessage; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Partner ReferenceNo</label>
            <input readonly type="text" name="partnerReferenceNo" id="partnerReferenceNo" value="<?php echo $partnerReferenceNo; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Original ReferenceNo</label>
            <input readonly type="text" name="originalReferenceNo" id="originalReferenceNo" value="<?php echo $originalReferenceNo; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">App Redirect Url</label>
            <input readonly type="text" name="appRedirectUrl" id="appRedirectUrl" value="<?php echo $appRedirectUrl; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Web Redirect Url</label>
            <input readonly type="text" name="webRedirectUrl" id="webRedirectUrl" value="<?php echo $webRedirectUrl; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <a href="http://localhost/BI-SNAP-EWALLET-NativePHP/"><input type="button" value="back" /></a>
    </div>
</body>
</html>