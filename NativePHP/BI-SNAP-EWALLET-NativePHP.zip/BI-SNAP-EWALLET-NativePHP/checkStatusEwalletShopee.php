<?php
session_start();

// Include Config File
include_once "lib/NicepayConfig.php";

$X_CLIENT_KEY = "IONPAYTEST";

date_default_timezone_set('Asia/Jakarta');
$X_TIMESTAMP = date('c');

$authorization = "Bearer ".$_POST['accessToken'];
$channel = X_CLIENT_KEY.rand();
$external = "EXT".rand();
$partner = X_CLIENT_KEY.rand();
$secretClient = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==";
$body = '{"merchantId": "IONPAYTEST","subMerchantId": "","originalPartnerReferenceNo": "RefnoTrx2023022831412308602932713","originalReferenceNo": "IONPAYTEST05202302221847404252","serviceCode": "54","transactionDate": "2020-12-21T14:56:11+07:00","externalStoreId":"","amount": {"value": "10000.00","currency": "IDR"},"additionalInfo": {}}';
$hashBody = strtolower(hash("SHA256", $body));

$stirgSign = "POST:/api/v1.0/debit/status:".$_POST['accessToken'].":".$hashBody.":".$X_TIMESTAMP;
$bodyHasing = hash_hmac("sha512", $stirgSign, $secretClient, true);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, NICEPAY_CHECK_STATUS_URL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'X-SIGNATURE: '.base64_encode($bodyHasing),
    'X-CLIENT-KEY: '.$X_CLIENT_KEY,
    'X-TIMESTAMP: '.$X_TIMESTAMP,
    'Authorization: '.$authorization,
    'CHANNEL-ID: '.$channel,
    'X-EXTERNAL-ID: '.$external,
    'X-PARTNER-ID: '.$X_CLIENT_KEY
));

$output = curl_exec($ch);
$data = json_decode($output);

$responseCode = $data->responseCode;
$responseMessage = $data->responseMessage;

if($responseCode == '5005500' || $responseCode == '5045500' || $responseCode == '2025500' || $responseCode == '4015500' 
|| $responseCode == '4005500' || $responseCode == '4035500' || $responseCode == '4045500' || $responseCode == '4095500' || $responseCode == '4045501' ) {
    $originalPartnerReferenceNo = "";
    $originalReferenceNo = "";
    $serviceCode = "";
    $latestTransactionStatus = "";
    $transactionStatusDesc = "";
    $currency = "";
    $value = "";
    $goodsNm = "";
    $mitraCd = "";
    $billingPhone = "";
    $billingNm = "";
} else {
    $originalPartnerReferenceNo = $data->originalPartnerReferenceNo;
    $originalReferenceNo = $data->originalReferenceNo;
    $serviceCode = $data->serviceCode;
    $latestTransactionStatus = $data->latestTransactionStatus;
    $transactionStatusDesc = $data->transactionStatusDesc;
    $currency = $data->transAmount->currency;
    $value = $data->transAmount->value;
    $goodsNm = $data->additionalInfo->goodsNm;
    $mitraCd = $data->additionalInfo->mitraCd;
    $billingPhone = $data->additionalInfo->billingPhone;
    $billingNm = $data->additionalInfo->billingNm;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Riko Adi Setiawan">
    <meta http-equiv="refresh" content="900; url=http://localhost/BI-SNAP-EWALLET-NativePHP/">
    <title>Result - Cek Status Shopee</title>

    <!-- CSS -->
	<link rel='stylesheet' href='index.css' type='text/css'/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Images -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <link rel="icon" href="favicon.ico" type="image/x-icon" />

    <style>
        input[type="text"],
        input[type="number"],select {
            font-size:16px;
            padding:10px 10px 10px 5px;
            display:block;
            width:100%;
            border:none;
            border-bottom:1px solid #34CACA;
            text-transform: none;
        }
        .label{
            width: 100%;position: relative;top: 0px;display: block;user-select: none;
        }
    </style>
</head>

<body>
    <div class="form-style-8">
        <h2>
            <img class="img-valign" style="width: 60px; height:auto" src="nicepay_logo.jpg" alt="">Result Check Status Ewallet - Shopee
        </h2>
        <div class="group mitra-cd">
            <label class="label">Response Message</label>
            <input readonly type="text" name="responseMessage" id="responseMessage" value="<?php echo $responseMessage; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Original Partner ReferenceNo</label>
            <input readonly type="text" name="originalPartnerReferenceNo" id="originalPartnerReferenceNo" value="<?php echo $originalPartnerReferenceNo; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Original ReferenceNo</label>
            <input readonly type="text" name="originalReferenceNo" id="originalReferenceNo" value="<?php echo $originalReferenceNo; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Service Code</label>
            <input readonly type="text" name="serviceCode" id="serviceCode" value="<?php echo $serviceCode; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Latest Transaction Status</label>
            <input readonly type="text" name="latestTransactionStatus" id="latestTransactionStatus" value="<?php echo $latestTransactionStatus; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Transaction Status Desc</label>
            <input readonly type="text" name="transactionStatusDesc" id="transactionStatusDesc" value="<?php echo $transactionStatusDesc; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Currency</label>
            <input readonly type="text" name="currency" id="currency" value="<?php echo $currency; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Value</label>
            <input readonly type="text" name="value" id="value" value="<?php echo $value; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Goods Name</label>
            <input readonly type="text" name="goodsNm" id="goodsNm" value="<?php echo $goodsNm; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Mitra Code</label>
            <input readonly type="text" name="mitraCd" id="mitraCd" value="<?php echo $mitraCd; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Billing Phone</label>
            <input readonly type="text" name="billingPhone" id="billingPhone" value="<?php echo $billingPhone; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <div class="group">
            <label class="label">Billing Name</label>
            <input readonly type="text" name="billingNm" id="billingNm" value="<?php echo $billingNm; ?>"/>
            <span class="highlight"></span>
            <span class="bar"></span>
        </div>
        <a href="http://localhost/BI-SNAP-EWALLET-NativePHP/"><input type="button" value="back" /></a>
    </div>
</body>
</html>