<?php
session_start();
if (isset($_REQUEST['iMid']) || $_REQUEST['iMid'] != '' || $_REQUEST['iMid'] != null){
    $_SESSION["iMid"] = $_REQUEST['iMid'];
}
if (isset($_REQUEST['mKey']) || $_REQUEST['mKey'] != '' || $_REQUEST['mKey'] != null){
    $_SESSION["mKey"] = $_REQUEST['mKey'];
}
if (isset($_REQUEST['env']) || $_REQUEST['env'] != '' || $_REQUEST['env'] != null){
    $_SESSION["env"] = $_REQUEST['env'];
}
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 * Please do not modify this module.
 * This module may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 09.03.2016
 *
 * 09.03.2016 Update Log
 * Please contact it.support@ionpay.net for inquiry
 *
 * ____________________________________________________________
 */
// Include the Nicepay class
// Cancel Transaction (VA can be canceled only if VA status is not paid)
include_once('lib/NicepayLib.php');

$nicepay = new NicepayLib();
if(!empty($_POST['tXid']) && !empty($_POST['tXid'])){

    $nicepay->set('iMid', NICEPAY_IMID);
    $nicepay->set('merchantKey', NICEPAY_MERCHANT_KEY);
    $nicepay->set('payMethod', '01');
    $nicepay->set('tXid', $_POST['tXid']);
    $nicepay->set('cancelType', $_POST['cancelType']);
    $nicepay->set('referenceNo', $_POST['referenceNo']);
    $nicepay->set('timeStamp', date("Ymd").date("his"));
    if ($_POST['cancelType']=='2'){
        $nicepay->set('amt', $_POST['amt']/2);
    }
    $nicepay->set('amt', $_POST['amt']);

    // $merchantToken = $nicepay->merchantTokenCancel();

    // $nicepay->set('merchantToken', $merchantToken);
//    echo $nicepay->get('merchantToken');
//    exit();
    // <REQUEST to NICEPAY>
    $response = $nicepay->cancelTrans();

    // <RESPONSE from NICEPAY>
    if (isset($response->resultCd) && $response->resultCd == "0000") {
        header("Location: cancelResult.php?tXid=".$response->tXid."&canceltXid=".$response->canceltXid."&amt=".$response->amt."&transDt=".$response->transDt."&transTm=".$response->transTm."&resultMsg=".$response->resultMsg."");
    } elseif(isset($response->resultCd)) {
        header("Location: cancelResultError.php?resultCd=".$response->resultCd."&resultMsg=".$response->resultMsg."&tXid=".$_POST['tXid']."");

    } else {
        header("Location: otherErrorPage.php?msg=Connection Timeout. Please Try again.");
    }

} else {
    header("Location: otherErrorPage.php?msg=Please Set Amount, ReferenceNo and tXid.");
    // alert("Please Set Amount, ReferenceNo and tXid");
}