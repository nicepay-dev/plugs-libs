# API Documentation

## Configuration :

- `X_CLIENT_KEY => lib/NicepayConfig.php`
- `NICEPAY_REQ_ACCESS_TOKEN_URL => lib/NicepayConfig.php`
- `NICEPAY_GENERATE_VA_URL => lib/NicepayConfig.php`
- `NICEPAY_PRIVATE_KEY => lib/NicepayConfig.php`

## Endpoints :

List of available endpoints:

- `POST /BI-SNAP-VA-NativePHP/requestToken.php`
- `POST /BI-SNAP-VA-NativePHP/virtualAccount.php`

&nbsp;

## 1. POST /BI-SNAP-VA-NativePHP/requestToken.php

Request:

- body:

```json
{
  "grantType": "client_credentials",
  "additionalInfo": {

  }
}
```

_Response (Successful)_

```json
{
  "responseCode": "2007300",
  "responseMessage": "Successful",
  "accessToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJJT05QQVlURVNUIiwiaXNzIjoiTklDRVBBWSIsIm5hbWUiOiJCQkJBIiwiZXhwIjoiMjAyMy0wMi0wN1QwNDoxODoxM1oifQ==.IhwnC5Jip2WDs70EP2LnS3dGBd4rXwX1VU0JQEPeBrg=",
  "tokenType": "Bearer",
  "expiresIn": "900"
}
```

&nbsp;

## 2. POST /BI-SNAP-VA-NativePHP/virtualAccount.php

Request:

- body:

```json
{
  "bankCd": "BMRI"
}
```

_Response (Successful)_

```json
{
  "responseCode": "2002700",
  "responseMessage": "Successful",
  "virtualAccountData": {
    "partnerServiceId": "",
    "customerNo": "",
    "virtualAccountNo": "70014000091105313300",
    "virtualAccountName": "John Doe",
    "trxId": "2022020100000000000001",
    "totalAmount":{
      "value": "10000.00",
      "currency": "IDR"
    },
    "additionalInfo":{
      "bankCd": "BMRI",
      "tXidVA": "IONPAYTEST02202302071105313300",
      "goodsNm": "John Doe",
      "vacctValidDt": "20230209",
      "vacctValidTm": "110531",
      "msId": "",
      "msFee": "",
      "msFeeType": "",
      "mbFee": "",
      "mbFeeType": ""
    }
  }
}
```

&nbsp;
