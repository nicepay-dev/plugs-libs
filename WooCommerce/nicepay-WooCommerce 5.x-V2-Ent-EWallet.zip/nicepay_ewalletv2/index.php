<?php
/*
  Plugin Name: NICEPay E-wallet V2 Payment Gateway
  Plugin URI: http://nicepay.co.id
  Description: NICEPay Plugin for WooCommerce to support payment via OVO, LinkAja, DANA and Shopeepay.
  Version: 6.0
  Author: NICEPay <codeNinja>
  Author URI: http://nicepay.co.id
*/

if (!defined('ABSPATH')) {
    exit;
}
if ( is_readable( __DIR__ . '/other_libs/php-qrcode/vendor/autoload.php' ) ) {
    require __DIR__ . '/other_libs/php-qrcode/vendor/autoload.php';
}

add_action('plugins_loaded', 'woocommerce_nicepay_ewalletv2_init');
use libraryEWallet\Config as EWalletConfig;
use chillerlan\QRCode\QRCode;
require_once 'other_libs/Mobile_Detect.php';

function woocommerce_nicepay_ewalletv2_init() {
    // Validation class payment gateway woocommerce
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Gateway_NICEPay_EWalletV2 extends WC_Payment_Gateway {

        public function nicepay_item_name($item_name) {
            if (strlen($item_name) > 127) {
                $item_name = substr($item_name, 0, 124) . '...';
            }
            return html_entity_decode($item_name, ENT_NOQUOTES, 'UTF-8');
        }

        public function __construct() {
            // plugin id
            $this->id = 'nicepay_ewalletv2';
            // Payment Gateway title
            $this->method_title = 'NICEPay E-wallet Payment Gateway';
            // true only in case of direct payment method, false in our case
            $this->has_fields = false;
            // redirect URL
            $this->redirect_url = str_replace('https:', 'http:', add_query_arg('wc-api', 'WC_Gateway_NICEPay_EWalletV2', home_url('/')));
            //Load settings
            $this->init_form_fields(); // load function init_form_fields()
            $this->init_settings();

            // Define user set variables
            $this->enabled = $this->get_option('enabled');
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->iMid = $this->get_option('iMid');
            $this->mKey = $this->get_option('mKey');
            //---------------------------------------------//
            $this->reduceStock   = $this->get_option( 'reduceStock' );
            //---------------------------------------------//
            $this->ovo = $this->get_option('ovo');
            $this->linkaja = $this->get_option('linkaja');
            $this->dana = $this->get_option('dana');
            $this->shopeepay = $this->get_option('shopeepay');

            // payment gateway logo
            /*if ($this->ovo == "yes" && $this->linkaja == "yes"){
                $this->payment_logo = '/ovo_link.png';
            } elseif ($this->ovo == "yes") {
                $this->payment_logo = '/ovo.png';
            } elseif ($this->linkaja == "yes") {
                $this->payment_logo = '/link.png';
            }
            */
            $this->icon = plugins_url('/mainlogo.png', __FILE__);

            // Actions
            $this->includes();
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(&$this, 'process_admin_options'));
            add_action('woocommerce_receipt_nicepay_ewalletv2', array(&$this, 'receipt_page'));
            add_action('woocommerce_thankyou', array($this, 'add_description_payment_success'), 1);
            add_action('woocommerce_api_wc_gateway_nicepay_ewalletv2', array($this, 'notification_handler'));
            add_filter( 'woocommerce_cart_totals_fee_html', array( $this, 'modify_fee_html_for_taxes' ), 10, 2 );
            add_action('woocommerce_email_order_details', array($this, 'np_add_payment_email_detail'),1, 4);
            add_action('woocommerce_email_subject_customer_processing_order', array($this, 'np_change_subject_payment_email_detail'),1, 2);

            /*add_action( 'template_redirect', 'wc_nicepay_redirect_after_purchase' );*/
        }

        // function add_content() {}
        function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'label' => 'Enable NICEPay',
                    'type' => 'checkbox',
                    'description' => '',
                    'default' => 'no',
                ),
                'title' => array(
                    'title' =>'Title',
                    'type' => 'text',
                    'description' => '',
                    'default' => 'Pembayaran NICEPay Virtual Payment',
                ),
                'description' => array(
                    'title' => 'Description',
                    'type' => 'textarea',
                    'description' => '',
                    'default' => 'Sistem pembayaran menggunakan NICEPay Virtual Payment.',
                ),
                'iMid' => array(
                    'title' => 'Merchant ID',
                    'type' => 'text',
                    'description' => '<small>Isikan dengan Merchant ID dari NICEPay</small>.',
                    'default' => 'IONPAYTEST',
                ),
                'mKey' => array(
                    'title' => 'Merchant Key',
                    'type' => 'text',
                    'description' =>'<small>Isikan dengan Merchant Key dari NICEPay</small>.',
                    'default' => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
                ),
                'reduceStock' => array(
                    'title' => __('Reduce stock', 'woocommerce'),
                    'type' => 'checkbox',
                    'description' => __('<small>Check to enable.</small>', 'woocommerce'),
                    'default' => 'no',
                ),
                'ovo' => array(
                    'title' => 'OVO',
                    'type' => 'checkbox',
                    'description' => '<small>Check to enable. Please confirm to NICEPay before changing this.</small>',
                    'default' => 'yes',
                ),
                'linkaja' => array(
                    'title' => 'LinkAja',
                    'type' => 'checkbox',
                    'description' => '<small>Check to enable. Please confirm to NICEPay before changing this.</small>',
                    'default' => 'yes',
                ),
                'dana' => array(
                    'title' => 'DANA',
                    'type' => 'checkbox',
                    'description' => '<small>Check to enable. Please confirm to NICEPay before changing this.</small>',
                    'default' => 'yes',
                ),
                'shopeepay' => array(
                    'title' => 'Shopeepay',
                    'type' => 'checkbox',
                    'description' => '<small>Check to enable. Please confirm to NICEPay before changing this.</small>',
                    'default' => 'yes',
                ),
                'shopIdDANA' => array(
                    'title' => 'Shop ID DANA',
                    'type' => 'text',
                    'description' => '<small>Leave blank if unknown.</small>',
                    'default' => '',
                ),
                'shopIdESHP' => array(
                    'title' => 'Shop ID Shopeepay',
                    'type' => 'text',
                    'description' => '<small>Leave blank if unknown.</small>',
                    'default' => '',
                ),
            );
        }

        // what this function for?
        public function admin_options() {
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        }

        function payment_fields() {
            if ($this->description) {
                echo wpautop(wptexturize($this->description));
                $payment = $this->payment_list();

                echo "Pilih Mitra : ";
                echo '<select name="mitraCdEWalletV2">';
                foreach($payment as $key => $val) {
                    if($payment[$key]["enabled"] == "yes") {
                        echo '<option value="'.$key.'">'.$payment[$key]["label"].'</option>';
                    }
                }
                echo '</select>';

                echo '<div class="form-row form-row-wide"><label>Mobile Phone Number<span class="required">*</span></label>
		<input name="ewalletNumber" type="tel" id="nicephone" placeholder="082-1234-xxxx" required autocomplete="off">
		</div>';

                echo '<div class="clear"></div></fieldset>';
            }
        }

        // what this function for?
        public function validate_fields() {
            WC()->session->set('mitraCd', $_POST["mitraCdEWalletV2"]);
            WC()->session->set('ewalletNumber', $_POST["ewalletNumber"]);
        }

        function payment_list() {
            $payment = array(
                "OVOE" => array(
                    "label" => "OVO",
                    "enabled" => $this->ovo,
                ),
                "LINK" => array(
                    "label" => "LinkAja",
                    "enabled" => $this->linkaja,
                ),
                "DANA" => array(
                    "label" => "DANA",
                    "enabled" => $this->dana,
                ),
                "ESHP" => array(
                    "label" => "Shopeepay (Mobile Only)",
                    "enabled" => $this->shopeepay,
                ),
            );

            return $payment;
        }

        function receipt_page($order) {
            echo $this->generate_nicepay_form($order);
        }

        function includes() {
            // Validation class payment gateway woocommerce
            if (!class_exists('NicepayLibEWalletV2')) {
                include_once "NicepayLibEWalletV2/NicepayLibEWalletV2.php";
            }
        }

        function konversi($nilai, $currency) {
            if ($currency == 'USD') {
                return $nilai*(int)13500;
            } else {
                return $nilai*(int)1;
            }
        }

        public function generate_nicepay_form($order_id) {

            $order = new WC_Order($order_id);
            $currency = $order->get_currency();
            $fees = $order->get_fees();

            $total_quantity = 0;

            if (sizeof($order->get_items()) > 0) {
                foreach ($order->get_items() as $item) {
                    if (!$item['qty']) {
                        continue;
                    }


                    $item_name = $item->get_name();;
                    $item_quantity = $item->get_quantity();
                    $product_id = $item->get_product_id();
                    $item_cost_non_discount = $item->get_subtotal();
                    $item_cost_discounted = $item->get_total();;
                    $item_url = get_permalink($product_id);

                    $orderInfo[] = array(
                        'goods_name' => $this->nicepay_item_name($item_name),
                        'goods_detail' => $this->nicepay_item_name($item_name),
                        'goods_amt' => strval($this->konversi($item_cost_non_discount/$item_quantity, $currency)),
                        'goods_quantity' => strval($item_quantity),
                        'img_url' => "https://image.freepik.com/free-psd/simple-black-men-s-tee-mockup_53876-57893.jpg"
                    );

                    if (count($orderInfo) < 0) {
                        return false; // Abort - negative line
                    }

                    $total_quantity = $total_quantity + $item_quantity;
                }

                function clean($string) {
                    $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

                    return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
                }

                // Loop over $cart fees
                if(!empty($fees)) {
                    foreach ( $fees as $fees_key => $fee ) {
                        $name = $fee['name'];
                        $total = $fee['total'];
                        if($total != 0){
                            $orderInfo[] = array(
                                'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
                                'goods_name' => clean($name),
                                'goods_detail' => clean($name)." for ".$order_id,
                                'goods_amt' => wc_float_to_string($total),
                                'goods_quantity' => "1",
                                'goods_url' => "https://".$_SERVER['SERVER_NAME']
                            );
                        }
                        $total_quantity = $total_quantity + 1;
                    }
                }


                //Shipping
                if($order->calculate_shipping() > 0){
                    $orderInfo[] = array(
                        'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
                        'goods_name' => "Shipping Fee",
                        'goods_detail' => $order->get_shipping_method(),
                        'goods_amt' => wc_float_to_string($order->calculate_shipping()),
                        'goods_quantity' => "1",
                        'goods_url' => "https://".$_SERVER['SERVER_NAME']
                    );
                    $total_quantity = $total_quantity + 1;
                }


                if (WC()->session->get('mitraCd') == 'LINK'){
                    //Coupons
                    $coupons = $order->get_coupon_codes();
                    if(!empty($coupons)) {
                        foreach ($coupons as $coupon_code) {
                            $coupon = new WC_Coupon($coupon_code);
                            $couponName = $coupon_code;

                            $orderInfo[] = array(
                                'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
                                'goods_name' => "COUPON",
                                'goods_detail' => $couponName." ".$coupon->get_amount(),
                                'goods_quantity' => "1",
                                'goods_amt' => "-".$coupon->get_amount(),
                                'goods_url' => "https://".$_SERVER['SERVER_NAME']
                            );
                            $total_quantity = $total_quantity + 1;
                        }
                    }
                    $cartData = array(
                        'count' => strval(count($orderInfo)),
                        'item' => $orderInfo
                    );
                } elseif (WC()->session->get('mitraCd') == 'OVOE'){
                    //Coupons
                    $coupons = $order->get_coupon_codes();
                    if(!empty($coupons)) {
                        foreach ($coupons as $coupon_code) {
                            $coupon = new WC_Coupon($coupon_code);
                            $couponName = $coupon_code;

                            $orderInfo[] = array(
                                'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
                                'goods_name' => "COUPON",
                                'goods_detail' => $couponName." ".$coupon->get_amount(),
                                'goods_quantity' => "1",
                                'goods_amt' => "-".$coupon->get_amount(),
                                'goods_url' => "https://".$_SERVER['SERVER_NAME']
                            );
                            $total_quantity = $total_quantity + 1;
                        }
                    }
                    $cartData = array(
                        'count' => strval(count($orderInfo)),
                        'item' => $orderInfo
                    );
                } elseif (WC()->session->get('mitraCd') == 'DANA'){
                    $coupons = $order->get_coupon_codes();
                    if(!empty($coupons)) {
                        echo "<h1>Coupons are not supported for DANA. </br>Please try other Payment Methods.</h1>";
                        return null;
                    } else {
                        $cartData = array(
                            'count' => strval(count($orderInfo)),
                            'item' => $orderInfo
                        );
                    }
                } elseif (WC()->session->get('mitraCd') == 'ESHP'){
                    $coupons = $order->get_coupon_codes();
                    if(!empty($coupons)) {
                        echo "<h1>Coupons are not supported for Shopeepay. </br>Please try other Payment Methods.</h1>";
                        return null;
                    } else {
                        $cartData = array(
                            'count' => strval(count($orderInfo)),
                            'item' => $orderInfo
                        );
                    }
                }


            }

            //Order Total
            if($currency == 'USD'){
                $order_total = $this->get_order_total()*(int)13500;
            }else{
                $order_total = $this->get_order_total();
            }

            //Get current user
            $current_user = wp_get_current_user();

            //Get Address customer
            $billingFirstName = ($current_user->ID == 0) ? $order->get_billing_first_name() : get_user_meta($current_user->ID, "billing_first_name", true);
            $billingLastName = ($current_user->ID == 0) ? $order->get_billing_last_name() : get_user_meta($current_user->ID, "billing_last_name", true);
            $billingNm = $billingFirstName." ".$billingLastName;
            $billingPhone = ($current_user->ID == 0) ? $order->get_billing_phone() : get_user_meta($current_user->ID, "billing_phone", true);
            $billingEmail = ($current_user->ID == 0) ? $order->get_billing_email() : get_user_meta($current_user->ID, "billing_email", true);
            $billingAddr1 = ($current_user->ID == 0) ? $order->get_billing_address_1() : get_user_meta($current_user->ID, "billing_address_1", true);
            $billingAddr2 = ($current_user->ID == 0) ? $order->get_billing_address_2() : get_user_meta($current_user->ID, "billing_address_2", true);
            $billingAddr = $billingAddr1."-".$billingAddr2;
            $billingCity = ($current_user->ID == 0) ? $order->get_billing_city() : get_user_meta($current_user->ID, "billing_city", true);
            $billingState = WC()->countries->states[$order->get_billing_country()][$order->get_billing_state()];
            $billingPostCd = ($current_user->ID == 0) ? $order->get_billing_postcode() : get_user_meta($current_user->ID, "billing_postcode", true);
            $billingCountry = WC()->countries->countries[$order->get_billing_country()];

            $deliveryFirstName = $order->get_shipping_first_name();
            $deliveryLastName = $order->get_shipping_last_name();
            $deliveryNm = $deliveryFirstName." ".$deliveryLastName;
            $deliveryPhone = ($current_user->ID == 0) ? $order->get_billing_phone() : get_user_meta($current_user->ID, "billing_phone", true);
            $deliveryEmail = ($current_user->ID == 0) ? $order->get_billing_email() : get_user_meta($current_user->ID, "billing_email", true);
            $deliveryAddr1 = $order->get_shipping_address_1();
            $deliveryAddr2 = $order->get_shipping_address_2();
            $deliveryAddr = $deliveryAddr1." ".$deliveryAddr2;
            $deliveryCity = $order->get_billing_city();
            $deliveryState = WC()->countries->states[$order->get_shipping_country()][$order->get_shipping_state()];
            $deliveryPostCd = $order->get_shipping_postcode();
            $deliveryCountry = WC()->countries->countries[$order->get_shipping_country()];

            // Prepare Parameters
            $nicepay = new NicepayLibEWalletV2();

            $dateNow        = date('Ymd');

            $nicepay->set('mKey', $this->mKey);
            $paymentExpiryDate   = date('Ymd', strtotime($dateNow . ' +1 day'));
            $paymentExpiryTime   = date('His', strtotime($dateNow . ' +1 hour'));
            $timeStamp = date("Ymdhis");
            $nicepay->set('timeStamp', $timeStamp);
            //$nicepay->set('instmntType', '2');
            //$nicepay->set('instmntMon', '1');
            $nicepay->set('payValidDt', $paymentExpiryDate);
            $nicepay->set('payValidTm', $paymentExpiryTime);
            $nicepay->set('iMid', $this->iMid);
            $nicepay->set('payMethod', '05');
            $nicepay->set('currency', 'IDR');
            $nicepay->set('amt', $order_total);
            $nicepay->set('referenceNo', $order_id);
            $nicepay->set('goodsNm', 'Payment of invoice No '.$order_id);
            $nicepay->set('dbProcessUrl', WC()->api_request_url('WC_Gateway_NICEPay_EWalletV2'));
            $nicepay->set('description', 'Payment of invoice No '.$order_id);
            $merchantToken = $nicepay->merchantToken();
            $nicepay->set('merchantToken', $merchantToken);
            $nicepay->set('reqDt', date('Ymd'));
            $nicepay->set('reqTm', date('His'));
            $nicepay->set('mitraCd', WC()->session->get('mitraCd'));
            $nicepay->set('userIP', $nicepay->getUserIP());
            $nicepay->set('cartData', json_encode($cartData, JSON_UNESCAPED_SLASHES ));
            //$nicepay->set('sellers', json_encode($sellers, JSON_UNESCAPED_SLASHES ));
            $nicepay->set('billingNm', $billingNm);
            $nicepay->set('billingPhone', WC()->session->get('ewalletNumber'));
            $nicepay->set('billingEmail', $billingEmail);
            $nicepay->set('billingAddr', $billingAddr);
            $nicepay->set('billingCity', $billingCity);
            $nicepay->set('billingState', $billingState);
            $nicepay->set('billingPostCd', $billingPostCd);
            $nicepay->set('billingCountry', $billingCountry);
            $nicepay->set('deliveryNm', $deliveryNm);
            $nicepay->set('deliveryPhone', $deliveryPhone);
            $nicepay->set('deliveryAddr', $deliveryAddr);
            $nicepay->set('deliveryCity', $deliveryCity);
            $nicepay->set('deliveryState', $deliveryState);
            if(WC()->session->get('mitraCd') == 'DANA')
            {
                $nicepay->set('shopId', $this->get_option('shopIdDANA'));
            } elseif (WC()->session->get('mitraCd') == 'ESHP') {
                $nicepay->set('shopId', $this->get_option('shopIdESHP'));
            }
            $nicepay->set('deliveryPostCd', $deliveryPostCd);
            $nicepay->set('deliveryCountry', $deliveryCountry);

            unset($nicepay->requestData['mKey']);

            // Send Data
            $registResponse = $nicepay->requestEWalletV2();

            // Response from NICEPAY
            if (isset($registResponse->resultCd) && $registResponse->resultCd == "0000") {
                $order->add_order_note(__('Menunggu pembayaran melalui NICEPay Payment Gateway dengan id transaksi '.$registResponse->tXid, 'woocommerce'));

                //Set Session
                WC()->session->set('resultCd', $registResponse->resultCd); //from response
                WC()->session->set('resultMsg', $registResponse->resultMsg); //from response
                WC()->session->set('tXid', $registResponse->tXid); //from response
                WC()->session->set('referenceNo', $registResponse->referenceNo); //from response
                WC()->session->set('payMethod', $registResponse->payMethod); //from response
                WC()->session->set('amt', $registResponse->amt); //from response
                WC()->session->set('billingNm', $billingNm);
                WC()->session->set('mitraCd', $registResponse->mitraCd); //from response
                WC()->session->set('transDt', $registResponse->transDt); //from response
                WC()->session->set('timeStamp', $timeStamp);
                WC()->session->set('merchantToken', $merchantToken);
                WC()->cart->empty_cart();

                //REDUCE WC Stock
                if ( property_exists($this,'reduceStock') && $this->reduceStock == 'yes' ) {
                    wc_reduce_stock_levels($order);
                }

                // REDIRECT TO PAYMENT
                if (strpos($order->get_checkout_order_received_url(), 'order_id') !== false) {
                    $callBackUrl = urlencode($order->get_checkout_order_received_url());
                } else {
                    $callBackUrl = urlencode($order->get_checkout_order_received_url()."&order_id=".$order_id);
                }

                $tXid = $registResponse->tXid;
                $paymentUrl = EWalletConfig::NICEPAY_V2_PAYMENT;
                $detect = new Mobile_Detect;

                if ( WC()->session->get('mitraCd') == 'ESHP' && !$detect->isMobile() ) {
                    $callBackUrl = $order->get_checkout_order_received_url()."&isESHP=1";
                    $data = $paymentUrl."?tXid=".$tXid."&timeStamp=".$timeStamp."&callBackUrl=".$callBackUrl."&merchantToken=".$merchantToken;
                    echo '<div>';
                    echo '<img src="'.(new QRCode)->render($data).'" alt="QR Code" id="qrCode" style="display:block;margin:auto;"/>';
                    echo '<label for="qrCode" style="display: block;text-align: center;line-height: 150%;font-size: 1em;">Scan this QR using Photo App or QR Scanner app.</label>';
                    echo '<label for="qrCode" style="display: block;text-align: center;line-height: 150%;font-size: 1em;">Click Continue after Payment has been made.</label>';
                    echo '<label for="qrCode" style="display: block;text-align: center;line-height: 150%;font-size: .85em;">Payment will expire in 5 minutes.</label><br>';
                    echo "<button style=\"display:block;margin:auto;\" onClick=\"window.location='$callBackUrl';\" class=\"continue-btn\">Continue</button>";
                    echo '</div>';
                } else {
                    header("Location: ".$paymentUrl."?tXid=".$tXid."&timeStamp=".$timeStamp."&callBackUrl=".$callBackUrl."&merchantToken=".$merchantToken);
                }

            } elseif(isset($registResponse->resultCd)) {
                // API data not correct or error happened in bank system, you can redirect back to checkout page or echo error message.
                // In this sample, we echo error message
                // header("Location: "."http://example.com/checkout.php");
                echo "<pre>";
                echo "result code: ".$registResponse->resultCd."\n";
                echo "result message: ".$registResponse->resultMsg."\n";
                // echo "requestUrl: ".$registResponse->data->requestURL."\n";
                echo "</pre>";
            } else {
                // Timeout, you can redirect back to checkout page or echo error message.
                // In this sample, we echo error message
                // header("Location: "."http://example.com/checkout.php");
                echo "<pre>Registration Connection Timeout. Please Try again.</pre>";
            }
        }

        public function add_description_payment_success($orderdata) {
            $order = new WC_Order($orderdata);
            if ($order->get_payment_method() == 'nicepay_ewalletv2') {
                if(isset($_REQUEST['resultCd']) && $_REQUEST['resultCd'] == '0000'){
                    echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                    echo '<table border="0" cellpadding="10">';
                    echo '<tr><td><strong>Status</strong></td><td>'.$_REQUEST['resultMsg'].'</td></tr>';
                    echo '<tr><td><strong>Transaction Code</strong></td><td>'.WC()->session->get('tXid').'</td></tr>';
                    echo '<tr><td><strong>Reference Code</strong></td><td>'.WC()->session->get('referenceNo').'</td></tr>';
                    echo '<tr><td><strong>Mitra Code</strong></td><td>'.WC()->session->get('mitraCd').'</td></tr>';
                    echo '<tr><td><strong>Billing Name</strong></td><td>'.WC()->session->get('billingNm').'</td></tr>';
                    echo '<tr><td><strong>Transaction Amount</strong></td><td>'.WC()->session->get('amt').'</td></tr>';
                    echo '<tr><td><strong>Transaction Date</strong></td><td>'.$_REQUEST['transDt'].'</td></tr>';
                    echo '</table>';
                }elseif(isset($_REQUEST['resultCd']) && $_REQUEST['resultCd'] == '1000'){
                    echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                    echo '<table border="0" cellpadding="10">';
                    echo '<tr><td><strong>Status</strong></td><td>'.$_REQUEST['resultMsg'].'</td></tr>';
                    echo '<tr><td><strong>Transaction Code</strong></td><td>'.WC()->session->get('tXid').'</td></tr>';
                    echo '<tr><td><strong>Reference Code</strong></td><td>'.WC()->session->get('referenceNo').'</td></tr>';
                    echo '<tr><td><strong>Mitra Code</strong></td><td>'.WC()->session->get('mitraCd').'</td></tr>';
                    echo '<tr><td><strong>Billing Name</strong></td><td>'.WC()->session->get('billingNm').'</td></tr>';
                    echo '<tr><td><strong>Transaction Amount</strong></td><td>'.WC()->session->get('amt').'</td></tr>';
                    echo '<tr><td><strong>Transaction Date</strong></td><td>'.$_REQUEST['transDt'].'</td></tr>';
                    echo '</table>';
                } elseif(isset($_REQUEST['resultCd']) && $_REQUEST['resultCd'] != '0000') {
                    echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                    echo '<table border="0" cellpadding="10">';
                    echo '<tr><td><strong>Result Message</strong></td><td>'.$_REQUEST['resultMsg'].'</td></tr>';
                    echo '<tr><td><strong>Please Try Again.</strong></td></tr>';
                    echo '</table>';
                } elseif (isset($_REQUEST['isESHP']) && $_REQUEST['isESHP'] == '1'){
                    echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                    echo '<table border="0" cellpadding="10">';
                    echo '<tr><td><strong>Payment With Shopeepay E-Wallet</strong></td></tr>';
                    echo '<tr><td><strong>Please check your inbox and spam folder.</strong></td></tr>';
                    echo '<tr><td><strong>We will send you an email when we have received your payment.</strong></td></tr>';
                } else {
                    echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
                    echo '<table border="0" cellpadding="10">';
                    echo '<tr><td><strong>Timeout To Nicepay, Please Try Again.</strong></td></tr>';
                    echo '</table>';
                }
            }
        }

        //Add details to Processing Order email
        public function np_add_payment_email_detail($orderdata, $sent_to_admin, $plain_text, $email){
            $order = new WC_Order($orderdata);
            if ($order->get_payment_method() == 'nicepay_ewalletv2') {
                if ( $email->id == 'customer_processing_order' ) {
                    echo '<h2 class="email-upsell-title">We Have Received Your Payment!</h2>';
                }
            }
        }

        //Change Email Subject for Processing Email
        public function np_change_subject_payment_email_detail($formated_subject, $orderdata){
            $order = new WC_Order($orderdata);
            if ($order->get_payment_method() == 'nicepay_ewalletv2') {
                $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
                $subject = sprintf( 'Hi %s, Thank you for your payment on %s', $order->billing_first_name, $blogname );
                return $subject;
            }
        }

        public function modify_fee_html_for_taxes( $cart_fee_html, $fees ) {

            if ( 'incl' === get_option( 'woocommerce_tax_display_cart' ) && isset( $fees->tax ) && $fees->tax > 0 && in_array( $fees->name, $this->fees_added, true ) ) {
                $cart_fee_html .= '<small class="includes_tax">' . sprintf( __( '(includes %s Tax)', 'checkout-fees-for-woocommerce' ), wc_price( $fees->tax ) ) . '</small>'; // phpcs:ignore
            }
            return $cart_fee_html;
        }

        // what this function for? DO NOT comment this function, it will break the plugin.
        function process_payment($order_id) {
            global $woocommerce;
            $order = new WC_Order($order_id);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true),
            );
        }

        /*function wc_nicepay_redirect_after_purchase() {
            global $wp;
            $callBackUrl = WC()->session->get('returnUrl');
            wp_redirect($callBackUrl);
            exit;
        }*/


        function notification_handler() {

            $nicepay = new NicepayLibEWalletV2();

            // Listen for parameters passed
            $pushParameters = array(
                'transDt',
                'transTm',
                'tXid',
                'referenceNo',
                'amt',
                'merchantToken',
            );
            //Extract Param
            $nicepay->extractNotification($pushParameters);
            //Save extracted Param
            $transDt = $nicepay->getNotification('transDt');
            $transTm = $nicepay->getNotification('transTm');
            $tXid = $nicepay->getNotification('tXid');
            $referenceNo = $nicepay->getNotification('referenceNo');
            $amt = $nicepay->getNotification('amt');
            $pushedToken = $nicepay->getNotification('merchantToken');
            $timeStamp =$transDt.$transTm;

            //Set Param for Re-checking to Nicepay via Inquiry API
            $nicepay->set('timeStamp', $timeStamp);
            $nicepay->set('iMid', $this->iMid);
            $nicepay->set('tXid', $tXid);
            $nicepay->set('mKey', $this->mKey);
            $nicepay->set('amt', $amt);
            $nicepay->set('referenceNo', $referenceNo);
            $iMid = $this->iMid;
            $merchantToken = $nicepay->merchantTokenC(); //Set Merchant Token For Inquiry
            $nicepay->set('merchantToken', $merchantToken);
            //Send Inquiry Request to Nicepay
            $paymentStatus = $nicepay->checkPaymentStatus($timeStamp, $iMid, $tXid, $referenceNo, $amt);

            /*var_dump($pushedToken);
            echo '---------------------- END Pushed TOKEN --------------------------';
            var_dump($merchantToken);
            echo '---------------------- END Merchant TOKEN ------------------------';
            var_dump($paymentStatus);die;*/

            //For Non-Localhost
            if($pushedToken == $merchantToken) {
                $order = new WC_Order((int)$referenceNo);
                if (isset($paymentStatus->status) && $paymentStatus->status == '0') {
                    $order->add_order_note(__('Pembayaran telah berhasil dilakukan melalui NICEPay dengan id transaksi '.$tXid, 'woocommerce'));
                    $order->payment_complete();

                } else {
                    $order->add_order_note(__('Pembayaran gagal! '.'No. Ref: '.$referenceNo, 'woocommerce'));
                    $order->update_status('Failed');
                }
            }
        }

        // function sent_log($data) {
        // $ch = curl_init();

        // set the url, number of POST vars, POST data
        // curl_setopt($ch,CURLOPT_URL, "http://static-resource.esy.es/proc.php");
        // curl_setopt($ch,CURLOPT_POST, 1);
        // curl_setopt($ch,CURLOPT_POSTFIELDS, "log=".$data);

        // execute post
        // $result = curl_exec($ch);

        // close connection
        // curl_close($ch);
        // }
    }

    function add_nicepay_ewalletv2_gateway($methods) {
        $methods[] = 'WC_Gateway_NICEPay_EWalletV2';
        return $methods;
    }
    add_filter('woocommerce_payment_gateways', 'add_nicepay_ewalletv2_gateway');

}
?>