<?php
/*
Plugin Name: Add Custom Fee Nicepay
Plugin URI: https://nicepay.co.id/
Description: Add Custom Fee for Nicepay PG
Author: NICEPAY
Version: 1.0.0
License: GPL2
*/
if (!defined('ABSPATH')) {
    exit;
}

// Check if WooCommerce is active.
$plugin_name = 'woocommerce/woocommerce.php';
if (
    ! in_array( $plugin_name, apply_filters( 'active_plugins', get_option( 'active_plugins', array() ) ) ) &&
    ! ( is_multisite() && array_key_exists( $plugin_name, get_site_option( 'active_sitewide_plugins', array() ) ) )
) {
    return;
}

class WC_Nicepay_Custom_fee {

    /**
     * Bootstraps the class and hooks required actions & filters.
     *
     */
    public static function init() {
        add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50 );
        add_action( 'woocommerce_settings_tabs_nicepay_custom_fee', __CLASS__ . '::settings_tab' );
        add_action( 'woocommerce_update_options_nicepay_custom_fee', __CLASS__ . '::update_settings' );
        add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), __CLASS__ . '::action_links' );
    }

    /**
     * Show action links on the plugin screen.
     *
     */
    public function action_links( $links ) {
        $custom_links   = array();
        $custom_links[] = '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=nicepay_custom_fee' ) . '">' . __( 'Settings', 'woocommerce' ) . '</a>';
        return array_merge( $custom_links, $links );
    }

    /**
     * Add a new settings tab to the WooCommerce settings tabs array.
     *
     * @param array $settings_tabs Array of WooCommerce setting tabs & their labels, excluding the Subscription tab.
     * @return array $settings_tabs Array of WooCommerce setting tabs & their labels, including the Subscription tab.
     */
    public static function add_settings_tab( $settings_tabs ) {
        $settings_tabs['nicepay_custom_fee'] = __( 'NICEPAY Custom Fee', 'woocommerce-nicepay-custom-fee' );
        return $settings_tabs;
    }


    /**
     * Uses the WooCommerce admin fields API to output settings via the @see woocommerce_admin_fields() function.
     *
     * @uses woocommerce_admin_fields()
     * @uses self::get_settings()
     */
    public static function settings_tab() {
        woocommerce_admin_fields( self::get_settings() );
    }


    /**
     * Uses the WooCommerce options API to save settings via the @see woocommerce_update_options() function.
     *
     * @uses woocommerce_update_options()
     * @uses self::get_settings()
     */
    public static function update_settings() {
        woocommerce_update_options( self::get_settings() );
    }


    /**
     * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
     *
     * @return array Array of settings for @see woocommerce_admin_fields() function.
     */
    public static function get_settings() {
        //Holder
        $settingsHolder = array(
            'main_title' => array(
                'name'     => __( 'NICEPAY Custom Fee', 'woocommerce-nicepay-custom-fee' ),
                'type'     => 'title',
                'desc'     => 'Custom fee settings for NICEPAY Plugins, Please install the Payment Gateway Plugin first to see this settings.',
                'id'       => 'wc_nicepay_custom_fee_settings_title'
            ),
            'main_end' => array(
                'type' => 'sectionend',
                'id' => 'wc_nicepay_custom_fee_title_end'
            )
        );
        $settings = array_merge($settingsHolder);

        // Validation class payment gateway woocommerce
        if (class_exists('WC_Gateway_NICEPay_CC')) {
            $settingsCC = array(
                'CC_title' => array(
                    'name'     => __( 'Credit Card', 'woocommerce-nicepay-custom-fee' ),
                    'type'     => 'title',
                    'desc'     => '',
                    'id'       => 'wc_nicepay_custom_fee_cc_title'
                ),
                'CCIsEnable' => array(
                    'name' => __( 'Enable', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'checkbox',
                    'default' => 'no',
                    'desc' => __( 'Enable Custom Fee for Credit Card?', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_cc_enable'
                ),
                'CCTransactionFee' => array(
                    'name' => __( 'Transaction Fee', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '1500',
                    'desc' => __( 'Insert the transaction fee according to the agreements. This is a flat fee for each transaction.', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_cc_transaction_fee'
                ),
                'CCVat' => array(
                    'name' => __( 'VAT %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'VAT fee according to the agreements. This calculation is based on the % of Transaction Fee. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_cc_vat_fee'
                ),
                'CCMitraFee' => array(
                    'name' => __( 'Mitra Fee %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'Mitra fee according to the agreements. This calculation is based on the % of Total Transaction. Leave empty if not used.', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_cc_mitra_fee'
                ),
                'CC_end' => array(
                    'type' => 'sectionend',
                    'id' => 'wc_nicepay_custom_fee_cc_section_end'
                )
            );
            $settings = array_merge($settings,$settingsCC);
        }

        if (class_exists('WC_Gateway_NICEPay_CVSV2')) {
            $settingsCVS = array(
                'CVS_title' => array(
                    'name'     => __( 'Convenience Store', 'woocommerce-nicepay-custom-fee' ),
                    'type'     => 'title',
                    'desc'     => '',
                    'id'       => 'wc_nicepay_custom_fee_cvs_title'
                ),
                'CVSIsEnable' => array(
                    'name' => __( 'Enable', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'checkbox',
                    'default' => 'no',
                    'desc' => __( 'Enable Custom Fee for Convenience Store?', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_cvs_enable'
                ),
                'CVSTransactionFee' => array(
                    'name' => __( 'Transaction Fee', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '1500',
                    'desc' => __( 'Insert the transaction fee according to the agreements. This is a flat fee for each transaction.', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_cvs_transaction_fee'
                ),
                'CVSVat' => array(
                    'name' => __( 'VAT %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'VAT fee according to the agreements. This calculation is based on the % of Transaction Fee. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_cvs_vat_fee'
                ),
                'CVSMitraFee' => array(
                    'name' => __( 'Mitra Fee %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'Mitra fee according to the agreements. This calculation is based on the % of Total Transaction. Leave empty if not used.', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_cvs_mitra_fee'
                ),
                'CVS_end' => array(
                    'type' => 'sectionend',
                    'id' => 'wc_nicepay_custom_fee_cvs_section_end'
                )
            );
            $settings = array_merge($settings,$settingsCVS);
        }

        if (class_exists('WC_Gateway_NICEPay_VAV2')) {
            $settingsVA = array(
                'VA_title' => array(
                    'name'     => __( 'Virtual Account', 'woocommerce-nicepay-custom-fee' ),
                    'type'     => 'title',
                    'desc'     => '',
                    'id'       => 'wc_nicepay_custom_fee_ewallet_title'
                ),
                'VAIsEnable' => array(
                    'name' => __( 'Enable', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'checkbox',
                    'default' => 'no',
                    'desc' => __( 'Enable Custom Fee for Virtual Account?', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_va_enable'
                ),
                'VATransactionFee' => array(
                    'name' => __( 'Transaction Fee', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '1500',
                    'desc' => __( 'Insert the transaction fee according to the agreements. This is a flat fee for each transaction.', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_va_transaction_fee'
                ),
                'VAVat' => array(
                    'name' => __( 'VAT %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'VAT fee according to the agreements. This calculation is based on the % of Transaction Fee. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_va_vat_fee'
                ),
                'VAMitraFee' => array(
                    'name' => __( 'Mitra Fee %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'Mitra fee according to the agreements. This calculation is based on the % of Total Transaction. Leave empty if not used.', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_va_mitra_fee'
                ),
                'VA_end' => array(
                    'type' => 'sectionend',
                    'id' => 'wc_nicepay_custom_fee_va_section_end'
                )
            );
            $settings = array_merge($settings,$settingsVA);
        }

        if (class_exists('WC_Gateway_NICEPay_EWalletV2')) {
            $settingsEWallet = array(
                'ewallet_title' => array(
                    'name'     => __( 'E-Wallet', 'woocommerce-nicepay-custom-fee' ),
                    'type'     => 'title',
                    'desc'     => '',
                    'id'       => 'wc_nicepay_custom_fee_ewallet_title'
                ),
                'eWalletIsEnable' => array(
                    'name' => __( 'Enable', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'checkbox',
                    'default' => 'no',
                    'desc' => __( 'Enable Custom Fee for E-Wallet?', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_ewallet_enable'
                ),
                'eWalletTransactionFee' => array(
                    'name' => __( 'Transaction Fee', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '1500',
                    'desc' => __( 'Insert the transaction fee according to the agreements. This is a flat fee for each transaction', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_ewallet_transaction_fee'
                ),
                'eWalletVat' => array(
                    'name' => __( 'VAT %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'VAT fee according to the agreements. This calculation is based on the % of Transaction Fee. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_ewallet_vat_fee'
                ),
                'eWalletMitraFee' => array(
                    'name' => __( 'Mitra Fee %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'Mitra fee according to the agreements. This calculation is based on the % of Total Transaction. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_ewallet_mitra_fee'
                ),
                'eWallet_end' => array(
                    'type' => 'sectionend',
                    'id' => 'wc_nicepay_custom_fee_ewallet_section_end'
                )
            );
            $settings = array_merge($settings,$settingsEWallet);
        }

        if (class_exists('WC_Gateway_NICEPay_PayLoan')) {
            $settingsPayloan = array(
                'payloan_title' => array(
                    'name'     => __( 'Payloan', 'woocommerce-nicepay-custom-fee' ),
                    'type'     => 'title',
                    'desc'     => '',
                    'id'       => 'wc_nicepay_custom_fee_payloan_title'
                ),
                'payloanIsEnable' => array(
                    'name' => __( 'Enable', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'checkbox',
                    'default' => 'no',
                    'desc' => __( 'Enable Custom Fee for Payloan?', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_payloan_enable'
                ),
                'payloanTransactionFee' => array(
                    'name' => __( 'Transaction Fee', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '1500',
                    'desc' => __( 'Insert the transaction fee according to the agreements. This is a flat fee for each transaction.', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_payloan_transaction_fee'
                ),
                'payloanVat' => array(
                    'name' => __( 'VAT %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'VAT fee according to the agreements. This calculation is based on the % of Transaction Fee. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_payloan_vat_fee'
                ),
                'payloanMitraFee' => array(
                    'name' => __( 'Mitra Fee %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'Mitra fee according to the agreements. This calculation is based on the % of Total Transaction. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_payloan_mitra_fee'
                ),
                'payloan_end' => array(
                    'type' => 'sectionend',
                    'id' => 'wc_nicepay_custom_fee_payloan_section_end'
                )
            );
            $settings = array_merge($settings,$settingsPayloan);
        }

        if (class_exists('WC_Gateway_NICEPay_QRISV2')) {
            $settingsQRIS = array(
                'QRIS_title' => array(
                    'name'     => __( 'QRIS', 'woocommerce-nicepay-custom-fee' ),
                    'type'     => 'title',
                    'desc'     => '',
                    'id'       => 'wc_nicepay_custom_fee_qrisv2_title'
                ),
                'QRISIsEnable' => array(
                    'name' => __( 'Enable', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'checkbox',
                    'default' => 'no',
                    'desc' => __( 'Enable Custom Fee for QRIS?', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_qrisv2_enable'
                ),
                'QRISTransactionFee' => array(
                    'name' => __( 'Transaction Fee', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '1500',
                    'desc' => __( 'Insert the transaction fee according to the agreements. This is a flat fee for each transaction.', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_qrisv2_transaction_fee'
                ),
                'QRISVat' => array(
                    'name' => __( 'VAT %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'VAT fee according to the agreements. This calculation is based on the % of Transaction Fee. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_qrisv2_vat_fee'
                ),
                'QRISMitraFee' => array(
                    'name' => __( 'Mitra Fee %', 'woocommerce-nicepay-custom-fee' ),
                    'type' => 'text',
                    'default' => '',
                    'desc' => __( 'Mitra fee according to the agreements. This calculation is based on the % of Total Transaction. Leave empty if not used..', 'woocommerce-nicepay-custom-fee' ),
                    'id'   => 'wc_nicepay_custom_fee_qrisv2_mitra_fee'
                ),
                'QRIS_end' => array(
                    'type' => 'sectionend',
                    'id' => 'wc_nicepay_custom_fee_qrisv2_section_end'
                )
            );
            $settings = array_merge($settings,$settingsQRIS);
        }

        return apply_filters( 'wc_nicepay_custom_fee_settings', $settings );
    }

}

WC_Nicepay_Custom_fee::init();

// Add a custom fee based o cart subtotal
add_action( 'woocommerce_cart_calculate_fees', 'nicepay_custom_fee', 20, 1 );
function nicepay_custom_fee ( $cart ) {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return;

    if ( ! ( is_checkout() && ! is_wc_endpoint_url() ) )
        return; // Only checkout page

    $payment_method = WC()->session->get( 'chosen_payment_method' );

    //Check Payment Method
   if ( $payment_method == "nicepay_qrisv2" && get_option('wc_nicepay_custom_fee_qrisv2_enable') == 'yes' ) {
        $transFeeOption = get_option( 'wc_nicepay_custom_fee_qrisv2_transaction_fee' );
        $mitraFeeOption = get_option( 'wc_nicepay_custom_fee_qrisv2_mitra_fee' );
        $vatFeeOption = get_option( 'wc_nicepay_custom_fee_qrisv2_vat_fee' );

        $transFee = ceil($transFeeOption); //CALC TRANS FEE
        $cart->add_fee( 'Transaction Fee', $transFee, false );


        if($vatFeeOption > 0 || $vatFeeOption !== null){
            $vatFee = ceil($transFee * ($vatFeeOption/100)); //CALC VAT FEE
            $cart->add_fee( 'VAT '.$vatFeeOption."%", $vatFee, false );

        }

        $subTotal = $cart->get_subtotal(); //GET CART SUB TOTAL
        $shipping = WC()->cart->get_shipping_total(); //GET CART SHIPPING COST

        if($mitraFeeOption > 0 ||  $mitraFeeOption !== null) {
            $mitraFee = ceil(($subTotal + $transFee + $vatFee + $shipping) * ($mitraFeeOption / 100)); // CALC MITRA FEE
            $cart->add_fee( 'Mitra Fee '.$mitraFeeOption."%", $mitraFee, false );

        }

    } elseif ( $payment_method == "nicepay_payloan" && get_option('wc_nicepay_custom_fee_payloan_enable') == 'yes' ) {
        $transFeeOption = get_option( 'wc_nicepay_custom_fee_payloan_transaction_fee' );
        $mitraFeeOption = get_option( 'wc_nicepay_custom_fee_payloan_mitra_fee' );
        $vatFeeOption = get_option( 'wc_nicepay_custom_fee_payloan_vat_fee' );

        $transFee = ceil($transFeeOption); //CALC TRANS FEE
        $cart->add_fee( 'Transaction Fee', $transFee, false );


        if($vatFeeOption > 0 || $vatFeeOption !== null){
            $vatFee = ceil($transFee * ($vatFeeOption/100)); //CALC VAT FEE
            $cart->add_fee( 'VAT '.$vatFeeOption."%", $vatFee, false );

        }

        $subTotal = $cart->get_subtotal(); //GET CART SUB TOTAL
        $shipping = WC()->cart->get_shipping_total(); //GET CART SHIPPING COST

        if($mitraFeeOption > 0 ||  $mitraFeeOption !== null) {
            $mitraFee = ceil(($subTotal + $transFee + $vatFee + $shipping) * ($mitraFeeOption / 100)); // CALC MITRA FEE
            $cart->add_fee( 'Mitra Fee '.$mitraFeeOption."%", $mitraFee, false );

        }

    } elseif ($payment_method == "nicepay_ewalletv2" && get_option('wc_nicepay_custom_fee_ewallet_enable') == 'yes') {
        $transFeeOption = get_option( 'wc_nicepay_custom_fee_ewallet_transaction_fee' );
        $mitraFeeOption = get_option( 'wc_nicepay_custom_fee_ewallet_mitra_fee' );
        $vatFeeOption = get_option( 'wc_nicepay_custom_fee_ewallet_vat_fee' );

        $transFee = ceil($transFeeOption); //CALC TRANS FEE
        $cart->add_fee( 'Transaction Fee', $transFee, false );


        if($vatFeeOption > 0 || $vatFeeOption !== null){
            $vatFee = ceil($transFee * ($vatFeeOption/100)); //CALC VAT FEE
            $cart->add_fee( 'VAT '.$vatFeeOption."%", $vatFee, false );

        }

        $subTotal = $cart->get_subtotal(); //GET CART SUB TOTAL
        $shipping = WC()->cart->get_shipping_total(); //GET CART SHIPPING COST

        if($mitraFeeOption > 0 ||  $mitraFeeOption !== null) {
            $mitraFee = ceil(($subTotal + $transFee + $vatFee + $shipping) * ($mitraFeeOption / 100)); // CALC MITRA FEE
            $cart->add_fee( 'Mitra Fee '.$mitraFeeOption."%", $mitraFee, false );

        }
    } elseif ($payment_method == "nicepay_vav2" && get_option('wc_nicepay_custom_fee_va_enable') == 'yes') {
        $transFeeOption = get_option( 'wc_nicepay_custom_fee_va_transaction_fee' );
        $mitraFeeOption = get_option( 'wc_nicepay_custom_fee_va_mitra_fee' );
        $vatFeeOption = get_option( 'wc_nicepay_custom_fee_va_vat_fee' );

        $transFee = ceil($transFeeOption); //CALC TRANS FEE
        $cart->add_fee( 'Transaction Fee', $transFee, false );


        if($vatFeeOption > 0 || $vatFeeOption != null){
            $vatFee = ceil($transFee * ($vatFeeOption/100)); //CALC VAT FEE
            $cart->add_fee( 'VAT '.$vatFeeOption."%", $vatFee, false );

        }

        $subTotal = $cart->get_subtotal(); //GET CART SUB TOTAL
        $shipping = WC()->cart->get_shipping_total(); //GET CART SHIPPING COST

        if($mitraFeeOption > 0 || $mitraFeeOption != null) {
            $mitraFee = ceil(($subTotal + $transFee + $vatFee + $shipping) * ($mitraFeeOption / 100)); // CALC MITRA FEE
            $cart->add_fee( 'Mitra Fee '.$mitraFeeOption."%", $mitraFee, false );

        }
    } elseif ($payment_method == "nicepay_cc" && get_option('wc_nicepay_custom_fee_cc_enable') == 'yes') {
        $transFeeOption = get_option( 'wc_nicepay_custom_fee_cc_transaction_fee' );
        $mitraFeeOption = get_option( 'wc_nicepay_custom_fee_cc_mitra_fee' );
        $vatFeeOption = get_option( 'wc_nicepay_custom_fee_cc_vat_fee' );

        $transFee = ceil($transFeeOption); //CALC TRANS FEE
        $cart->add_fee( 'Transaction Fee', $transFee, false );


        if($vatFeeOption > 0 || $vatFeeOption != null){
            $vatFee = ceil($transFee * ($vatFeeOption/100)); //CALC VAT FEE
            $cart->add_fee( 'VAT '.$vatFeeOption."%", $vatFee, false );

        }

        $subTotal = $cart->get_subtotal(); //GET CART SUB TOTAL
        $shipping = WC()->cart->get_shipping_total(); //GET CART SHIPPING COST

        if($mitraFeeOption > 0 || $mitraFeeOption != null) {
            $mitraFee = ceil(($subTotal + $transFee + $vatFee + $shipping) * ($mitraFeeOption / 100)); // CALC MITRA FEE
            $cart->add_fee( 'Mitra Fee '.$mitraFeeOption."%", $mitraFee, false );

        }
    } elseif ($payment_method == "nicepay_cvsv2" && get_option('wc_nicepay_custom_fee_cvs_enable') == 'yes') {
        $transFeeOption = get_option( 'wc_nicepay_custom_fee_cvs_transaction_fee' );
        $mitraFeeOption = get_option( 'wc_nicepay_custom_fee_cvs_mitra_fee' );
        $vatFeeOption = get_option( 'wc_nicepay_custom_fee_cvs_vat_fee' );

        $transFee = ceil($transFeeOption); //CALC TRANS FEE
        $cart->add_fee( 'Transaction Fee', $transFee, false );

        if($vatFeeOption > 0 || $vatFeeOption != null){
            $vatFee = ceil($transFee * ($vatFeeOption/100)); //CALC VAT FEE
            $cart->add_fee( 'VAT '.$vatFeeOption."%", $vatFee, false );

        }

        $subTotal = $cart->get_subtotal(); //GET CART SUB TOTAL
        $shipping = WC()->cart->get_shipping_total(); //GET CART SHIPPING COST

        if($mitraFeeOption > 0 || $mitraFeeOption != null) {
            $mitraFee = ceil(($subTotal + $transFee + $vatFee + $shipping) * ($mitraFeeOption / 100)); // CALC MITRA FEE
            $cart->add_fee( 'Mitra Fee '.$mitraFeeOption."%", $mitraFee, false );
        }
    }
}

// jQuery - Update checkout on methode payment change
add_action( 'wp_footer', 'custom_checkout_jqscript' );
function custom_checkout_jqscript() {
    if ( ! ( is_checkout() && ! is_wc_endpoint_url() ) )
        return; // Only checkout page
    ?>
    <script type="text/javascript">
        jQuery( function($){
            $('form.checkout').on('change', 'input[name="payment_method"]', function(){
                $(document.body).trigger('update_checkout');
            });
        });
    </script>
    <?php
}

