Plugin Name: NICEPay Pay Loan Payment Gateway
Plugin URI: http://nicepay.co.id
Description: PayLoan Plugins for Kredivo and Akulaku
API Version: 2
Author: NICEPay
Author URI: http://nicepay.co.id
------
WooCommerce Version: 3.8.1
Wordpress Version: 5.3 (tested)
PHP: 5.6->latest

fixed bug :

------
- Added seller data parameters.
- Fix error on JSON: Cart Item.
- Add pay submit button to receipt page.
- Add dburl for localhost and fix pushedparams.
- Add Callback view.
- Add empty cart function after registration to nicepay to prevent multiple tXid on same order.
- Change payment icon.
- Fix HEREDOC causing parsing error in certain PHP version.
- Known BUG from Akulaku: URL must not contain special characters such as ? or = etc.
- Known BUG from AKulaku: Shipping Address and probably other parameters must not have empty space at the end.
- Fix Non-free shipping method causing error in item cart for both payment methods.
- Fix bug on refferenceNo
- Add Akulaku Image