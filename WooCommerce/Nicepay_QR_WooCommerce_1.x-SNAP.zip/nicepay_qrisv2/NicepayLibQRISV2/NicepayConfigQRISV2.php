<?php
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 *
 * This config file may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 09.03.2016
 *
 * 09.03.2016 Update Log
 *
 * ____________________________________________________________
 */

namespace libraryQRISV2;

class Config
{
    const NICEPAY_TIMEOUT_CONNECT = 15;
    const NICEPAY_TIMEOUT_READ = 25;
    const NICEPAY_READ_TIMEOUT_ERR = "10200";

    const NICEPAY_PROGRAM = "NicepayLite";
    const NICEPAY_VERSION = "1.11";
    const NICEPAY_BUILDDATE = "20230731";
    const NICEPAY_ACCESSTOKEN = "https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b";
    const NICEPAY_SNAP_CREATEQR = "https://dev.nicepay.co.id/nicepay/api/v1.0/qr/qr-mpm-generate";
    const NICEPAY_SNAP_INQUIRY = "https://dev.nicepay.co.id/nicepay/api/v1.0/qr/qr-mpm-query";

}