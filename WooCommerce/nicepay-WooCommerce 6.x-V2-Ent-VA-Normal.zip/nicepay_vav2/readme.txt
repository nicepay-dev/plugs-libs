Plugin Name: NICEPay Payment Gateway
Plugin URI: http://nicepay.co.id
Description: NICEPay Payment Gateway
Version: 1.2
Author: NICEPay <codeNinja>
Author URI: http://nicepay.co.id

fixed bug :
2020/24/09
- Custom Title
- Add Reduce Stock
- Send Trigger New Order Email
- Add params to callback page
- Defaults Param failsafe
- Custom Logo for email
- Guest Login email
- Add banks logo and size setting