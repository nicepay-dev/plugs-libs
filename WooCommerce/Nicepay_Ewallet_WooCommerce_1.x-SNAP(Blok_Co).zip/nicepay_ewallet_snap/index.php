<?php
/**
 * Plugin Name: NICEPay Ewallet SNAP Payment Gateway
 * Plugin URI: http://nicepay.co.id
 * Description: NICEPay Ewallet SNAP Payment Gateway for WooCommerce
 * Version: 1.0.0
 * Author: codeNinja
 * Author URI: http://nicepay.co.id
 * Text Domain: nicepay-ewallet-snap
 * WC requires at least: 5.0
 * WC tested up to: 7.x
 */
defined('ABSPATH') or exit;

// Make sure WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

// Initialize the plugin
add_action('plugins_loaded', 'initialize_nicepay_ewallet_snap', 0);



function initialize_nicepay_ewallet_snap() {
    // Check if WooCommerce is active
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    // Load plugin textdomain
    load_plugin_textdomain('nicepay-ewalletsnap-gateway', false, dirname(plugin_basename(__FILE__)) . '/languages');

    // Include the main gateway class
    require_once plugin_dir_path(__FILE__) . 'config/ewallet-snap.php';
    $gateway = new WC_Gateway_Ewallet_NICEPay_SNAP();
    add_filter('woocommerce_payment_gateways', 'add_nicepay_ewallet_snap_gateway');
    add_action('wp_ajax_save_nicepay_mitra', 'save_nicepay_mitra');
    add_action('wp_ajax_nopriv_save_nicepay_mitra', 'save_nicepay_mitra');
    add_action('wp_enqueue_scripts', 'enqueue_nicepay_ewallet_snap_scripts');
}

function save_nicepay_mitra() {
    check_ajax_referer('nicepay-ewallet-snap-nonce', 'nonce');

    if (!isset($_POST['mitra'])) {
        wp_send_json_error('No mitra specified');
    }

    $mitra = sanitize_text_field($_POST['mitra']);
    WC()->session->set('nicepay_selected_mitra', $mitra);

    wp_send_json_success('Mitra saved successfully: ' . $mitra);
}

function add_nicepay_ewallet_snap_gateway($methods) {
    $methods[] = 'WC_Gateway_Ewallet_NICEPay_SNAP';
    return $methods;
}

add_filter('woocommerce_payment_gateways', 'add_nicepay_ewallet_snap_gateway');

// Enqueue scripts for blocks
function enqueue_nicepay_ewallet_snap_scripts() {
    if (!class_exists('WC_Gateway_Ewallet_NICEPay_SNAP') || !is_checkout()) {
        return;
    }

    wp_enqueue_script(
        'nicepay-ewallet-snap-blocks-integration',
        plugin_dir_url(__FILE__) . 'config/blocks-integration.js',
        array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wc-blocks-registry'),
        filemtime(plugin_dir_path(__FILE__) . 'config/blocks-integration.js'), 
        true
    );

    wp_enqueue_style(
        'nicepay-ewallet-snap-style',
        plugins_url('config/ewalletsnap.css', __FILE__),
        [],
        filemtime(plugin_dir_path(__FILE__) . 'config/ewalletsnap.css')
    );


    $gateway = new WC_Gateway_Ewallet_NICEPay_SNAP();
    wp_localize_script(
        'nicepay-ewallet-snap-blocks-integration',
        'nicepayData',
        array(
            'enabled_mitra' => $gateway->get_ewallet_options(), // Gunakan fungsi yang sudah dimodifikasi
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nicepay-ewallet-snap-nonce'),
            'pluginUrl' => plugin_dir_url(__FILE__)
        )
    );
}