<!-- 11 November 2024 -->
- Create Plugin Ewallet SNAP