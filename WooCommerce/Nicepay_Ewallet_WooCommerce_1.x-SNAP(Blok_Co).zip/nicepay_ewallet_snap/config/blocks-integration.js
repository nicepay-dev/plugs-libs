console.log('NICEPay Ewallet SNAP script loaded');

// Processing DOM
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded');
    console.log('wp object:', window.wp);
    console.log('wc object:', window.wc);

    
    if (window.wp && window.wc && window.wc.wcBlocksRegistry && window.wp.element) {
        console.log('All required dependencies are available');
        initNicepayEwalletSnap();
    } else {
        console.error('Some required dependencies are missing');
    }
});

function initNicepayEwalletSnap() {
    const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
    const { createElement, useState } = window.wp.element;

    const NicepayEwalletComponent = () => {
        const [selectedMitra, setSelectedMitra] = useState('');
        // Gunakan mitra dari nicepayData.enabled_mitra
        const mitra = nicepayData.enabled_mitra || [];
        console.log('Available mitra:', mitra);

        const handleMitraChange = (e) => {
            const selectedMitraCode = e.target.value;
            console.log('Mitra selected:', selectedMitraCode);
            setSelectedMitra(selectedMitraCode);
            saveMitraSelection(selectedMitraCode);
        };

        const saveMitraSelection = (mitraCode) => {
            if (typeof jQuery === 'undefined' || typeof nicepayData === 'undefined') {
                console.error('Required dependencies not available for mitra selection');
                return;
            }

            jQuery.ajax({
                url: nicepayData.ajax_url,
                type: 'POST',
                data: {
                    action: 'save_nicepay_mitra',
                    mitra: mitraCode,
                    nonce: nicepayData.nonce
                },
                success: function(response) {
                    console.log('Mitra selection saved:', response);
                },
                error: function(xhr, status, error) {
                    console.error('Error saving mitra selection:', error);
                    console.log('Full error response:', xhr.responseText);
                }
            });
        };

        // Jika tidak ada mitra yang aktif, jangan tampilkan komponen
        if (!Array.isArray(mitra) || mitra.length === 0) {
            console.log('No active mitra available');
            return null;
        }

        return createElement('div', { className: 'nicepay-ewallet-container' },
            createElement('div', { className: 'nicepay-ewallet-content' }, [
                // Container gambar
                createElement('div', { className: 'nicepay-ewallet-logos' },
                    createElement('img', {
                        src: nicepayData.pluginUrl + '/config/ewallet1.png',
                        alt: 'E-wallet Options',
                        className: 'nicepay-ewallet-image'
                    })
                ),
            // Select dropdown untuk mitra
            createElement('div', { className: 'nicepay-ewallet-select' },
                createElement('select', {
                    onChange: handleMitraChange,
                    value: selectedMitra,
                    className: 'nicepay-select'
                }, [
                    createElement('option', { value: '' }, 'Pilih E-wallet'),
                    ...mitra.map(m => createElement('option', {
                        value: m.value || m.code,
                        key: m.value || m.code
                    }, m.label || m.name))
                ])
            )
        ])
        )
    };

    registerPaymentMethod({
        name: 'nicepay_ewallet_snap',
        label: 'NICEPay E-wallet',
        content: createElement(NicepayEwalletComponent),
        edit: createElement(NicepayEwalletComponent),
        canMakePayment: () => true,
        ariaLabel: 'NICEPay E-wallet',
        supports: {
            features: ['products'],
        },
        // paymentProcessing: handlePaymentProcessing
        onPaymentProcessing: async ({ processingResponse }) => {
            console.log('Processing payment:', processingResponse);
            
            try {
                if (processingResponse?.paymentResult?.payment_details?.type === 'linkaja') {
                    const details = processingResponse.paymentResult.payment_details;
                    console.log('LinkAja payment details:', details);
                    
                    // Buat dan submit form
                    const form = document.createElement('form');
                    form.setAttribute('method', 'POST');
                    form.setAttribute('action', details.url);
                    form.style.display = 'none';
                    
                    const tokenInput = document.createElement('input');
                    tokenInput.setAttribute('type', 'hidden');
                    tokenInput.setAttribute('name', 'redirectToken');
                    tokenInput.setAttribute('value', details.token);
                    
                    form.appendChild(tokenInput);
                    document.body.appendChild(form);
                    
                    // Submit form setelah delay kecil
                    setTimeout(() => {
                        console.log('Submitting LinkAja form...');
                        form.submit();
                    }, 100);
                }
                
                return { type: 'success' };
            } catch (error) {
                console.error('Error processing LinkAja payment:', error);
                return {
                    type: 'error',
                    message: error.message
                };
            }
        }
    });
}