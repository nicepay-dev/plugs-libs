const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { createElement, useState, useEffect } = window.wp.element;



const NicepayVASNAPComponent = () => {
        
        const [selectedBank, setSelectedBank] = useState('');
        const banks = [
            { code: 'BMRI', name: 'Bank Mandiri' },
            { code: 'BNIN', name: 'Bank BNI' },
            { code: 'BRIN', name: 'Bank BRI' },
            { code: 'BBBA', name: 'Bank Permata' },
            { code: 'CENA', name: 'Bank BCA' },
            { code: 'IBBK', name: 'Maybank' },
            { code: 'BBBB', name: 'Bank Permata Syariah' },
            { code: 'HNBN', name: 'Bank KEB Hana Indonesia' },
            { code: 'BNIA', name: 'Bank CIMB' },
            { code: 'BDIN', name: 'Bank Bank Danamon' },
            { code: 'PDJB', name: 'Bank BJB' },
            { code: 'YUDB', name: 'Bank Neo Commerce (BNC)' },
            { code: 'BDKI', name: 'Bank DKI' },
            
        ];
        const handleBankChange = (e) => {
            const selectedBankCode = e.target.value;
            console.log('Bank selected:', selectedBankCode);
            setSelectedBank(selectedBankCode);
            saveBankSelection(selectedBankCode);
        };
        
        const saveBankSelection = (bankCode) => {
            console.log('Attempting to save bank selection:', bankCode);
            if (typeof jQuery !== 'undefined' && typeof nicepayData !== 'undefined') {
                jQuery.ajax({
                    url: nicepayData.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'set_nicepay_bank',
                        bank_code: bankCode
                    },
                    success: function(response) {
                        console.log('Bank selection saved:', response);
                    },
                    error: function(error) {
                        console.error('Error saving bank selection:', error);
                        console.log('Full error object:', error);
                    }
                });
            } else {
                console.error('jQuery or nicepayData is not available');
            }
        };
            // useEffect(() => {
            //     const checkoutForm = document.querySelector('form.woocommerce-checkout');
            //     if (checkoutForm) {
            //         const submitHandler = function(e) {
            //             if (!selectedBank) {
            //                 e.preventDefault();
            //                 alert('Please select a bank for payment');
            //             } else {
            //                 saveBankSelection(selectedBank);
            //             }
            //         };
            //         checkoutForm.addEventListener('submit', submitHandler);
            //         return () => {
            //             checkoutForm.removeEventListener('submit', submitHandler);
            //         };
            //     }
            // }, [selectedBank]);

            return createElement('div', { className: 'nicepay-vasnap-container' }, [
                createElement('div', { className: 'nicepay-vasnap-header' }, [
                    createElement('img', { 
                        src: nicepayData.pluginUrl + '/images/logobank.png', 
                        alt: 'Bank Icon', 
                        className: 'nicepay-vasnap-bank-icon' 
                    }),
                ]),
                createElement('div', { className: 'nicepay-vasnap-bank-select' }, [
                    createElement('label', { htmlFor: 'nicepay-bank-select' }, 'Pilih Bank:'),
                    createElement('select',
                        {
                            name: 'nicepay_bank',
                            id: 'nicepay-bank-select',
                            onChange: handleBankChange,
                            value: selectedBank
                        },
                        [
                            createElement('option', { value: '' }, 'Pilih Bank'),
                            ...banks.map(bank =>
                                createElement('option', { value: bank.code, key: bank.code }, bank.name)
                            )
                        ]
                    )
                ]),
                createElement('p', { className: 'nicepay-vasnap-instruction' }, 'Silakan pilih bank untuk pembayaran Virtual Account Anda.')
            ]);
        };
        registerPaymentMethod({
            name: "nicepay_va_snap",
            label: "NICEPay Virtual Account SNAP",
            content: createElement(NicepayVASNAPComponent),
            edit: createElement(NicepayVASNAPComponent),
            canMakePayment: () => true,
            ariaLabel: "NICEPay Virtual Account SNAP payment method",
            supports: {
                features: ['products'],
            },
        });