<?php
if (!defined('ABSPATH')) {
    exit;
}
class WC_Gateway_NICEPay_SNAP extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'nicepay_va_snap';
        $this->icon               = apply_filters('woocommerce_nicepay_vasnap_icon', '');
        $this->has_fields         = false;
        $this->method_title       = __('NICEPay Virtual Account SNAP', 'nicepay-vasnap-gateway');
        $this->method_description = __('Allows payments using NICEPay Virtual Account SNAP.', 'nicepay-vasnap-gateway');

        $this->supports = [
            'products',
            'refunds',
        ];
        $this->api_endpoints = [
            'access_token' => 'https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b',
            'create_va'    => 'https://dev.nicepay.co.id/nicepay/api/v1.0/transfer-va/create-va',
            'check_status_url' => 'https://dev.nicepay.co.id/nicepay/api/v1.0/transfer-va/status',
        ];

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('wp_ajax_set_nicepay_bank', array($this, 'handle_set_nicepay_bank'));
        add_action('wp_ajax_nopriv_set_nicepay_bank', array($this, 'handle_set_nicepay_bank'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        add_action('init', array($this, 'add_endpoint'));
        add_action('woocommerce_api_wc_gateway_nicepay_snap', array($this, 'handle_callback'));

        error_log("NICEPay gateway initialized");
}
public function add_endpoint() {
add_rewrite_endpoint('wc-api', EP_ALL);
}

public function handle_set_nicepay_bank() {
    error_log("handle_set_nicepay_bank called");
    error_log("POST data: " . print_r($_POST, true));
    if (isset($_POST['bank_code'])) {
        $bank_code = sanitize_text_field($_POST['bank_code']);
        WC()->session->set('nicepay_selected_bank', $bank_code);
        error_log("Bank code saved to session: " . $bank_code);
        wp_send_json_success('Bank code saved: ' . $bank_code);
    } else {
        error_log("Bank code not provided in POST data");
        wp_send_json_error('Bank code not provided');
    }
    wp_die();
}

public function init_form_fields() {
    $this->form_fields = array(
        'enabled' => array(
            'title'   => __('Enable/Disable', 'woocommerce'),
            'type'    => 'checkbox',
            'label'   => __('Enable NICEPay Payment', 'woocommerce'),
            'default' => 'no'
        ),
        'title' => array(
            'title'       => __('Title', 'woocommerce'),
            'type'        => 'text',
            'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
            'default'     => __('NICEPay', 'woocommerce'),
            'desc_tip'    => true,
        ),
        'description' => array(
            'title'       => __('Description', 'woocommerce'),
            'type'        => 'textarea',
            'description' => __('This controls the description which the user sees during checkout.', 'woocommerce'),
            'default'     => __('Pay with NICEPay', 'woocommerce'),
            'desc_tip'    => true,
        ),
        'X-CLIENT-KEY' => array(
                'title' => __('Merchant ID', 'woocommerce'),
                'type' => 'text',
                'description' => __('<small>Isikan dengan Merchant ID dari NICEPay</small>.', 'woocommerce'),
                'default' => 'IONPAYTEST',
            ),
        'client_secret' => array(
            'title'       => __('Client Key', 'woocommerce'),
            'type'        => 'text',
            'description' => __('Enter your NICEPay Client Key.', 'woocommerce'),
            'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            'desc_tip'    => true,
        ),
        'merchant_key' => array(
            'title'       => __('Merchant Key', 'woocommerce'),
            'type'        => 'text',
            'description' => __('Enter your NICEPay Merchant Key.', 'woocommerce'),
            'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R',
        ),
        'private_key' => array(
            'title'       => __('Private Key', 'woocommerce'),
            'type'        => 'textarea',
            'description' => __('Enter your NICEPay Private Key.', 'woocommerce'),
            'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
            'desc_tip'    => true,
        ),
    );
}
    public function is_available() {
        $is_available = ('yes' === $this->enabled);
        
        if (WC()->cart && WC()->cart->needs_shipping()) {
            $is_available = $is_available && $this->supports_shipping_country(WC()->customer->get_shipping_country());
        }
    
        return $is_available;
    }
    
    private function supports_shipping_country($country) {
        $supported_countries = array('ID'); // Daftar kode negara yang didukung
        return in_array($country, $supported_countries);
    }
    public function get_bank_list() {
        return [
            ['code' => 'BMRI', 'name' => 'Bank Mandiri'],
            ['code' => 'BNIN', 'name' => 'Bank BNI'],
            ['code' => 'BRIN', 'name' => 'Bank BRI'],
            ['code' => 'BBBA', 'name' => 'Bank Permata'],
            ['code' => 'CENA', 'name' => 'Bank BCA'],
            ['code' => 'IBBK', 'name' => 'Maybank'],
            ['code' => 'BBBB', 'name' => 'Bank Permata Syariah'],
            ['code' => 'HNBN', 'name' => 'Bank KEB Hana Indonesia'],
            ['code' => 'BNIA', 'name' => 'Bank CIMB'],
            ['code' => 'BDIN', 'name' => 'Bank Bank Danamon'],
            ['code' => 'PDJB', 'name' => 'Bank BJB'],
            ['code' => 'YUDB', 'name' => 'Bank Neo Commerce (BNC)'],
            ['code' => 'BDKI', 'name' => 'Bank DKI']
        ];
    }
    
    
    public function get_bank_name($bank_code) {
        $banks = $this->get_bank_list();
        foreach ($banks as $bank) {
            if ($bank['code'] === $bank_code) {
                return $bank['name'];
            }
        }
        return $bank_code;
    }

    public function payment_fields() {
        if ($this->description) {
            echo wpautop(wptexturize($this->description));
        }
        echo '<div id="nicepay-payment-description">';
        echo 'Anda akan diarahkan ke halaman pembayaran NICEPay setelah menekan tombol "Place order".';
        echo '</div>';
    }

    public function process_payment($order_id) {
        error_log("Starting process_payment for order $order_id");
        error_log("POST data received: " . print_r($_POST, true));
        error_log("Session data: " . print_r(WC()->session->get_session_data(), true));
        $order = wc_get_order($order_id);
        $selected_bank = WC()->session->get('nicepay_selected_bank');
        error_log("Selected bank from session in process_payment: " . ($selected_bank ?: 'Not set'));

    if (!$selected_bank) {
        wc_add_notice(__('Please select a bank for payment', 'woocommerce'), 'error');
        return array(
            'result'   => 'failure',
            'redirect' => '',
        );
    }


        try {
            $access_token = $this->get_access_token();
            $va_data = $this->create_virtual_account($order, $access_token, $selected_bank);
            
            
             
        if (isset($va_data['virtualAccountData'])) {
        
            $this->handle_va_creation_response($order, $va_data);
                WC()->cart->empty_cart();
    
                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order),
                );
            } else {
                throw new Exception(__('Failed to create Virtual Account', 'woocommerce'));
            }
        } catch (Exception $e) {
            wc_add_notice(__('Payment error:', 'woocommerce') . ' ' . $e->getMessage(), 'error');
            error_log("Payment error in process_payment: " . $e->getMessage());
            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }
    }

    private function get_access_token() {
        error_log("Starting get_access_token process");
    
        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $timestamp = $this->generate_formatted_timestamp();
        $stringToSign = $X_CLIENT_KEY . "|" . $timestamp;
        
        $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" .
            $this->get_option('private_key') . "\r\n" .
            "-----END RSA PRIVATE KEY-----";
        
        $binary_signature = "";
        $pKey = openssl_pkey_get_private($privatekey);
        
        if ($pKey === false) {
            error_log("Failed to get private key: " . openssl_error_string());
            throw new Exception("Invalid private key");
        }
        
        $sign_result = openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
        
        if ($sign_result === false) {
            error_log("Failed to create signature: " . openssl_error_string());
            throw new Exception("Failed to create signature");
        }
        
        $signature = base64_encode($binary_signature);
        
        $jsonData = array(
            "grantType" => "client_credentials",
            "additionalInfo" => ""
        );
        
        $jsonDataEncode = json_encode($jsonData);
        
        $requestToken = $this->api_endpoints['access_token'];
        
        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SIGNATURE'  => $signature,
                'X-CLIENT-KEY' => $X_CLIENT_KEY,
                'X-TIMESTAMP'  => $timestamp
            ),
            'body'    => $jsonDataEncode,
        );
        
        $response = wp_remote_post($requestToken, $args);
        
        if (is_wp_error($response)) {
            error_log("Error in get_access_token: " . $response->get_error_message());
            throw new Exception($response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response));
        error_log("Access token response: " . json_encode($body));
        
        if (!isset($body->accessToken)) {
            error_log("Invalid access token response: " . json_encode($body));
            throw new Exception(__('Invalid access token response', 'nicepay-vasnap-gateway'));
        }
        
        error_log("Successfully obtained access token");
        WC()->session->set('accessToken', $body->responseCode);
        
        return $body->accessToken;
    }
    
    

    private function create_virtual_account($order, $access_token, $selected_bank) {
        error_log("Starting create_virtual_account for order " . $order->get_id());
        $selected_bank = WC()->session->get('nicepay_selected_bank');
        error_log("Selected bank from session: " . ($selected_bank ?: 'Not set'));

        if (!$selected_bank) {
            throw new Exception(__('Please select a bank for payment', 'woocommerce'));
        }

        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $secretClient = $this->get_option('client_secret');
        $X_TIMESTAMP = $this->generate_formatted_timestamp();
        $timestamp = date('YmdHis');
        $channel = $X_CLIENT_KEY . "01";
        $external = $timestamp . rand(1000, 9999);
        
        $additionalInfo = [
            "bankCd" => $selected_bank,
            "goodsNm" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            "dbProcessUrl" => home_url('/wc-api/wc_gateway_nicepay_snap'),
            "vacctValidDt" => date('Ymd', strtotime('+1 day')),
            "vacctValidTm" => date('His', strtotime('+1 day')),
            "msId" => "",
            "msFee" => "",
            "msFeeType" => "",
            "mbFee" => "",
            "mbFeeType" => ""
        ];
        error_log("body additionalinfo: " . print_r($additionalInfo, true));
    
        $TotalAmount = [
            "value" => number_format($order->get_total(), 2, '.', ''),
            "currency" => $order->get_currency()
        ];
    
        $newBody = [
            "partnerServiceId" => "",
            "customerNo" => "",
            "virtualAccountNo" => "",
            "virtualAccountName" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            "trxId" => $order->get_id() . "",
            "totalAmount" => $TotalAmount,
            "additionalInfo" => $additionalInfo
        ];
    
        $stringBody = json_encode($newBody);
        $hashbody = strtolower(hash("SHA256", $stringBody));
    
        $strigSign = "POST:/api/v1.0/transfer-va/create-va:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
    
        $args = array(
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type'   => 'application/json',
                'X-SIGNATURE'    => base64_encode($bodyHasing),
                'X-CLIENT-KEY'   => $X_CLIENT_KEY,
                'X-TIMESTAMP'    => $X_TIMESTAMP,
                'Authorization'  => "Bearer " . $access_token,
                'CHANNEL-ID'     => $channel,
                'X-EXTERNAL-ID'  => $external,
                'X-PARTNER-ID'   => $X_CLIENT_KEY
            ),
            'body'    => $stringBody,
        );
    
        error_log("Request body for create_virtual_account: " . $stringBody);
        error_log("Request headers for create_virtual_account: " . print_r($args['headers'], true));
    
        $response = wp_remote_post($this->api_endpoints['create_va'], $args);
    
        if (is_wp_error($response)) {
            error_log("Error in create_virtual_account: " . $response->get_error_message());
            throw new Exception($response->get_error_message());
        }
    
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        error_log("Create virtual account response: " . json_encode($response_body));
    
        if (isset($response_body['responseCode']) && $response_body['responseCode'] === '2002700') {
            $va_data = $response_body['virtualAccountData'];
            $order->update_meta_data('_nicepay_va_number', $va_data['virtualAccountNo']);
            $order->update_meta_data('_nicepay_bank_code', $va_data['additionalInfo']['bankCd']);
            $order->update_meta_data('_nicepay_va_expiry', $va_data['additionalInfo']['vacctValidDt'] . ' ' . $va_data['additionalInfo']['vacctValidTm']);
            $order->update_meta_data('_nicepay_tXid', $va_data['additionalInfo']['tXidVA']);
            $order->save();
        } else {
            throw new Exception(__('Failed to create Virtual Account: ' . ($response_body['responseMessage'] ?? 'Unknown error'), 'nicepay-vasnap-gateway'));
        }
    
        return $response_body;
    }
    

    private function handle_va_creation_response($order, $data) {
        if (isset($data['responseCode']) && $data['responseCode'] == "2002700") {
            $va_number = $data['virtualAccountData']['virtualAccountNo'];
            $txid_va = $data['virtualAccountData']['additionalInfo']['tXidVA'];
            $bank_code = $data['virtualAccountData']['additionalInfo']['bankCd'];
            $expiry_date = $data['virtualAccountData']['additionalInfo']['vacctValidDt'];
            $expiry_time = $data['virtualAccountData']['additionalInfo']['vacctValidTm'];

            $status_note = sprintf(
                __('Awaiting NICEPay payment. VA Number: %s, tXidVA: %s', 'nicepay-vasnap-gateway'),
                $va_number,
                $txid_va
            );
            
            $order->update_status('on-hold', $status_note);
            $order->add_order_note(sprintf(
                __('NICEPay Virtual Account created. Details:
                Number: %s
                Bank: %s
                tXidVA: %s', 'nicepay-vasnap-gateway'),
                $va_number,
                $this->get_bank_name($bank_code),
                $expiry_date,
                $expiry_time,
                $txid_va
            ));
            $order->update_meta_data('_nicepay_va_number', $va_number);
            $order->update_meta_data('_nicepay_bank_code', $bank_code);
            $order->update_meta_data('_nicepay_va_expiry', $expiry_date . ' ' . $expiry_time);
            $order->update_meta_data('_nicepay_txid_va', $txid_va);
            $order->save();

            WC()->session->set('nicepay_va_number', $data['virtualAccountData']['virtualAccountNo']);
            WC()->session->set('nicepay_bank_name', $data['virtualAccountData']['additionalInfo']['bankCd']);

            if ($this->get_option('reduceStock') === 'yes' && !$order->get_meta('_stock_reduced', true)) {
                wc_reduce_stock_levels($order->get_id());
                $order->update_meta_data('_stock_reduced', 'yes');
                $order->save();
            }

            WC()->cart->empty_cart();
        } else {
            throw new Exception(__('Failed to create Virtual Account', 'nicepay-vasnap-gateway'));
        }
    }

    private function generate_formatted_timestamp() {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }

    private function generate_signature($string_to_sign, $use_hmac = false) {
        if ($use_hmac) {
            return hash_hmac("sha512", $string_to_sign, $this->get_option('merchant_key'), true);
        } else {
            $private_key = $this->get_formatted_private_key();
            
            if (!$private_key) {
                throw new Exception("Invalid private key format");
            }

            $binary_signature = "";
            $result = openssl_sign($string_to_sign, $binary_signature, $private_key, OPENSSL_ALGO_SHA256);
            
            if ($result === false) {
                throw new Exception("Failed to generate signature: " . openssl_error_string());
            }
            
            return $binary_signature;
        }
    }
    private function get_formatted_private_key() {
        $private_key = $this->get_option('private_key');
        
        // Remove any whitespace or newline characters
        $private_key = preg_replace('/\s+/', '', $private_key);
        
        // Check if the key is already correctly formatted
        if (strpos($private_key, '-----BEGIN RSA PRIVATE KEY-----') === 0) {
            return $private_key;
        }
        
        // Format the key
        $formatted_key = "-----BEGIN RSA PRIVATE KEY-----\n" .
            chunk_split($private_key, 64, "\n") .
            "-----END RSA PRIVATE KEY-----";
        
        // Verify the key
        $key_resource = openssl_pkey_get_private($formatted_key);
        if ($key_resource === false) {
            error_log("Invalid private key: " . openssl_error_string());
            return false;
        }
        openssl_free_key($key_resource);
        
        return $formatted_key;
    }

    private function generate_external_id() {
        return date('YmdHis') . rand(1000, 9999);
    }

    public function thankyou_page($order_id) {
        $order = wc_get_order($order_id);
        if ($order && $order->get_payment_method() === $this->id) {
            $va_number = $order->get_meta('_nicepay_va_number');
            $bank_code = $order->get_meta('_nicepay_bank_code');
            $expiry_date = $order->get_meta('_nicepay_va_expiry');
            $payment_status = $order->get_status();
    
            if (!$order->get_meta('_nicepay_thankyou_displayed')) {
                echo '<div class="woocommerce-order-payment-details">';
                echo '<h2>' . __('Payment Instructions', 'woocommerce') . '</h2>';
    
                echo '<p><strong>' . __('Payment Status:', 'woocommerce') . '</strong> ' . $this->get_payment_status_description($payment_status) . '</p>';
    
                if ($payment_status !== 'completed' && $payment_status !== 'processing') {
                    echo '<p>' . sprintf(
                        __('Please transfer %s to the following Virtual Account details:', 'woocommerce'),
                        wc_price($order->get_total())
                    ) . '</p>';
                    echo '<ul>';
                    echo '<li><strong>' . __('Bank:', 'woocommerce') . '</strong> ' . esc_html($this->get_bank_name($bank_code)) . '</li>';
                    echo '<li><strong>' . __('Virtual Account Number:', 'woocommerce') . '</strong> ' . esc_html($va_number) . '</li>';
                    echo '<li><strong>' . __('Amount:', 'woocommerce') . '</strong> ' . wc_price($order->get_total()) . '</li>';
                    if ($expiry_date) {
                        $formatted_expiry = $this->format_expiry_date($expiry_date);
                        echo '<li><strong>' . __('Expiry Date:', 'woocommerce') . '</strong> ' . esc_html($formatted_expiry) . '</li>';
                    }
                    echo '</ul>';
    
                    
                    echo '<p>' . sprintf(
                        __('For detailed payment instructions, please visit <a href="%s" target="_blank">NICEPay Payment Guide</a>.', 'woocommerce'),
                        'https://template.nicepay.co.id/'
                    ) . '</p>';
    
                    echo '<p>' . __('Please complete the payment before the VA expires. After payment is completed, it may take a few moments for the system to confirm your payment.', 'woocommerce') . '</p>';
                } else {
                    echo '<p>' . __('Thank you for your payment. Your transaction has been completed.', 'woocommerce') . '</p>';
                }
    
                echo '</div>';
                $order->update_meta_data('_nicepay_thankyou_displayed', 'yes');
                $order->save();
            }
        }
    }
    private function format_expiry_date($expiry_date) {
    
        $datetime = DateTime::createFromFormat('Ymd His', $expiry_date);
        if ($datetime) {
            return $datetime->format('d F Y H:i:s'); 
        }
        return $expiry_date;
    }
    private function get_payment_status_description($status) {
        switch ($status) {
            case 'pending':
                return __('Pending payment', 'woocommerce');
            case 'on-hold':
                return __('Awaiting payment confirmation', 'woocommerce');
            case 'processing':
                return __('Payment received, processing order', 'woocommerce');
            case 'completed':
                return __('Payment completed', 'woocommerce');
            case 'cancelled':
                return __('Order cancelled', 'woocommerce');
            case 'failed':
                return __('Payment failed', 'woocommerce');
            default:
                return ucfirst($status);
        }
    }

    public function openssl_missing_notice() {
        echo '<div class="error"><p>' . __('NICEPay gateway requires OpenSSL extension to be installed on your server', 'nicepay-vasnap-gateway') . '</p></div>';
    }

    public function handle_callback() {
    error_log('NICEPay callback received. Starting processing...');
    status_header(200);

    $raw_post = file_get_contents('php://input');
    error_log('Raw input: ' . $raw_post);

    $decoded_post = json_decode($raw_post, true);
    if (!$decoded_post) {
        parse_str($raw_post, $decoded_post);
    }
    if (empty($decoded_post)) {
        $decoded_post = $_POST;
    }

    error_log('Processed callback data: ' . print_r($decoded_post, true));

    if (isset($decoded_post['tXid']) && isset($decoded_post['vacctNo'])) {
        $order_id = trim($decoded_post['referenceNo']);
        error_log('Attempting to find order with ID: ' . $order_id);
        
        $order = wc_get_order($order_id);

        if ($order) {
            error_log('Order found: ' . $order_id);
            // Update order meta
            $order->update_meta_data('_nicepay_txid', $decoded_post['tXid']);
            $order->update_meta_data('_nicepay_vacctno', $decoded_post['vacctNo']);
            $order->update_meta_data('_nicepay_amount', $decoded_post['amt']);
            $order->update_meta_data('_nicepay_reference_no', $order_id);
            $order->update_meta_data('_nicepay_currency', $decoded_post['currency']);
            $order->save();  

            error_log('Order meta updated for order ' . $order_id);
            // Check payment status
            $this->check_payment_status($order);

            wp_send_json(array('status' => 'received'), 200);
            exit;
        } else {
            error_log('Order not found for referenceNo: ' . $order_id);
            wp_send_json_error('Order not found', 404);
        }
    } else {
        error_log('Invalid callback data received: ' . print_r($decoded_post, true));
        wp_send_json_error('Invalid callback data', 400);
    }
}
    private function check_payment_status($order) {
        error_log('Starting check_payment_status for order ' . $order->get_id());
        $access_token = $this->get_access_token();
        if (!$access_token) {
            error_log('Failed to get access token for status check');
            return;
        }
        
        $txid = trim($order->get_meta('_nicepay_txid'));
        $vacctno = trim($order->get_meta('_nicepay_vacctno'));
        $amount = trim($order->get_meta('_nicepay_amount'));
        $amt = number_format((float)$amount, 2, '.', '');
        $currency = trim($order->get_meta('_nicepay_currency'));
        $reference_no = trim($order->get_meta('_nicepay_reference_no'));
        $external = date('YmdHis') . rand(1000, 9999);
    
        $check_status_url = $this->api_endpoints['check_status_url'];
        // $addinfo = [
        //     "tXidVA" => $txid
        // ];

        // $totalAmt = [
        //     "value" => $amt,
        //     "currency" => $currency
        // ]; 
    
        $body = [
            "partnerServiceId" => "",
            "customerNo" => "",
            "virtualAccountNo" => $vacctno,
            "inquiryRequestId" => $external,
            "additionalInfo" => [
                "totalAmount" => [
                    "value" => $amt,
                    "currency" => $currency
                ],
                "trxId" => $reference_no,
                "tXidVA" => $txid
            ]
        ];
    
        $X_CLIENT_KEY = $this->get_option('X-CLIENT-KEY');
        $secretClient = $this->get_option('client_secret');
        $X_TIMESTAMP = $this->generate_formatted_timestamp();
        $channel = $X_CLIENT_KEY . "01";

        
        $stringBody = json_encode($body);
        $hashbody = strtolower(hash("SHA256", $stringBody));
        error_log('body: ' . print_r($stringBody, true));

        $strigSign = "POST:/api/v1.0/transfer-va/status:" . $access_token . ":" . $hashbody . ":" . $X_TIMESTAMP;
        $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
        $X_SIGNATURE = base64_encode($bodyHasing);

        error_log('Sending check status request for order ' . $order->get_id() . ': ' . print_r($body, true));

        $args = array(
        'method'  => 'POST',
        'timeout' => 45,
        'headers' => array(
            'Content-Type'  => 'application/json',
            'Authorization' => "Bearer " . $access_token,
            'X-CLIENT-KEY' => $X_CLIENT_KEY,
            'X-TIMESTAMP'  => $X_TIMESTAMP,
            'X-SIGNATURE' => $X_SIGNATURE,
            'X-PARTNER-ID' => $X_CLIENT_KEY,
            'X-EXTERNAL-ID' => $external,
            'CHANNEL-ID' => $channel
        ),
        'body'    => $stringBody,
        );

    $response = wp_remote_post($check_status_url, $args);
    
        if (is_wp_error($response)) {
            error_log('Error checking payment status: ' . $response->get_error_message());
            return;
        }
    
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        error_log('Received check status response for order ' . $order->get_id() . ': ' . print_r($response_body, true));
    
        if (isset($response_body['responseCode']) && $response_body['responseCode'] === '2002600') {
            $status = $response_body['additionalInfo']['latestTransactionStatus'] ?? '';
            $status_desc = $response_body['additionalInfo']['transactionStatusDesc'] ?? '';
            error_log('Payment status for order ' . $order->get_id() . ': ' . $status . ' - ' . $status_desc);
    
            switch ($status) {
                case '00':
                    $order->payment_complete($response_body['additionalInfo']['tXidVA']);
                    $order->add_order_note('Payment completed via NICEPay Virtual Account. Status: ' . $status_desc);
                    error_log('Order ' . $order->get_id() . ' marked as paid. Status: ' . $status_desc);
                    break;
                case '03':
                    if ($order->get_status() !== 'on-hold') {
                        $order->update_status('on-hold', 'Payment still pending via NICEPay Virtual Account. Status: ' . $status_desc);
                    } else {
                        $order->add_order_note('Payment still pending via NICEPay Virtual Account. Status: ' . $status_desc);
                    }
                    error_log('Order ' . $order->get_id() . ' is still pending. Status: ' . $status_desc);
                    break;
                case '04':
                    $order->update_status('cancelled', 'NICEPay Virtual Account payment expired. Status: ' . $status_desc);
                    error_log('Order ' . $order->get_id() . ' marked as expired. Status: ' . $status_desc);
                    break;
                default:
                    $order->add_order_note('Unknown payment status from NICEPay: ' . $status . ' - ' . $status_desc);
                    error_log('Unknown payment status for order ' . $order->get_id() . ': ' . $status . ' - ' . $status_desc);
                    break;
            }
            
            $order->save();
        } else {
            error_log('Invalid response from NICEPay status check: ' . print_r($response_body, true));
            $order->add_order_note('Failed to check payment status with NICEPay. Response: ' . print_r($response_body, true));
            $order->save();
        }
    }
}