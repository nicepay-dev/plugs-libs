<?php
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 *
 * This config file may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 09.03.2016
 *
 * 09.03.2016 Update Log
 *
 * ____________________________________________________________
 */
namespace libraryAstrapay;

class Config
{
    const NICEPAY_TIMEOUT_CONNECT = 15;
    const NICEPAY_TIMEOUT_READ = 25;
    const NICEPAY_READ_TIMEOUT_ERR = "10200";

    const NICEPAY_PROGRAM = "NicepayLite";
    const NICEPAY_VERSION = "1.11";
    const NICEPAY_BUILDDATE = "20220902";
    const NICEPAY_ENABLE_URL = "https://dev.nicepay.co.id/nicepay/api/linkEnable.do";
    const NICEPAY_INITIATE_URL = "https://dev.nicepay.co.id/nicepay/api/linkInitiate.do";
    const NICEPAY_ORDER_STATUS_URL = "https://dev.nicepay.co.id/nicepay/api/onePassStatus.do";

}