<?php
/*
Plugin Name: NICEPay Disbursement Payment Gateway
Plugin URI: http://nicepay.co.id
Description: NICEPay Disbursement Payment Gateway for WooCommerce
Version: 1.0
Author: NICEPay <codeNinja>
Author URI: http://nicepay.co.id
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Make sure WooCommerce is active
// Hook to initialize the gateway
add_action('plugins_loaded', 'woocommerce_nicepay_disbursement_init', 0);

function woocommerce_nicepay_disbursement_init() {
    // Check if WooCommerce is active
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    // Include the gateway class
    require_once plugin_dir_path(__FILE__) . 'nicepayrequest/NicepayRequestorPO.php';

    // Add the gateway to WooCommerce
    function add_nicepay_disbursement_gateway($methods) {
        $methods[] = 'WC_Gateway_NICEPay_Disbursement';
        return $methods;
    }
    add_filter('woocommerce_payment_gateways', 'add_nicepay_disbursement_gateway');
}

// Plugin activation hook
function nicepay_disbursement_activate() {
    // Perform any necessary setup on activation
}
register_activation_hook(__FILE__, 'nicepay_disbursement_activate');

// Plugin deactivation hook
function nicepay_disbursement_deactivate() {
    // Perform any necessary cleanup on deactivation
}
register_deactivation_hook(__FILE__, 'nicepay_disbursement_deactivate');