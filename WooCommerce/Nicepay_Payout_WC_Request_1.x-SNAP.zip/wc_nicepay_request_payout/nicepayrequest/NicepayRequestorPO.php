<?php
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('WC_Payment_Gateway')) {
    return;
}
require_once(plugin_dir_path(__FILE__) . 'nicepayrequest.php');
require_once(plugin_dir_path(__FILE__) . 'nicepayparam.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

class WC_Gateway_NICEPay_Disbursement extends WC_Payment_Gateway {
    var $callbackUrl;
        var $tSuccess = array();

        public function __construct() {
            $this->id                 = 'nicepay_disbursement';
            $this->icon               = apply_filters('woocommerce_nicepay_icon', '');
            $this->has_fields         = false;
            $this->method_title       = __('NICEPay Disbursement', 'woocommerce');
            $this->method_description = __('NICEPay Disbursement Payment Gateway', 'woocommerce');
            
    
            // Load the settings
            $this->init_form_fields();
            $this->init_settings();

        $this->redirect_url = str_replace('https:', 'http:', add_query_arg('wc-api', 'WC_Gateway_NICEPay_posnap', home_url('/')));

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->instructions = $this->get_option('instructions', $this->description);
        $this->enabled      = $this->get_option('enabled');
        $this->XCLIENTKEY   = $this->get_option('x_client_key');
        $this->xclientKey   = get_option('nicepay_x_client_key', $this->get_option('x_client_key'));
        $this->privateKey = get_option('nicepay_private_key', $this->get_option('private_key'));
        $this->secretClient = get_option('nicepay_secret_client', $this->get_option('secretClient'));
        $this->mKey         = $this->get_option('m_key');

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_receipt_nicepay_posnap', array(&$this, 'receipt_page'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        add_action('woocommerce_api_wc_gateway_nicepay_disbursement', array($this, 'webhook'));
        add_action('woocommerce_api_wc_gateway_nicepay_disbursement', array($this, 'check_nicepay_response'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        


    }
    public function enqueue_styles() {
        wp_enqueue_style('nicepay-disbursement-style', plugins_url('nicepay-disbursement.css', __FILE__));
    }
    public function nicepay_item_name($item_name) {
        if (strlen($item_name) > 127) {
            $item_name = substr($item_name, 0, 124) . '...';
        }
        return html_entity_decode($item_name, ENT_NOQUOTES, 'UTF-8');
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'woocommerce'),
                'type'    => 'checkbox',
                'label'   => __('Enable NICEPay Disbursement', 'woocommerce'),
                'default' => 'yes'
            ),
            'title' => array(
                'title'       => __('Title', 'woocommerce'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
                'default'     => __('NICEPay Disbursement', 'woocommerce'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'woocommerce'),
                'type'        => 'textarea',
                'description' => __('Payment method description that the customer will see on your checkout.', 'woocommerce'),
                'default'     => __('Pay with NICEPay Disbursement payment method.', 'woocommerce'),
                'desc_tip'    => true,
            ),
            'instructions' => array(
                'title'       => __('Instructions', 'woocommerce'),
                'type'        => 'textarea',
                'description' => __('Instructions that will be added to the thank you page and emails.', 'woocommerce'),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'x_client_key' => array(
                'title'       => __('Merchant ID', 'woocommerce'),
                'type'        => 'text',
                'description' => __('<small>Enter your NICEPay Mechant ID</small>.', 'woocommerce'),
                'default'     => 'IONPAYTEST',
                'desc_tip'    => true,
            ),
            'secretClient' => array(
                'title'       => __('Secret Client Key', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Secret Key.', 'woocommerce'),
                'default'     => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R',
                'desc_tip'    => true,
            ),
            'private_key' => array(
                'title'       => __('Private Key', 'woocommerce'),
                'type'        => 'text',
                'description' => __('Enter your NICEPay Private Key.', 'woocommerce'),
                'default'     => 'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAInJe1G22R2fMchIE6BjtYRqyMj6lurP/zq6vy79WaiGKt0Fxs4q3Ab4ifmOXd97ynS5f0JRfIqakXDcV/e2rx9bFdsS2HORY7o5At7D5E3tkyNM9smI/7dk8d3O0fyeZyrmPMySghzgkR3oMEDW1TCD5q63Hh/oq0LKZ/4Jjcb9AgMBAAECgYA4Boz2NPsjaE+9uFECrohoR2NNFVe4Msr8/mIuoSWLuMJFDMxBmHvO+dBggNr6vEMeIy7zsF6LnT32PiImv0mFRY5fRD5iLAAlIdh8ux9NXDIHgyera/PW4nyMaz2uC67MRm7uhCTKfDAJK7LXqrNVDlIBFdweH5uzmrPBn77foQJBAMPCnCzR9vIfqbk7gQaA0hVnXL3qBQPMmHaeIk0BMAfXTVq37PUfryo+80XXgEP1mN/e7f10GDUPFiVw6Wfwz38CQQC0L+xoxraftGnwFcVN1cK/MwqGS+DYNXnddo7Hu3+RShUjCz5E5NzVWH5yHu0E0Zt3sdYD2t7u7HSr9wn96OeDAkEApzB6eb0JD1kDd3PeilNTGXyhtIE9rzT5sbT0zpeJEelL44LaGa/pxkblNm0K2v/ShMC8uY6Bbi9oVqnMbj04uQJAJDIgTmfkla5bPZRR/zG6nkf1jEa/0w7i/R7szaiXlqsIFfMTPimvRtgxBmG6ASbOETxTHpEgCWTMhyLoCe54WwJATmPDSXk4APUQNvX5rr5OSfGWEOo67cKBvp5Wst+tpvc6AbIJeiRFlKF4fXYTb6HtiuulgwQNePuvlzlt2Q8hqQ==',
                'desc_tip'    => true,
            ),

        );
    }
    public function admin_options() {
        echo '<table class="form-table">';
        $this->generate_settings_html();
        echo '</table>';
    }
    public function process_admin_options() {
        parent::process_admin_options();
        $xclientKey = $this->get_option('x_client_key');
        $secret_client = $this->get_option('secretClient');
        $private_key = $this->get_option('private_key');
        
        error_log("Saving x_client_key: " . $xclientKey);
        error_log("Saving secret_client: " . $secret_client);
        error_log("Saving private_key: " . substr($private_key, 0, 20) . "..."); 
        
        update_option('nicepay_secret_client', $secret_client);
        update_option('nicepay_private_key', $private_key);
        update_option('nicepay_x_client_key', $xclientKey);
    }

    // public function validate_fields() {
    //     WC()->session->set('bankCd', isset($_POST["bankCdVAV2"]) ? $_POST["bankCdVAV2"] : '');
    //     WC()->session->set('accountno', isset($_POST["accountno"]) ? $_POST["accountno"] : '');
    // }

    //   function accountNo_list(){
    //     $accountno = array(
    //       "1234567" => array(
    //           "input" => "",
    //       )
    //     );

    //     return $accountno;
    //   }

    public function get_bank_list() {
        return array(
            'ABAL' => 'BPD BALI',
            'ABNA'  => 'ROYAL BANK SCOTLAND',
            'AGSS'  => 'BANK AGRIS',
            'AGTB'  => 'BRI AGRONIAGA',
            'AKTB' => 'BARCLAYS INDO',
            'ANTD'  => 'BANK ANTARDAERAH',
            'ANZB'  => 'BANK ANZ INDO',
            'ARFA'  => 'PANIN SYARIAH',
            'ARTG' => 'BANK ARTHA GRAHA',
            'ATOS'  => 'BANK ARTOS INDO',
            'AWAN'  => 'BANK QNB INDO',
            'BBAI'  => 'BANK BUMI ARTA',
            'BBBA' => 'PT BANK PERMATA, TBK',
            'BBIJ'  => 'BANK UOB INDO',
            'BBUK'  => 'BANK BUKOPIN',
            'BCIA'  => 'BANK CAPITAL INDO',
            'BDIN' => 'BANK DANAMON',
            'BDIP'  => 'SAHABAT SAMPOERNA',
            'BDKI'  => 'BANK DKI',
            'BDPC'  => 'BANK DANPAC',
            'BDSY' => 'DANAMON SYARIAH',
            'BHTL'  => 'BANK HARMONI INTL',
            'BICN'  => 'COMMONWEALTH',
            'BIDX'  => 'BANK INDEX SELINDO',
            'BJTM' => 'BANK JATIM',
            'BKCH'  => 'BANK OF CHINA',
            'BKKB'  => 'BANGKOK BANK',
            'BMDM'  => 'BANK MESTIKA DHARMA',
            'BMRI' => 'MANDIRI',
            'BMSE'  => 'MULTI ARTA SENTOSA',
            'BNIA'  => 'CIMB NIAGA',
            'BNIN'  => 'BNI',
            'BNPA' => 'BNP PARIBAS INDO',
            'BOFA'  => 'BANK OF AMERICA',
            'BOTK'  => 'MUFG BANK, LTD',
            'BPIA'  => 'RESONA PERDANIA',
            'BPKO' => 'BANK PIKKO',
            'BRIN'  => 'BRI',
            'BSYI'  => 'BANK SYARIAH INDONESIA',
            'BSSP'  => 'BPD SUMSELBABEL',
            'BTAN' => 'BTN',
            'BUMI'  => 'BANK MNC INTL',
            'BUST'  => 'BANK BISNIS INTL',
            'BUTG'  => 'BANK MEGA SYARIAH',
            'BVIC' => 'VICTORIA INTL',
            'BWKI'  => 'CHINA CONSTRUCTION',
            'CENA'  => 'BCA',
            'CICT'  => 'BANK MUTIARA',
            'CITI' => 'CITIBANK',
            'CNBA'  => 'BANK CENTRATAMA',
            'CTCB'  => 'BANK CTBC INDO',
            'DBSB'  => 'DBS INDO',
            'DEUT' => 'DEUTSCHE AG',
            'EKON'  => 'BANK HSBC INDO',
            'EKST'  => 'BANK PUNDI INDONESIA(KPO)',
            'FAMA'  => 'BANK FAMA',
            'GNES' => 'BANK GANESHA',
            'HNBN'  => 'BANK KEB HANA',
            'HRDA'  => 'BANK HARDA INTL',
            'HVBK'  => 'WOORI SAUDARA INDO',
            'IBBK' => 'MAYBANK INDO',
            'ICBK'  => 'BANK ICBC INDO',
            'INDO'  => 'BANK INDONESIA(KPO)',
            'INPB'  => 'BANK INA PERDANA',
            'JSAB' => 'BANK JASA JAKARTA',
            'KSEB'  => 'BANK KESEJAHTERAAN',
            'LFIB'  => 'NOBU NATIONAL BANK',
            'LMAN'  => 'BANK DINAR INDO',
            'LOMA' => 'BANK AMAR INDO',
            'MASD'  => 'BANK MASPION INDO',
            'MAYA'  => 'BANK MAYAPADA',
            'MAYO'  => 'BANK MAYORA',
            'MBBE' => 'MAYBANK SYARIAH',
            'MEEK'  => 'BANK METRO EXPRESS',
            'MEGA'  => 'BANK MEGA TBK',
            'MGAB'  => 'BANK MITRANIAGA',
            'MHCC' => 'BANK MIZUHO INDO',
            'MUAB'  => 'BANK MUAMALAT',
            'NISP'  => 'OCBC NISP',
            'NUPA'  => 'BANK NUSANTARA',
            'PDAC' => 'BANK ACEH',
            'PDBK'  => 'BPD BENGKULU',
            'PDIJ'  => 'BPD PAPUA',
            'PDJB'  => 'BANK JABAR',
            'PDJG' => 'BPD JAWA TENGAH',
            'PDJM'  => 'BPD JAMBI',
            'PDJT'  => 'BANK JATIM SYARIAH',
            'PDKB'  => 'BPD KALBAR',
            'PDKG' => 'BPD KALTENG',
            'PDKS'  => 'BPD KALSEL',
            'PDKT'  => 'BPD KALTIM',
            'PDLP'  => 'BPD LAMPUNG',
            'PDML' => 'BPD MALUKU',
            'PDNB'  => 'BPD NTB',
            'PDNT'  => 'BPD NTT',
            'PDRI'  => 'BPD RIAU KEPRI',
            'PDSB' => 'BPD SUMBAR',
            'PDSU'  => 'BPD SUMUT',
            'PDWG'  => 'BPD SULAWESITENGAH',
            'PDWR'  => 'BPD SULAWESITENGGARA',
            'PDWS' => 'BANK SULSELBAR',
            'PDWU'  => 'BPD SULAWESIUTARA',
            'PDYK'  => 'BPD YOGYA SYARIAH',
            'PINB'  => 'PANIN',
            'PMAS' => 'BANK PRIMA MASTER',
            'PUBA'  => 'BANK BTPN SYARIAH',
            'RABO'  => 'RABO BANK',
            'RIPA'  => 'BANK OKE INDO',
            'ROYB' => 'BANK ROYAL INDO',
            'SBID'  => 'BANK SBI INDO',
            'SBJK'  => 'BANK SINARMAS',
            'SCBL'  => 'STANDARD CHARTERED',
            'SDOB' => 'BUKOPIN SYARIAH',
            'SIHB'  => 'BANK SINAR HARAPAN',
            'SUNI'  => 'SUMITOMO MITSUI(KPO)',
            'SWAG'  => 'VICTORIA SYARIAH',
            'SWBA' => 'BANK OF INDIA INDO',
            'SYAC'  => 'BPD ACEH SYARIAH',
            'SYBK'  => 'MAYBANK INDO UUS',
            'SYBT'  => 'BTN SYARIAH',
            'SYCA' => 'BCA SYARIAH',
            'SYDK'  => 'BANK DKI SYARIAH',
            'SYJB'  => 'BANK JABAR SYARIAH',
            'SYKB'  => 'BPD KALBAR SYARIAH',
            'SYKS' => 'BPD KALSEL SYARIAH',
            'SYKT'  => 'BPD KALTIM SYARIAH',
            'SYNA'  => 'CIMB NIAGA SYARIAH',
            'SYNI'  => 'BNI SYARIAH',
            'SYON' => 'OCBC NISP SYARIAH',
            'SYSB'  => 'BPD SUMBAR SYARIAH',
            'SYSS'  => 'BPD SUMSEL SYARIAH',
            'SYSU'  => 'BPD SUMUT SYARIAH',
            'SYYK' => 'BPD YOGYA',
            'TAPE'  => 'BTPN',
            'YUDB'  => 'BANK YUDHA BAKTI',
            'IDMC'  => 'INDOMARET',

        );
    }
    public function payment_fields() {
        if ($this->description) {
            echo wpautop(wptexturize($this->description));
        }
        
        $banks = $this->get_bank_list();
        
        echo '<div class="nicepay-disbursement-wrapper">';
        echo '<img src="' . plugins_url('logobank.png', __FILE__) . '" alt="NICEPay Disbursement" class="nicepay-disbursement-image">';
        echo '<fieldset id="wc-' . esc_attr($this->id) . '-cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">';
        
        do_action('woocommerce_credit_card_form_start', $this->id);

                echo '<div class="form-row form-row-wide">
                <label>Pilih Bank <span class="required">*</span></label>
                <select name="nicepay_bank" id="nicepay_bank" required>
                    <option value="">Pilih Bank</option>';
            foreach ($banks as $code => $name) {
                echo '<option value="' . esc_attr($code) . '">' . esc_html($name) . '</option>';
            }
            echo '</select>
            </div>';
            
            echo '<div class="form-row form-row-wide">
                <label>Nomor Rekening <span class="required">*</span></label>
                <input id="nicepay_account_number" name="nicepay_account_number" type="text" autocomplete="off" required>
            </div>';

            do_action('woocommerce_credit_card_form_end', $this->id);

            echo '<div class="clear"></div></fieldset>';
            echo '</div>'; 
            ?>
            <script type="text/javascript">
    jQuery(function($){
        $('#nicepay_bank').select2({
            placeholder: "Cari atau pilih bank",
            allowClear: true,
            matcher: function(params, data) {
                if ($.trim(params.term) === '') {
                    return data;
                }

                if (data.text.toLowerCase().indexOf(params.term.toLowerCase()) < 0) {
                    return null;
                }
                return data;
            }
        });
    });
    </script>
            <?php
            }
      function receipt_page($order) {
        echo $this->generate_nicepay_form($order);
    }

    public function validate_fields() {
        if (empty($_POST['nicepay_bank'])) {
            wc_add_notice('Silakan pilih bank', 'error');
            return false;
        }
        if (empty($_POST['nicepay_account_number'])) {
            wc_add_notice('Silakan masukkan nomor rekening', 'error');
            return false;
        }
        return true;
    }


    public function process_payment($order_id) {
        error_log("NICEPay: Memulai proses pembayaran untuk order $order_id");
        try {
            $order = wc_get_order($order_id);
            if (!$order) {
                throw new Exception("Order tidak ditemukan");
            }
        global $woocommerce;
        $order = wc_get_order($order_id);
        $currency = $order->get_currency();
        if (sizeof($order->get_items()) > 0) {
            foreach ($order->get_items() as $item_id => $item ) {
                if (!$item['qty']) {
                    continue;
                }

                $item_name = $item->get_name();
                $item_cost_non_discount = $item->get_subtotal();

                $pro = new WC_Product($item["product_id"]);
                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $pro->get_id() ), 'single-post-thumbnail' );
                $img_url = $image[0];

                $orderInfo[] = array(
                    'img_url' => $img_url,
                    'goods_name' => $this->nicepay_item_name($item_name),
                    'goods_detail' => $this->nicepay_item_name($item_name),
                    'goods_amt' => $item_cost_non_discount
                );

                if (count($orderInfo) < 0) {
                    return false; // Abort - negative line
                }
            }
            $cartData = array(
                'count' => count($orderInfo),
                'item' => $orderInfo
            );
        }
        if($currency == 'USD'){
            $order_total = $this->get_order_total()*(int)16060;
        }else{
            $order_total = $this->get_order_total();
        }
        update_post_meta($order_id, '_nicepay_bank', sanitize_text_field($_POST['nicepay_bank']));
        update_post_meta($order_id, '_nicepay_account_number', sanitize_text_field($_POST['nicepay_account_number']));
        $payment_page = $order->get_checkout_payment_url();
        $current_user = wp_get_current_user();

         //Get Address customer
         $billingFirstName = ($current_user->ID == 0) ? $order->get_billing_first_name() : get_user_meta($current_user->ID, "billing_first_name", true);
         $billingLastName = ($current_user->ID == 0) ? $order->get_billing_last_name() : get_user_meta($current_user->ID, "billing_last_name", true);
         $virtualAccountName = $billingFirstName . " " . $billingLastName;
         $customer_name = trim($billingFirstName . ' ' . $billingLastName);
         if (empty($customer_name)) {
            $user_id = $order->get_user_id();
            if ($user_id) {
                $user = get_userdata($user_id);
                $customer_name = $user->display_name;
            }
            if (empty($customer_name)) {
                $customer_name = 'Order ' . $order->get_order_number();
            }
        }
        $customer_name = substr($customer_name, 0, 30);
         $billingPhone = ($current_user->ID == 0) ? $order->get_billing_phone() : get_user_meta($current_user->ID, "billing_phone", true);
         $billingEmail = ($current_user->ID == 0) ? $order->get_billing_email() : get_user_meta($current_user->ID, "billing_email", true);
         $billingAddr1 = ($current_user->ID == 0) ? $order->get_billing_address_1() : get_user_meta($current_user->ID, "billing_address_1", true);
         $billingAddr2 = ($current_user->ID == 0) ? $order->get_billing_address_2() : get_user_meta($current_user->ID, "billing_address_2", true);
         $billingAddr = $billingAddr1 . " " . $billingAddr2;
         $billingCity = ($current_user->ID == 0) ? $order->get_billing_city() : get_user_meta($current_user->ID, "billing_city", true);
         $billingState = WC()->countries->get_states($order->get_billing_country())[$order->get_billing_state()];
         $billingPostCd = ($current_user->ID == 0) ? $order->get_billing_postcode() : get_user_meta($current_user->ID, "billing_postcode", true);
         $billingCountry = WC()->countries->get_countries()[$order->get_billing_country()];
         error_log("NICEPay Debug - Customer Name: " . $customer_name);
     
         // Shipping Information
         $deliveryFirstName = $order->get_shipping_first_name();
         $deliveryLastName = $order->get_shipping_last_name();
         $deliveryNm = $deliveryFirstName . " " . $deliveryLastName;
         $deliveryPhone = ($current_user->ID == 0) ? $order->get_billing_phone() : get_user_meta($current_user->ID, "billing_phone", true);
         $deliveryEmail = ($current_user->ID == 0) ? $order->get_billing_email() : get_user_meta($current_user->ID, "billing_email", true);
         $deliveryAddr1 = $order->get_shipping_address_1();
         $deliveryAddr2 = $order->get_shipping_address_2();
         $deliveryAddr = $deliveryAddr1 . " " . $deliveryAddr2;
         $deliveryCity = $order->get_shipping_city();
         $deliveryState = WC()->countries->get_states($order->get_shipping_country())[$order->get_shipping_state()];
         $deliveryPostCd = $order->get_shipping_postcode();
         $deliveryCountry = WC()->countries->get_countries()[$order->get_shipping_country()];
         error_log("NICEPay: Mencoba membuat objek nicepayrequest");

         $nicepay = new nicepayrequest();
         if (!$nicepay) {
            throw new Exception("Gagal membuat objek nicepayrequest");
        }
        function generateFormattedTimestamp() {
            $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
            return $date->format('Y-m-d\TH:i:sP');
        }
        // generate x-timestamp
        $X_TIMESTAMP = generateFormattedTimestamp();
     
         $dateNow = date('Ymd');
         $vaExpiryDate = date('Ymd', strtotime($dateNow . ' +1 day'));
         $myaccount_page_id = get_option('woocommerce_myaccount_page_id');
         $myaccount_page_url = $myaccount_page_id ? get_permalink($myaccount_page_id) : null;
         $privateKey = get_option('nicepay_private_key', $this->get_option('private_key'));

        // $nicepay->set('mKey', $this->mKey);
        $nicepay->set('secretClient', $this->secretClient);
        // $nicepay->set('prrivate_key', $this->privatkey);
        // date_default_timezone_set('Asia/Jakarta');
        $nicepay->set('X-TIMESTAMP', $X_TIMESTAMP);
        $nicepay->set('X-CLIENT-KEY', $this->XCLIENTKEY);
        // $nicepay->set('payMethod', '02');
        // $nicepay->set('accountno', $this->accountno);
        $nicepay->set('currency', 'IDR');
        $nicepay->set('amt', $order_total);
        $nicepay->set('trxId', $order_id);
        $nicepay->set('goodsNm', 'Payment of invoice No '.$order_id);
        $nicepay->set('dbProcessUrl', WC()->api_request_url('WC_Gateway_NICEPay_posnap'));
        error_log("NICEPay: Data dasar telah diatur untuk order $order_id");
        $nicepay->set('description', 'Payment of invoice No '.$order_id.$virtualAccountName);
        // $nicepay->set('reqDt', date('Ymd'));
        // $nicepay->set('reqTm', date('His'));
        // $nicepay->set('$accountno', WC()->session->get('accountno'));
        // $nicepay->set('userIP', $nicepay->getUserIP());
        // $nicepay->set('cartData', json_encode($cartData));
        // unset($nicepay->requestData['privateKey']);

        // Create access Token
        $X_CLIENT_KEY = $this->XCLIENTKEY;
        // $XTIMESTAMP = date('c');
        // print_r($XTIMESTAMP);exit();
        $requestToken = 'https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b';
        $stringToSign = $X_CLIENT_KEY."|".$nicepay->get('X-TIMESTAMP');
        $privatekey = "-----BEGIN RSA PRIVATE KEY-----" . "\r\n" .
        $privateKey . // string private key
        "\r\n" .
        "-----END RSA PRIVATE KEY-----";
        $binary_signature = "";
        $pKey = openssl_pkey_get_private($privatekey);
        openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
        openssl_pkey_free($pKey);
            $signature = base64_encode($binary_signature);
            // error_log("pivatekey: " . print_r($privatekey, true));
            // print_r($privatekey);exit();
            $jsonData = array(
              "grantType" => "client_credentials",
            "additionalInfo" => ""
          );
          $jsonDataEncode = json_encode($jsonData);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $requestToken);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncode);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'X-SIGNATURE: '.base64_encode($binary_signature),
                'X-CLIENT-KEY: '.$X_CLIENT_KEY,
                'X-TIMESTAMP: '.$nicepay->get("X-TIMESTAMP")
            ));

            $output = curl_exec($ch);
            if (curl_errno($ch)) {
            error_log("NICEPay Curl Error: " . curl_error($ch));
            throw new Exception('Curl error: ' . curl_error($ch));
            }
            curl_close($ch);

            $accessToken = json_decode($output);
            if (!$accessToken || !isset($accessToken->accessToken)) {
                error_log("NICEPay Error: Invalid access token response: " . print_r($output, true));
                throw new Exception('Gagal mendapatkan access token');
            }

            error_log("NICEPay: Berhasil mendapatkan access token untuk order $order_id");
            // print_r($accessToken);exit();
            WC()->session->set('accessToken', $accessToken->accessToken);
            error_log("NICEPay: Access token yang disimpan: " . $accessToken->accessToken);



            // Request Payout
            $timestamp = date('YmdHis');
            $Request = 'https://dev.nicepay.co.id/nicepay/api/v1.0/transfer/registration';
            $authorization = "Bearer " . (is_object($accessToken) && isset($accessToken->accessToken) ? $accessToken->accessToken : '');
            error_log("NICEPay Debug - Authorization value: " . $authorization);
            $channel = $X_CLIENT_KEY."01";
            $external = $timestamp.rand();
            $partner = $X_CLIENT_KEY;
            // $amt = $nicepay->get("amt");
            error_log("NICEPay Debug - Request headers: " . print_r([
                'X-CLIENT-KEY' => $X_CLIENT_KEY,
                'X-TIMESTAMP' => $X_TIMESTAMP,
                'CHANNEL-ID' => $channel,
                'X-EXTERNAL-ID' => $external,
                'X-PARTNER-ID' => $X_CLIENT_KEY
            ], true));
            
            $secretClient = get_option('nicepay_secret_client', $this->get_option('secretClient'));
            // $this->secretClient;
            // print_r($secretClient);exit();

            $TotalAmount = [
              "value"=> $nicepay->get("amt").".00",
              "currency" => $nicepay->get("currency")
            ];
            $newBody = [
              "merchantId" => $X_CLIENT_KEY,
              "msId" => "",
              "beneficiaryAccountNo"=> get_post_meta($order_id, '_nicepay_account_number', true),
              "beneficiaryName"=> $customer_name,
              "beneficiaryPhone"=> $billingPhone,
              "beneficiaryCustomerResidence" => "1",
              "beneficiaryCustomerType" => "1",
              "beneficiaryPostalCode" => $billingPostCd,
              "payoutMethod" => "1",
              "beneficiaryBankCode" => get_post_meta($order_id, '_nicepay_bank', true),
              "amount" => $TotalAmount,
              "partnerReferenceNo" =>$order->get_order_number(),
              "reservedDt" => "",
              "reservedTm" => "",
              "deliveryId" => "",
              "deliveryName" => $deliveryNm,
              "description" => "Payment for Order" . $order->get_order_number(),
              "beneficiaryPOE" => $billingCity,
              "beneficiaryDOE" => date('ymd'),
              "beneficiaryCoNo" => $order_id,
              "beneficiaryAddress" => $billingAddr,
              "beneficiaryAuthPhoneNumber" => $billingPhone,
              "beneficiaryMerCategory" => "01",
              "beneficiaryCoMgmtName" => $customer_name,
              "beneficiaryCoShName" => $billingFirstName . " " . $billingLastName
            ];
            error_log("NICEPay: Menggunakan nomor pesanan " . $order->get_order_number() . " sebagai partnerReferenceNo untuk order ID " . $order_id);
            //  print_r($newBody);exit();
            error_log("NICEPay Debug - Request Body: " . json_encode($newBody));
            $stringBody = json_encode($newBody);
            // print_r($secretClient);exit();
            $hashbody = strtolower(hash("SHA256", $stringBody));

            // print_r($CreateVA);exit();

            $strigSign = "POST:/api/v1.0/transfer/registration:" . (is_object($accessToken) ? $accessToken->accessToken : $accessToken) . ":" . $hashbody . ":" . $X_TIMESTAMP;
            error_log("NICEPay Debug - strigSign: " . $strigSign);
            $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);
            // echo base64_encode($bodyHasing);exit();
            // print_r($strigSign);exit();

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $Request);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($newBody));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'X-SIGNATURE: ' . base64_encode($bodyHasing),
                'X-CLIENT-KEY: ' . $X_CLIENT_KEY,
                'X-TIMESTAMP: ' . $X_TIMESTAMP,
                'Authorization: ' . $authorization,
                'CHANNEL-ID: ' . $channel,
                'X-EXTERNAL-ID: ' . $external,
                'X-PARTNER-ID: ' . $X_CLIENT_KEY
            ]);
        

            $output = curl_exec($ch);
            if (curl_errno($ch)) {
                throw new Exception('Curl error pada Request Payout: ' . curl_error($ch));
            }
            curl_close($ch);

        error_log("NICEPay Raw Response dari Request Payout: " . $output);

        $data = json_decode($output, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Gagal parsing JSON response: ' . json_last_error_msg());
        error_log("NICEPay Debug - Data structure: " . print_r($data, true));
    }

        error_log("NICEPay: Menerima respon dari NICEPay untuk order $order_id: " . print_r($data, true));

    
    //   $responseMessage = $data->responseMessage;
      error_log("NICEPay: Menerima respon dari NICEPay untuk order $order_id");

            // Response from NICEPAY
            if (isset($data['responseCode']) && $data['responseCode'] == "2000000") {
                $order->add_order_note(__('Menunggu Konfirmasi Approve ' . ($data['originalReferenceNo'] ?? 'Unknown'), 'woocommerce'));
                // $bank = $this->bank_list();
                // response
                WC()->session->set('resultCd', $data['responseCode'] ?? '');
                WC()->session->set('resultMsg', $data['responseMessage'] ?? '');
                WC()->session->set('tXid', $data['originalReferenceNo'] ?? '');
                WC()->session->set('trxId', $data['partnerReferenceNo'] ?? '');
                
                if (isset($data['amount']['value'])) {
                    WC()->session->set('amt', $data['amount']['value']);
                }
                if (isset($data['amount']['currency'])) {
                    WC()->session->set('currency', $data['amount']['currency']);
                }
                
                WC()->session->set('goodsNm', $data['beneficiaryName'] ?? '');
                WC()->session->set('bankCd', $data['beneficiaryBankCode'] ?? '');
            
                update_post_meta($order_id, '_nicepay_txid', $data['originalReferenceNo'] ?? '');
                update_post_meta($order_id, '_nicepay_trxid', $data['partnerReferenceNo'] ?? '');
                update_post_meta($order_id, '_nicepay_payout_status', 'pending');
                update_post_meta($order_id, '_nicepay_beneficiary_account_no', $data['beneficiaryaccountNo'] ?? '');
                update_post_meta($order_id, '_nicepay_beneficiary_name', $data['beneficiaryName'] ?? '');
                update_post_meta($order_id, '_nicepay_beneficiary_bank_code', $data['beneficiaryBankCode'] ?? '');
                update_post_meta($order_id, '_nicepay_client_key', $X_CLIENT_KEY);
                if (isset($data['amount']['value'])) {
                    update_post_meta($order_id, '_nicepay_amount', $data['amount']['value']);
                }
                if (isset($data['amount']['currency'])) {
                    update_post_meta($order_id, '_nicepay_currency', $data['amount']['currency']);
                }
                
                update_post_meta($order_id, '_nicepay_request_date', current_time('mysql'));
                
                $order->update_status('processing', __('Awaiting NICEPay disbursement', 'woocommerce'));
                update_post_meta($order_id, '_payment_method', 'nicepay_disbursement');
                update_post_meta($order_id, '_payment_method_title', 'NICEPay Disbursement');
                error_log("NICEPay: Berhasil memproses dan menyimpan data untuk order " . $order_id);   

                wc_clear_notices();

                WC()->cart->empty_cart();

                $result = array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order)
                );

                 error_log("NICEPay: process_payment selesai untuk order $order_id dengan hasil: " . print_r($result, true));
                 return $result;
             } else {
                $error_message = isset($data['responseMessage']) ? $data['responseMessage'] : 'Unknown error';
                error_log("NICEPay Error untuk order $order_id: " . $error_message);
                
                $order->add_order_note(__('Pembayaran NICEPay gagal: ' . $error_message, 'woocommerce'));
                $order->update_status('failed', __('Pembayaran gagal', 'woocommerce'));
                
                wc_add_notice('Pembayaran gagal: ' . $error_message, 'error');
                $result = array('result' => 'failure');
                error_log("NICEPay: process_payment selesai untuk order $order_id dengan hasil: " . print_r($result, true));
                return $result;
            }  
            
    }
    catch (Exception $e) {
        error_log("NICEPay Error untuk order $order_id: " . $e->getMessage());
        wc_add_notice('Terjadi kesalahan saat memproses pembayaran: ' . $e->getMessage(), 'error');
        return array('result' => 'failure');
    }
}
    
    public function check_nicepay_response() {
        error_log("NICEPay: check_nicepay_response dipanggil");

        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);

        if (!$data) {
            error_log("NICEPay Error: Invalid JSON payload received");
            wp_die('Invalid payload', 'NICEPay Response', array('response' => 400));
        }

        error_log("NICEPay Response Data: " . print_r($data, true));
        if (!$this->validate_nicepay_response($data)) {
            error_log("NICEPay Error: Invalid response");
            wp_die('Invalid response', 'NICEPay Response', array('response' => 401));
        }

        $order_id = $data['partnerReferenceNo'] ?? ''; 
        $order = wc_get_order($order_id);

        if (!$order) {
            error_log("NICEPay Error: Order not found for ID: $order_id");
            wp_die('Order not found', 'NICEPay Response', array('response' => 404));
        }

        // Proses response
        $this->process_nicepay_response($order, $data);

        wp_die('OK', 'NICEPay Response', array('response' => 200));
    }

    private function process_nicepay_response($order, $data) {
        if ($data['responseCode'] === '2000000') { 
            $order->payment_complete($data['originalReferenceNo'] ?? '');
            $order->add_order_note('Pembayaran NICEPay berhasil. Referensi: ' . ($data['originalReferenceNo'] ?? 'Unknown'));
        } else {
            $order->update_status('failed', 'Pembayaran NICEPay gagal. Pesan: ' . ($data['responseMessage'] ?? 'Unknown error'));
        }
    }

    

    public function thankyou_page($order_id) {
        $order = wc_get_order($order_id);
        
        echo '<h2>Terima kasih atas permintaan pembayaran Anda!</h2>';
        echo '<p>Permintaan pembayaran Anda telah diterima dan sedang diproses.</p>';
        
        if ($this->instructions) {
            echo wpautop(wptexturize($this->instructions));
        }
        
        $this->disbursement_details($order_id);
    }

    public function disbursement_details($order_id) {
        $order = wc_get_order($order_id);
        $banks = $this->get_bank_list();

        $bank_code = get_post_meta($order_id, '_nicepay_bank', true);
        $bank_name = isset($banks[$bank_code]) ? $banks[$bank_code] : $bank_code;
        
        echo '<h3>Detail Permintaan Pembayaran</h3>';
        echo '<ul>';
        echo '<li>Nomor Referensi: ' . get_post_meta($order_id, '_nicepay_txid', true) . '</li>';
        echo '<li>Status: ' . get_post_meta($order_id, '_nicepay_payout_status', true) . '</li>';
        echo '<li>Jumlah: ' . get_post_meta($order_id, '_nicepay_amount', true) . ' ' . get_post_meta($order_id, '_nicepay_currency', true) . '</li>';
        echo '<li>Bank Tujuan: ' .  $bank_name  . '</li>';
        echo '<li>Nama Penerima: ' . get_post_meta($order_id, '_nicepay_beneficiary_name', true) . '</li>';
        echo '<li>Nomor Rekening: ' . get_post_meta($order_id, '_nicepay_beneficiary_account_no', true) . '</li>';
        echo '</ul>';
    }
    private function get_disbursement_info($order) {
        // Implement the logic to get disbursement info from NICEPay API
        // This is a placeholder and should be replaced with actual API call
        return array(
            'reference' => array(
                'label' => __('Reference Number', 'woocommerce'),
                'value' => $order->get_order_number()
            ),
            'status' => array(
                'label' => __('Status', 'woocommerce'),
                'value' => __('Pending', 'woocommerce')
            ),
            // Add more fields as needed
        );
    }

    public function webhook() {
        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);

        if (!$this->validate_webhook($data)) {
            wp_die('NICEPay Webhook Validation Failed', 'NICEPay Webhook', array('response' => 401));
        }

        $order_id = $data['order_id']; // Adjust based on actual payload structure
        $order = wc_get_order($order_id);

        if (!$order) {
            wp_die('Order not found', 'NICEPay Webhook', array('response' => 404));
        }

        // Process the webhook payload and update the order
        $this->process_webhook_payload($order, $data);

        wp_die('Webhook processed successfully', 'NICEPay Webhook', array('response' => 200));
    }

    private function validate_webhook($data) {
        // Implement webhook validation logic
        // This might involve checking signatures, timestamps, etc.
        return true; // Placeholder
    }

    private function process_webhook_payload($order, $data) {
        // Implement the logic to process the webhook payload
        // Update order status, add notes, etc.
        $order->add_order_note('NICEPay Disbursement: ' . $data['status']); // Adjust based on actual payload
        $order->save();
    }
}

?>