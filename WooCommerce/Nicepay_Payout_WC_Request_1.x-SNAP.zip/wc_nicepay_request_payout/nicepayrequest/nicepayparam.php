<?php
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 * Please do not modify this module.
 * This module may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 22.02.2016
 *
 * 2016.02.22 Update Log
 * Please contact it.support@ionpay.net for inquiry
 *
 * ____________________________________________________________
 */


class nicepayparam {
    public $sock = 0;
    public $apiUrl;
    public $port = 443;
    public $status;
    public $headers = "";
    public $body = "";
    public $request;
    public $errorcode;
    public $errormsg;
    public $timeout;

    public function __construct() {
        // $this->log = new NicepayLoggerVA();
    }

    public function openSocket() {
        $host = parse_url($this->apiUrl, PHP_URL_HOST);
        $tryCount = 0;
        if (! $this->sock = @fsockopen ("ssl://".$host, $this->port, $errno, $errstr, POConfig::NICEPAY_TIMEOUT_CONNECT)) {
            while ($tryCount < 5) {
                if ($this->sock = @fsockopen("ssl://".$host, $this->port, $errno, $errstr, POConfig::NICEPAY_TIMEOUT_CONNECT)) {
                    return true;
                }
                sleep(2);
                $tryCount++;
            }
            $this->errorcode = $errno;
            switch ($errno) {
                case - 3 :
                    $this->errormsg = 'Socket creation failed (-3)';
                case - 4 :
                    $this->errormsg = 'DNS lookup failure (-4)';
                case - 5 :
                    $this->errormsg = 'Connection refused or timed out (-5)';
                default :
                    $this->errormsg = 'Connection failed (' . $errno . ')';
                    $this->errormsg .= ' ' . $errstr;
            }
            return false;
        }
        return true;
    }

}