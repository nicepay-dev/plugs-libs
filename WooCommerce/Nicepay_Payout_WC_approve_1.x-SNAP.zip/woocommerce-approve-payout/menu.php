<?php
/*
Plugin Name: WooCommerce Payout Menu
Description: Payout Transaksi
Version: 1.0
Author: NICEPay
*/

if (!defined('ABSPATH')) {
    exit;
}
// require_once plugin_dir_path(__FILE__) . 'helpers.php';

if (!defined('WC_PAYOUT_MENU_LOADED')) {
    define('WC_PAYOUT_MENU_LOADED', true);
    add_action('admin_init', 'wc_payout_menu_check_woocommerce');
    add_action('admin_menu', 'wc_payout_menu_add_menu', 99);
    add_action('init', 'register_nicepay_webhook_endpoint');
    add_action('parse_request', 'handle_nicepay_notification');
    add_filter('query_vars', 'add_nicepay_webhook_query_var');
    add_action('woocommerce_view_order', 'nicepay_refresh_order_status_on_view', 10, 1);
}
function nicepay_refresh_order_status_on_view($order_id) {
    $order = wc_get_order($order_id);
    if ($order && $order->get_payment_method() === 'nicepay_disbursement') {
        refresh_nicepay_order_status($order_id);
    }
}


function wc_payout_menu_check_woocommerce() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'wc_payout_menu_woocommerce_missing_notice');
        deactivate_plugins(plugin_basename(__FILE__));
        if (isset($_GET['activate'])) {
            unset($_GET['activate']);
        }
    }
}

function wc_payout_menu_woocommerce_missing_notice() {
    ?>
    <div class="error">
        <p><?php _e('WooCommerce Payout Menu membutuhkan plugin WooCommerce untuk berfungsi. Silakan instal dan aktifkan WooCommerce terlebih dahulu.', 'wc-payout-menu'); ?></p>
    </div>
    <?php
}

function wc_payout_menu_add_menu() {
    if (current_user_can('manage_woocommerce')) {
        add_submenu_page(
            'woocommerce',
            'NICEPay Payout',
            'NICEPay Payout',
            'manage_woocommerce',
            'wc-payout-menu',
            'wc_payout_menu_page_content'
        );
    }
}
function get_nicepay_payout_data($order_id) {
    return array(
        'txid' => get_post_meta($order_id, '_nicepay_txid', true),
        'trxid' => get_post_meta($order_id, '_nicepay_trxid', true),
        'payout_status' => get_post_meta($order_id, '_nicepay_payout_status', true),
        'beneficiary_account_no' => get_post_meta($order_id, '_nicepay_beneficiary_account_no', true),
        'beneficiary_name' => get_post_meta($order_id, '_nicepay_beneficiary_name', true),
        'beneficiary_bank_code' => get_post_meta($order_id, '_nicepay_beneficiary_bank_code', true),
        'amount' => get_post_meta($order_id, '_nicepay_amount', true),
        'currency' => get_post_meta($order_id, '_nicepay_currency', true),
        'request_date' => get_post_meta($order_id, '_nicepay_request_date', true)
    );
}


function wc_payout_menu_page_content() {
    if (!current_user_can('manage_woocommerce')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    $saldo = get_nicepay_saldo();
    error_log('NICEPay: Saldo yang diterima - ' . print_r($saldo, true));
    wp_enqueue_script('react');
    wp_enqueue_script('react-dom');
    wp_enqueue_script('nicepay-saldo-widget', plugin_dir_url(__FILE__) . '/nicepay-saldo-widget.js', array('react', 'react-dom'), '1.0', true);

    global $wpdb;

    $page = isset($_GET['paged']) ? abs((int)$_GET['paged']) : 1;
    $limit = 20;
    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
    error_log('NICEPay: Fetching orders for page ' . $page);

    $orders = get_nicepay_payout_orders(array('limit' => $limit, 'paged' => $page));

    error_log('NICEPay: Retrieved ' . count($orders) . ' orders');

    $sql = $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->posts} p
        JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
        JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id
        WHERE p.post_type = %s
        AND pm.meta_key = %s
        AND pm.meta_value = %s
        AND pm2.meta_key = %s",
        'shop_order',
        '_payment_method',
        'nicepay_disbursement',
        '_nicepay_payout_status'
        );
    $merchant_id = get_option('nicepay_merchant_id', 'IONPAYTEST'); // Default value
    echo '<style>
     .nicepay-admin-wrap { margin: 20px; }
    .nicepay-admin-wrap h1 { margin-bottom: 20px; }
    .nicepay-form-container { background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin-bottom: 20px; }
    .nicepay-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
    .merchant-id-form { flex-grow: 1; }
    .nicepay-logo { max-width: 70px; height: auto; }
    .nicepay-table-container { margin-top: 20px; }
    .wp-list-table { border: 1px solid #ccd0d4; }
    .search-box { float: right; margin-bottom: 10px; }
    #nicepay-saldo-widget { padding: 10px; background-color: #f9f9f9; border: 1px solid #ddd; }
    </style>';
    $total_items = $wpdb->get_var($sql);
    error_log('NICEPay: Total items query - ' . $sql);
    error_log('NICEPay: Total items found - ' . $total_items);
    ?>
    
    <div class="wrap">
        <h1 class="wp-heading-inline"><?php echo esc_html__('NICEPay Payout', 'wc-payout-menu'); ?></h1>
        <hr class="wp-header-end">
        <div class="nicepay-form-container">
        <div class="nicepay-header">
                <form method="post" action="" class="merchant-id-form">
                    <?php wp_nonce_field('save_nicepay_merchant_id', 'nicepay_merchant_id_nonce'); ?>
                    <label for="nicepay_merchant_id">Merchant ID</label>
                    <input type="text" id="nicepay_merchant_id" name="nicepay_merchant_id" value="<?php echo esc_attr($merchant_id); ?>" class="regular-text">
                    <input type="submit" name="save_merchant_id" class="button-primary" value="Save Merchant ID">
                </form>
            <img src="<?php echo plugin_dir_url(__FILE__) . 'nicepay.png'; ?>" alt="NICEPay Logo" class="nicepay-logo">
            
        </div>
        <div id="nicepay-saldo-widget"></div>
        </div>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const saldoWidget = document.getElementById("nicepay-saldo-widget");
                if (typeof React !== "undefined" && typeof ReactDOM !== "undefined" && typeof NICEPaySaldoWidget !== "undefined") {
                    ReactDOM.render(React.createElement(NICEPaySaldoWidget, { initialSaldo: <?php echo json_encode($saldo); ?> }), saldoWidget);
                } else {
                    console.error("React, ReactDOM, atau NICEPaySaldoWidget tidak tersedia");
                    saldoWidget.innerHTML = "Saldo NICEPay: Rp <?php echo number_format($saldo, 0, ',', '.'); ?>";
                }
            });
        </script>

        <div class="nicepay-table-container">
            <form method="get">
                <input type="hidden" name="page" value="wc-payout-menu">
                <?php
                $search_term = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
                ?>
                <p class="search-box">
                    <label class="screen-reader-text" for="post-search-input">Cari pesanan:</label>
                    <input type="search" id="post-search-input" name="s" value="<?php echo esc_attr($search_term); ?>">
                    <input type="submit" id="search-submit" class="button" value="Cari Pesanan">
                </p>
            </form>


        <form id="posts-filter" method="post">
            <input type="hidden" name="page" value="wc-payout-menu" />
            <?php wp_nonce_field('process_nicepay_payout', 'nicepay_payout_nonce'); ?>
            <table class="wp-list-table widefat fixed striped posts">
    <thead>
        <tr>
            <th>Pesanan</th>
            <th>Tanggal</th>
            <th>Status</th>
            <th>Total</th>
            <th>Status Nicepay</th>
            <th>TXID</th>
            <th>Approve</th>
            <th>Reject</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        if (!empty($orders) && is_array($orders)) {
            foreach ($orders as $order) {
                if ($order instanceof WC_Order) {
                    $payout_data = get_nicepay_payout_data($order->get_id());
                    $nicepay_status = get_post_meta($order->get_id(), '_nicepay_payout_status', true);
        ?>
            <tr>
                <td><?php echo $order->get_order_number(); ?></td>
                <td><?php echo $order->get_date_created()->date('Y-m-d H:i:s'); ?></td>
                <td><?php echo wc_get_order_status_name($order->get_status()); ?></td>
                <td><?php echo $order->get_formatted_order_total(); ?></td>
                <td><?php echo $nicepay_status; ?></td>
                <td><?php echo isset($payout_data['txid']) ? $payout_data['txid'] : 'N/A'; ?></td>
                <td>
                <?php if ($nicepay_status === 'pending'): ?>
                <input type="checkbox" name="approve[]" value="<?php echo $order->get_id(); ?>">
                <?php endif; ?>
                </td>
                <td>
                <?php if ($nicepay_status === 'pending'): ?>
                <input type="checkbox" name="reject[]" value="<?php echo $order->get_id(); ?>">
                <?php endif; ?>
                </td>
            </tr>   
        <?php 
                }
            }
        } else {
            echo '<tr><td colspan="8">Tidak ada pesanan yang ditemukan.</td></tr>';
        }
        ?>
    </tbody>

</table>
<p>
    <input type="submit" name="process_payout" class="button button-primary" value="Proses Payout">
</p>
<?php
echo paginate_links(array(
    'base' => add_query_arg('paged', '%#%'),
    'format' => '',
    'prev_text' => __('&laquo;'),
    'next_text' => __('&raquo;'),
    'total' => ceil($total_items / $limit),
    'current' => $page
));
?>
        </form>
    </div>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('input[name="approve[]"], input[name="reject[]"]').on('change', function() {
            var orderId = $(this).val();
            if ($(this).is(':checked')) {
                if ($(this).attr('name') === 'approve[]') {
                    $('input[name="reject[]"][value="' + orderId + '"]').prop('checked', false);
                } else {
                    $('input[name="approve[]"][value="' + orderId + '"]').prop('checked', false);
                }
            }
        });
        

        $('#posts-filter').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();

            $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData + '&action=process_nicepay_payout',
            dataType: 'json',
            success: function(response) {
                if (response && response.success) {
                    if (response.processed && response.processed.length > 0) {
                        response.processed.forEach(function(item) {
                            var row = $('input[name="' + item.action + '[]"][value="' + item.id + '"]').closest('tr');
                            row.find('td:nth-last-child(2), td:last-child').empty(); // Menghapus checkbox
                    
                            if (item.action === 'approve') {
                                row.find('td:nth-child(3)').text('Disetujui');
                                row.find('td:nth-child(5)').text('approved');
                            } else if (item.action === 'reject') {
                                row.find('td:nth-child(3)').text('Dibatalkan');
                                row.find('td:nth-child(5)').text('rejected');
                            }
                        });
                    }


                        if (response.errors && response.errors.length > 0) {
                            alert('Beberapa pesanan tidak dapat diproses. Silahkan hubungi NICEPay.');
                        } else {
                            alert('Semua pesanan yang dipilih telah berhasil diproses.');
                        }
                    } else {
                        alert('Terjadi kesalahan. Silakan coba lagi.');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('AJAX Error:', textStatus, errorThrown);
                    alert('Terjadi kesalahan. Silakan coba lagi.');
                }
            });
        });
    });
    </script>
    <?php
}

function get_nicepay_order_data_for_api($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) {
        return false;
    }

    return array(
        "originalPartnerReferenceNo" => $order->get_id(),
        "originalReferenceNo" => get_post_meta($order->get_id(), '_nicepay_txid', true),
        "merchantId" => "IONPAYTEST"
    );
}
function wc_approve_payout_generate_formatted_timestamp() {
    $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
    return $date->format('Y-m-d\TH:i:sP');
}
// Set value from database
// $privateKey = get_option('nicepay_private_key', ''); 
// $secretClient = get_option('nicepay_secret_client', '');
// $xClientKey = get_option('nicepay_x_client_key', '');

function get_nicepay_access_token() {
    $X_TIMESTAMP = wc_approve_payout_generate_formatted_timestamp();
    $X_CLIENT_KEY = get_option('nicepay_merchant_id', '');
    $privateKey = get_option('nicepay_private_key', '');
    $requestToken = 'https://dev.nicepay.co.id/nicepay/v1.0/access-token/b2b';
    $stringToSign = $X_CLIENT_KEY."|".$X_TIMESTAMP;
    $privatekey = "-----BEGIN RSA PRIVATE KEY-----\r\n" . $privateKey . "\r\n-----END RSA PRIVATE KEY-----";

    error_log("merchant id : " . $X_CLIENT_KEY);
    error_log("private key : " . $privateKey);
    
    $binary_signature = "";
    $pKey = openssl_pkey_get_private($privatekey);
    if (!$pKey) {
        error_log("NICEPay Error: Failed to get private key");
        return false;
    }
    openssl_sign($stringToSign, $binary_signature, $pKey, OPENSSL_ALGO_SHA256);
    openssl_pkey_free($pKey);
    
    $signature = base64_encode($binary_signature);
    $jsonData = array(
        "grantType" => "client_credentials",
        "additionalInfo" => ""
    );
    
    $jsonDataEncode = json_encode($jsonData);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $requestToken);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncode);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'X-SIGNATURE: '.$signature,
        'X-CLIENT-KEY: '.$X_CLIENT_KEY,
        'X-TIMESTAMP: '.$X_TIMESTAMP
    ));
    $output = curl_exec($ch);
    if (curl_errno($ch)) {
        error_log("NICEPay Curl Error: " . curl_error($ch));
        curl_close($ch);
        return false;
    }
    curl_close($ch);
    
    $accessToken = json_decode($output);
    if (!$accessToken || !isset($accessToken->accessToken)) {
        error_log("NICEPay Error: Invalid access token response");
        return false;
    }
    return $accessToken->accessToken;
}

function call_nicepay_api($endpoint, $data, $accessToken) {
    $X_CLIENT_KEY = get_option('nicepay_merchant_id', '');
    $X_TIMESTAMP = wc_approve_payout_generate_formatted_timestamp();
    $secretClient = get_option('nicepay_secret_client', '');

    $stringBody = json_encode($data);
    error_log("NICEPay: Request Body - " . $stringBody);
    $hashbody = strtolower(hash("SHA256", $stringBody));
    $strigSign = "POST:$endpoint:$accessToken:$hashbody:$X_TIMESTAMP";
    $bodyHasing = hash_hmac("sha512", $strigSign, $secretClient, true);

    $api_url = "https://dev.nicepay.co.id/nicepay" . $endpoint;
    error_log("NICEPay: Full API URL - " . $api_url);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $stringBody);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'X-SIGNATURE: ' . base64_encode($bodyHasing),
        'X-CLIENT-KEY: ' . $X_CLIENT_KEY,
        'X-TIMESTAMP: ' . $X_TIMESTAMP,
        'Authorization: Bearer ' . $accessToken,
        'CHANNEL-ID: ' . $X_CLIENT_KEY . "01",
        'X-EXTERNAL-ID: ' . date('YmdHis') . rand(),
        'X-PARTNER-ID: ' . $X_CLIENT_KEY
    ]);

    $output = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        error_log("NICEPay Curl Error: " . curl_error($ch));
        curl_close($ch);
        return false;
    }
    curl_close($ch);

    error_log("NICEPay API Response Code: " . $httpCode);
    error_log("NICEPay API Raw Response: " . $output);

    $data = json_decode($output);
    if (!$data && $httpCode != 200) {
        error_log("NICEPay Error: Invalid JSON response - " . $output);
        return false;
    }

    return $data;
}

// API SALDO
function get_nicepay_saldo() {
    $accessToken = get_nicepay_access_token();
    if (!$accessToken) {
        error_log("NICEPay Error: Gagal mendapatkan token akses");
        return 0;
    }

    $endpoint = '/api/v1.0/balance-inquiry';
    $data = [
        "accountNo" => get_option('nicepay_merchant_id', ''),
        "additionalInfo" => [
            "msId" => ""
        ],
    ];

    $result = call_nicepay_api($endpoint, $data, $accessToken);

    if (!$result) {
        error_log("NICEPay Error: Tidak ada respons dari API");
        return 0;
    }
    error_log("NICEPay API Raw Response: " . print_r($result, true));

    if (isset($result->responseCode) && $result->responseCode === "2001100") {
        if (isset($result->accountInfos) && is_array($result->accountInfos) && !empty($result->accountInfos)) {
            $balance = $result->accountInfos[0]->availableBalance->value ?? 0;
            error_log("NICEPay: Saldo yang diterima - " . $balance);
            return floatval($balance);
        }
    }
    error_log("NICEPay Error: Format respons tidak sesuai atau saldo tidak ditemukan");


    return 0;
}
add_action('rest_api_init', function () {
    register_rest_route('nicepay/v1', '/saldo', array(
        'methods' => 'GET',
        'callback' => 'get_nicepay_saldo_api',
        'permission_callback' => function () {
            return current_user_can('manage_woocommerce');
        }
    ));
});

function get_nicepay_saldo_api() {
    $saldo = get_nicepay_saldo();
    if ($saldo === false) {
        return new WP_Error('nicepay_error', 'Gagal mengambil saldo', array('status' => 500));
    }
    return new WP_REST_Response(array('saldo' => $saldo), 200);
}

function call_nicepay_api_wrapper($order_id, $action, $payout_data) {
    $accessToken = get_nicepay_access_token();
    if (!$accessToken) {
        error_log("NICEPay Error: Failed to get access token for order $order_id");
        return false;
    }
    $merchant_id = get_option('nicepay_merchant_id', '');

    $data = [
        "originalPartnerReferenceNo" => $payout_data['trxid'],
        "originalReferenceNo" => $payout_data['txid'],
        "merchantId" => $merchant_id
    ];

    $endpoint = $action === 'approve' ? '/api/v1.0/transfer/approve' : '/api/v1.0/transfer/reject';
    
    error_log("NICEPay: Processing $action for order $order_id");
    error_log("NICEPay: API Endpoint - $endpoint");
    error_log("NICEPay: Request data - " . print_r($data, true));
    error_log("NICEPay: Access Token - " . substr($accessToken, 0, 10) . '...');

    $result = call_nicepay_api($endpoint, $data, $accessToken);

    if (!$result) {
        error_log("NICEPay Error: API call failed for order $order_id");
        return false;
    }

    error_log("NICEPay: API Response for order $order_id - " . print_r($result, true));

    if (isset($result->responseCode) && $result->responseCode === '2000000') {
        error_log("NICEPay: Successfully processed $action for order $order_id");
        return true;
    } else {
        error_log("NICEPay Error: Failed to process $action for order $order_id. Response: " . print_r($result, true));
        return false;
    }
}
function nicepay_approve_payout($payout_data) {
    if (isset($_POST['process_payout']) && isset($_POST['nicepay_payout_nonce']) && wp_verify_nonce($_POST['nicepay_payout_nonce'], 'process_nicepay_payout')) {
        $approve_orders = isset($_POST['approve']) ? array_map('intval', $_POST['approve']) : array();
        $reject_orders = isset($_POST['reject']) ? array_map('intval', $_POST['reject']) : array();

        $processed = 0;
        $errors = 0;

        foreach ($approve_orders as $order_id) {
            $payout_data = get_nicepay_payout_data($order_id);
            if ($payout_data && call_nicepay_api_wrapper($order_id, 'approve', $payout_data)) {
                update_post_meta($order_id, '_nicepay_payout_status', 'approved');
                $processed++;
            } else {
                $errors++;
            }
        }

        foreach ($reject_orders as $order_id) {
            $payout_data = get_nicepay_payout_data($order_id);
            if ($payout_data && call_nicepay_api_wrapper($order_id, 'reject', $payout_data)) {
                update_post_meta($order_id, '_nicepay_payout_status', 'rejected');
                $processed++;
            } else {
                $errors++;
            }
         }
         add_action('admin_notices', function() use ($processed, $errors) {
            ?>
            <div class="notice notice-<?php echo $errors > 0 ? 'warning' : 'success'; ?> is-dismissible">
                <p><?php 
                echo sprintf('%d payout actions processed successfully.', $processed);
                if ($errors > 0) {
                    echo sprintf(' %d actions failed.', $errors);
                }
                ?></p>
            </div>
            <?php
        });
    }
    }
function nicepay_reject_payout($payout_data) {
    $accessToken = get_nicepay_access_token();
    $data = [
        "originalPartnerReferenceNo" => $payout_data['trxid'],
        "originalReferenceNo" => $payout_data['txid'],
        "merchantId" => get_option('nicepay_merchant_id', '')
    ];
    return call_nicepay_api('/v1.0/transfer/reject', $data, $accessToken);
}
function save_nicepay_merchant_id() {
    if (isset($_POST['save_merchant_id']) && isset($_POST['nicepay_merchant_id_nonce']) && wp_verify_nonce($_POST['nicepay_merchant_id_nonce'], 'save_nicepay_merchant_id')) {
        $merchant_id = sanitize_text_field($_POST['nicepay_merchant_id']);
        update_option('nicepay_merchant_id', $merchant_id);
        add_action('admin_notices', function() {
            ?>
            <div class="notice notice-success is-dismissible">
                <p><?php _e('Merchant ID saved successfully.', 'wc-payout-menu'); ?></p>
            </div>
            <?php
        });
    }
}
add_action('admin_init', 'save_nicepay_merchant_id');

function process_payout_action() {
    check_ajax_referer('process_nicepay_payout', 'nicepay_payout_nonce');

    $approve_orders = isset($_POST['approve']) ? array_map('intval', $_POST['approve']) : array();
    $reject_orders = isset($_POST['reject']) ? array_map('intval', $_POST['reject']) : array();

    $processed = array();
    $errors = array();

    foreach ($approve_orders as $order_id) {
        $payout_data = get_nicepay_payout_data($order_id);
        if ($payout_data) {
            if (call_nicepay_api_wrapper($order_id, 'approve', $payout_data)) {
                update_post_meta($order_id, '_nicepay_payout_status', 'approved');
                $processed[] = array('id' => $order_id, 'action' => 'approve');
            } else {
                $errors[] = $order_id;
            }
        } else {
            $errors[] = $order_id;
        }
    }

    foreach ($reject_orders as $order_id) {
        $order = wc_get_order($order_id);
        if ($order) {
            $order->update_status('cancelled', 'Payout rejected by admin');
            update_post_meta($order_id, '_nicepay_payout_status', 'rejected');
            $processed[] = array('id' => $order_id, 'action' => 'reject');
        } else {
            $errors[] = $order_id;
        }
    }

    wp_send_json(array(
        'success' => true,
        'processed' => $processed,
        'errors' => $errors
    ));
}
add_action('wp_ajax_process_nicepay_payout', 'process_payout_action');
function get_nicepay_payout_orders($args = array()) {
    $query_args = array(
        'limit' => isset($args['limit']) ? $args['limit'] : 20,
        'paged' => isset($args['paged']) ? $args['paged'] : 1,
        'orderby' => 'date',
        'order' => 'DESC',
        'payment_method' => 'nicepay_disbursement',
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key' => '_nicepay_payout_status',
                'EXISTS' => '='
            ),
            array(
                'key' => '_nicepay_payout_status',
                'NOT EXISTS' => '='
            )
        )
    );
    if (!empty($args['search'])) {
        $query_args['search'] = $args['search'];
    }

    error_log('NICEPay: Fetching orders with query args - ' . print_r($query_args, true));

    $orders = wc_get_orders($query_args);

    error_log('NICEPay: Found ' . count($orders) . ' orders.');

    $all_nicepay_orders = wc_get_orders(array(
        'limit' => -1,
        'payment_method' => 'nicepay_disbursement'
    ));
    error_log('NICEPay: Total nicepay_disbursement orders: ' . count($all_nicepay_orders));

    $pending_orders = wc_get_orders(array(
        'limit' => -1,
        'status' => 'pending',
        'payment_method' => 'nicepay_disbursement'
    ));
    error_log('NICEPay: Total pending nicepay_disbursement orders: ' . count($pending_orders));

    return $orders;
}
function count_nicepay_payout_orders($search = '') {
    $query_args = array(
        'limit' => -1,
        'return' => 'ids',
        'payment_method' => 'nicepay_disbursement',
        'meta_query' => array(
            'relation'=>'OR',
            array(
                'key' => '_nicepay_payout_status',
                'compare' => 'EXISTS'
            ),
            array(
                'key' => '_nicepay_payout_status',
                'compare' => 'NOT EXISTS'
            )
        )
    );

    if (!empty($search)) {
        $query_args['search'] = $search;
    }

    $orders = wc_get_orders($query_args);
    return count($orders);
}

add_filter('manage_edit-shop_order_columns', function($columns) {
    if (isset($_GET['page']) && $_GET['page'] === 'wc-payout-menu') {
        $new_columns = array();
        foreach ($columns as $column_name => $column_info) {
            $new_columns[$column_name] = $column_info;
            if ($column_name === 'order_status') {
                $new_columns['nicepay_status'] = __('NICEPay Status', 'wc-payout-menu');
            }
        }
        return $new_columns;
    }
    return $columns;
});

add_action('manage_shop_order_posts_custom_column', function($column, $post_id) {
    if ($column === 'nicepay_status') {
        $order = wc_get_order($post_id);
        echo $order->get_meta('_nicepay_payout_status');
    }
}, 20, 2);

function debug_nicepay_orders() {
    global $wpdb;
    $sql = $wpdb->prepare("
    SELECT p.ID, p.post_date, pm1.meta_value as payment_method, pm2.meta_value as payout_status
    FROM {$wpdb->posts} p
    JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_payment_method'
    LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_nicepay_payout_status'
    WHERE p.post_type = %s
    AND pm1.meta_value = %s
    ORDER BY p.post_date DESC
    LIMIT 20
    ", 'shop_order', 'nicepay_disbursement');
    
    $results = $wpdb->get_results($sql);
    error_log('NICEPay Debug: SQL Query - ' . $sql);
    error_log('NICEPay Debug: Direct DB Query Results - ' . print_r($results, true));
    
    if (empty($results)) {
        error_log('NICEPay Debug: No orders found with nicepay_disbursement payment method');
        // Check if there are any orders with this payment method
        $check_payment_method = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_payment_method' AND meta_value = %s",
            'nicepay_disbursement'
        ));
        error_log('NICEPay Debug: Number of orders with nicepay_disbursement payment method: ' . $check_payment_method);
    }
    
    // Check total number of orders
    $total_orders = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'shop_order'");
    error_log('NICEPay Debug: Total number of orders - ' . $total_orders);
}

add_action('init', 'debug_nicepay_orders');

function update_nicepay_order_meta($order_id) {
    $order = wc_get_order($order_id);
    if ($order) {
        error_log('NICEPay: Pesanan berhasil diakses dengan ID: ' . $order_id);
        if ($order->get_payment_method() === 'nicepay_disbursement') {
            $order->update_meta_data('_nicepay_payout_status', 'pending');
            $order->save();
            error_log('NICEPay: Meta status _nicepay_payout_status diset menjadi pending.');
        }
    } else {
        error_log('NICEPay: Tidak dapat menemukan pesanan dengan ID: ' . $order_id);
    }
}

add_action('woocommerce_checkout_update_order_meta', 'update_nicepay_order_meta', 10, 1);
add_action('woocommerce_payment_complete', 'update_nicepay_order_meta', 10, 1);

require_once plugin_dir_path(__FILE__) . 'nicepay-webhook.php';

add_action('init', 'register_nicepay_webhook_endpoint');

function register_nicepay_webhook_endpoint() {
    add_rewrite_rule('^nicepay-payout-snap/?', 'index.php?nicepay_webhook=1', 'top');
    flush_rewrite_rules();
    $webhook_url = home_url('nicepay-payout-snap/');
    error_log('NICEPay Webhook URL: ' . $webhook_url);
}

add_filter('query_vars', 'add_nicepay_webhook_query_var');

function add_nicepay_webhook_query_var($vars) {
    $vars[] = 'nicepay-payout-snap';
    return $vars;
}

add_action('init', 'register_nicepay_notification_endpoint');
function register_nicepay_notification_endpoint() {
    add_rewrite_rule('^nicepay-notification/?', 'index.php?nicepay-notification=1', 'top');
}

add_filter('query_vars', 'add_nicepay_notification_query_var');
function add_nicepay_notification_query_var($vars) {
    $vars[] = 'nicepay-notification';
    return $vars;
}

function handle_nicepay_notification($wp) {
    error_log('NICEPay: Entering handle_nicepay_notification function');
    error_log('NICEPay: Query vars - ' . print_r($wp->query_vars, true));
    error_log('NICEPay: $_GET data - ' . print_r($_GET, true));
    error_log('NICEPay: $_POST data - ' . print_r($_POST, true));
    error_log('NICEPay: Raw input - ' . file_get_contents('php://input'));
    
    if (isset($wp->query_vars['nicepay_payout_snap']) || strpos($_SERVER['REQUEST_URI'], 'nicepay-payout-snap') !== false) {
        error_log('NICEPay: nicepay_payout_snap detected');
        
        // Parse the received data
        $notification_data = $_POST;
        if (empty($notification_data)) {
            $notification_data = json_decode(file_get_contents('php://input'), true);
        }
        error_log('NICEPay Parsed Notification Data: ' . print_r($notification_data, true));

        // Process the notification
        process_nicepay_notification($notification_data);

        // Respond to NICEPay
        error_log('NICEPay: Sending response');
        echo json_encode(array('status' => 'OK'));
        exit;
    } else {
        error_log('NICEPay: nicepay_payout_snap not detected in query vars or REQUEST_URI');
    }
}
add_action('parse_request', 'handle_nicepay_notification');

function verify_nicepay_notification() {
    $headers = getallheaders();
    $signature = isset($headers['X-SIGNATURE']) ? $headers['X-SIGNATURE'] : '';
    $body = file_get_contents('php://input');
    
    // Use your secret key to verify the signature
    $secret_key = 'YOUR_SECRET_KEY'; // Replace with your actual secret key
    $calculated_signature = hash_hmac('sha512', $body, $secret_key);
    
    return hash_equals($calculated_signature, $signature);
}

function process_nicepay_notification($data) {
    error_log('NICEPay: Entering process_nicepay_notification function');
    error_log('Received NICEPay notification: ' . print_r($data, true));

    $order_id = $data['referenceNo'] ?? '';
    $txid = $data['tXid'] ?? '';
    $initial_status = $data['status'] ?? '';
    $amount = $data['amt'] ?? '';
    $beneficiary_account_no = $data['accountNo'] ?? '';

    error_log("NICEPay: Processing order $order_id with initial status $initial_status");
    error_log("NICEPay: Beneficiary Account No from notification: $beneficiary_account_no");

    $order = wc_get_order($order_id);
    if (!$order) {
        error_log("NICEPay Error: Order not found for ID $order_id");
        return;
    }
    if (empty($beneficiary_account_no)) {
        $beneficiary_account_no = $order->get_meta('_nicepay_beneficiary_account_no');
        error_log("NICEPay: Beneficiary Account No from order meta: $beneficiary_account_no");
    }
    if (empty($beneficiary_account_no)) {
        error_log("NICEPay Warning: Beneficiary account number not found for order $order_id");
    }

    $final_status = check_nicepay_status($order_id, $txid, $beneficiary_account_no);

    if ($final_status === false) {
        error_log("NICEPay Error: Failed to get final status for order $order_id, transaction $txid");
        $final_status = $initial_status === '0' ? 'SUCCESS' : 'UNKNOWN';
    }
    error_log("NICEPay: Final status for order $order_id is $final_status");

    if ($final_status === 'SUCCESS') {
        error_log("NICEPay: Updating order $order_id to completed");
        $order->update_status('completed', 'Payment completed via NICEPay');
        update_post_meta($order_id, '_nicepay_payout_status', 'completed');
        
        $order->update_meta_data('_nicepay_transaction_id', $txid);
        $order->update_meta_data('_nicepay_amount', $amount);
        
        if ($order->get_total() != $amount) {
            error_log("NICEPay Warning: Amount mismatch for order $order_id. Expected: {$order->get_total()}, Received: $amount");
        }
    } elseif ($final_status === 'PENDING' || $final_status === 'PENDING_SUSPECT') {
        error_log("NICEPay: Updating order $order_id to on-hold");
        $order->update_status('on-hold', 'Payment pending via NICEPay');
        update_post_meta($order_id, '_nicepay_payout_status', 'pending');
    } else {
        error_log("NICEPay: Updating order $order_id to failed");
        $order->update_status('failed', 'Payment failed via NICEPay');
        update_post_meta($order_id, '_nicepay_payout_status', 'failed');
    }

    $order->save();
    error_log("NICEPay: Order $order_id processed. New WooCommerce status: " . $order->get_status());
    error_log("NICEPay: Order $order_id NICEPay payout status: " . get_post_meta($order_id, '_nicepay_payout_status', true));
}
function check_nicepay_status($order_id, $txid, $beneficiary_account_no) {
    $accessToken = get_nicepay_access_token();
    if (!$accessToken) {
        error_log("NICEPay Error: Failed to get access token for status check");
        return false;
    }

    $endpoint = '/api/v1.0/transfer/inquiry';
    $merchant_id = get_option('nicepay_merchant_id', '');

    $data = [
        "originalPartnerReferenceNo" => $order_id,
        "originalReferenceNo" => $txid,
        "merchantId" => $merchant_id,
        "beneficiaryAccountNo" => $beneficiary_account_no
    ];

    error_log("NICEPay: Checking status for order $order_id, transaction $txid");
    error_log("NICEPay: Request data - " . json_encode($data));

    $result = call_nicepay_api($endpoint, $data, $accessToken);

    if (!$result) {
        error_log("NICEPay Error: Status check API call failed for order $order_id, transaction $txid");
        return false;
    }

    // Log the full response
    error_log("NICEPay: Full API Response for order $order_id, transaction $txid - " . json_encode($result));

    if (isset($result->responseCode) && $result->responseCode === '2000000') {
        $transactionStatus = $result->latestTransactionStatus ?? 'UNKNOWN';
        
        switch ($transactionStatus) {
            case '00':
                return 'SUCCESS';
            case '03':
                return 'PENDING';
            case '04':
                return 'CANCELED';
            case '05':
                return 'REJECTED';
            case '08':
                return 'PENDING_SUSPECT';
            case '09':
                return 'FAILED';
            default:
                error_log("NICEPay Warning: Unknown transaction status '$transactionStatus' for order $order_id");
                return 'UNKNOWN';
        }
    } else {
        error_log("NICEPay Error: Failed to get status for order $order_id, transaction $txid. Response: " . print_r($result, true));
        return false;
    }
}
function refresh_nicepay_order_status($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) {
        error_log("NICEPay Error: Order not found for ID $order_id");
        return;
    }

    $txid = $order->get_meta('_nicepay_transaction_id');
    $beneficiary_account_no = $order->get_meta('_nicepay_beneficiary_account_no');

    if (!$txid || !$beneficiary_account_no) {
        error_log("NICEPay Error: Missing transaction ID or beneficiary account number for order $order_id");
        return;
    }

    $status = check_nicepay_status($order_id, $txid, $beneficiary_account_no);

    if ($status === false) {
        error_log("NICEPay Error: Failed to get status for order $order_id");
        return;
    }

    error_log("NICEPay: Refreshed status for order $order_id is $status");

    // Update order based on refreshed status
    switch ($status) {
        case 'SUCCESS':
            $order->update_status('completed', 'Payment completed via NICEPay (Status refreshed)');
            update_post_meta($order_id, '_nicepay_payout_status', 'completed');
            break;
        case 'PENDING':
        case 'PENDING_SUSPECT':
            $order->update_status('on-hold', 'Payment pending via NICEPay (Status refreshed)');
            update_post_meta($order_id, '_nicepay_payout_status', 'pending');
            break;
        case 'CANCELED':
            $order->update_status('cancelled', 'Payment canceled via NICEPay (Status refreshed)');
            update_post_meta($order_id, '_nicepay_payout_status', 'canceled');
            break;
        case 'REJECTED':
            $order->update_status('failed', 'Payment rejected via NICEPay (Status refreshed)');
            update_post_meta($order_id, '_nicepay_payout_status', 'rejected');
            break;
        case 'FAILED':
            $order->update_status('failed', 'Payment failed via NICEPay (Status refreshed)');
            update_post_meta($order_id, '_nicepay_payout_status', 'failed');
            break;
        default:
            $order->add_order_note("NICEPay status check returned unknown status: $status");
            update_post_meta($order_id, '_nicepay_payout_status', 'unknown');
            break;
    }

    $order->save();
    error_log("NICEPay: Order $order_id status refreshed. New WooCommerce status: " . $order->get_status());
}



function update_nicepay_payout_menu_status($order_id, $status) {
    update_post_meta($order_id, '_nicepay_payout_menu_status', $status);
}
function log_nicepay_webhook_url() {
    $webhook_url = home_url('nicepay-payout-snap/');
    error_log('NICEPay Webhook URL (on init): ' . $webhook_url);
}
add_action('init', 'log_nicepay_webhook_url', 99);
register_activation_hook(__FILE__, 'flush_rewrite_rules');
register_deactivation_hook(__FILE__, 'flush_rewrite_rules');


// function test_nicepay_order_query() {
//     global $wpdb;

//     $payment_method = 'nicepay_po_snap'; // Example payment method
//     $query = $wpdb->prepare(
//         "SELECT * FROM {$wpdb->prefix}postmeta WHERE meta_key = '_payment_method' AND meta_value = %s",
//         $payment_method
//     );

//     $results = $wpdb->get_results($query);

//     if (empty($results)) {
//         error_log('NICEPay: Tidak ada hasil ditemukan untuk metode pembayaran: ' . $payment_method);
//     } else {
//         error_log('NICEPay: ' . count($results) . ' hasil ditemukan untuk metode pembayaran: ' . $payment_method);
//     }
// }

// add_action('admin_init', 'test_nicepay_order_query');

