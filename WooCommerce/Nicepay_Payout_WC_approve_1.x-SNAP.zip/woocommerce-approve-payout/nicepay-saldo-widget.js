const NICEPaySaldoWidget = ({ initialSaldo }) => {
    const [saldo, setSaldo] = React.useState(initialSaldo);
    const [isLoading, setIsLoading] = React.useState(false);
    const [error, setError] = React.useState(null);

    React.useEffect(() => {
        const fetchSaldo = async () => {
            try {
                setIsLoading(true);
                const response = await fetch('/wp-json/nicepay/v1/saldo');
                if (!response.ok) {
                    throw new Error('Gagal mengambil saldo');
                }
                const data = await response.json();
                setSaldo(data.saldo);
            } catch (error) {
                console.error('Gagal mengambil saldo:', error);
                setError(error.message);
            } finally {
                setIsLoading(false);
            }
        };

        if (initialSaldo === 0) {
            fetchSaldo();
        }
    }, [initialSaldo]);

    return React.createElement(
        'div',
        { className: 'nicepay-saldo-widget' },
        React.createElement('h3', null, 'Saldo NICEPay'),
        isLoading
            ? React.createElement('p', null, 'Memuat saldo...')
            : React.createElement('p', { className: 'saldo' }, `Rp ${parseFloat(saldo).toLocaleString('id-ID')}`)
    );
};