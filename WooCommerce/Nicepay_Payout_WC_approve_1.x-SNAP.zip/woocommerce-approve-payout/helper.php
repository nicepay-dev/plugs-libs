<?php
// helpers.php

if (!function_exists('generateFormattedTimestamp')) {
    function generateFormattedTimestamp() {
        $date = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
        return $date->format('Y-m-d\TH:i:sP');
    }
}