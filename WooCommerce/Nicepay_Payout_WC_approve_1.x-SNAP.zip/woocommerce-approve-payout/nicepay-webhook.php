<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'handle_nicepay_webhook');
add_action('rest_api_init', function () {
    register_rest_route('nicepay/v1', '/webhook', array(
        'methods' => 'POST',
        'callback' => 'handle_nicepay_webhook',
        'permission_callback' => '__return_true'
    ));
});

function handle_nicepay_webhook() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['nicepay_webhook'])) {
        // Log the incoming webhook data
        $input = file_get_contents('php://input');
        error_log('NICEPay Webhook received: ' . $input);

        // Process the webhook data here
        // ...

        // Respond to NICEPay
        header('HTTP/1.1 200 OK');
        exit();
    }
}