<?php
/*
  Plugin Name: NICEPay Credit Card Payment Gateway
  Plugin URI: http://nicepay.co.id
  Description: NICEPay Credit Card Payment Gateway
  Version: 5.1
  Author: NICEPay <codeNinja>
  Author URI: http://nicepay.co.id
*/

if (!defined('ABSPATH')) {
  exit;
}

add_action('plugins_loaded', 'woocommerce_nicepay_init_cc', 0);

function woocommerce_nicepay_init_cc() {

  // Validation class payment gateway woocommerce
  if (!class_exists('WC_Payment_Gateway')) {
    return;
  }

  class WC_Gateway_NICEPay_CC extends WC_Payment_Gateway {

    var $callbackUrl;
    var $tSuccess = array();

    private $adminFee = 0; //Rupiah
    private $mdrFee = 0; //%

    public function nicepay_item_name($item_name) {
      if (strlen($item_name) > 127) {
        $item_name = substr($item_name, 0, 124) . '...';
      }
      return html_entity_decode($item_name, ENT_NOQUOTES, 'UTF-8');
    }

    public function __construct() {

      // plugin id
      $this->id = 'nicepay_cc';
      // Payment Gateway title
      $this->method_title = 'NICEPay Credit Card Payment Gateway';
      // true only in case of direct payment method, false in our case
      $this->has_fields = false;
      // payment gateway logo
      $this->icon = plugins_url('/nicepay.png', __FILE__);
      // redirect URL
      $this->redirect_url = str_replace('https:', 'http:', add_query_arg('wc-api', 'WC_Gateway_NICEPay_CC', home_url('/')));

      //Load settings
      $this->init_form_fields();
      $this->init_settings();

      // Define user set variables
      $this->enabled = $this->settings['enabled'];
      $this->title = $this->settings['title'];
      $this->description = $this->settings['description'];
      $this->iMid = $this->settings['iMid'];
      $this->mKey = $this->settings['mKey'];
      //---------------------------------------------//
      $this->reduceStock   = $this->get_option( 'reduceStock' );
      //---------------------------------------------//
      // $this->nicepayDebug = $this->settings['nicepayDebug'];

      // Actions
      $this->includes();
      // start sequence
      add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(&$this, 'process_admin_options'));
      // execute receipt_page function as woocommerce_receipt_nicepay_va
      add_action('woocommerce_receipt_nicepay_cc', array(&$this, 'receipt_page'));
      // execute add_description_payment_success function as woocommerce_thankyou
      add_action('woocommerce_thankyou', array($this, 'add_description_payment_success'), 1);
      // execute add_content function as woocommerce_email_after_order_table (credit card)
      // add_action('woocommerce_email_after_order_table', array($this, 'add_content' ));
      // execute notification_handler function as woocommerce_api_wc_gateway_nicepay_va
      add_filter( 'woocommerce_cart_totals_fee_html', array( $this, 'modify_fee_html_for_taxes' ), 10, 2 );
      add_action('woocommerce_api_wc_gateway_nicepay_cc', array($this, 'notification_handler'));
      add_action('woocommerce_email_order_details', array($this, 'np_add_payment_email_detail'),10, 4);
      add_action('woocommerce_email_subject_customer_processing_order', array($this, 'np_change_subject_payment_email_detail'),10, 2);

    }

    // function add_content() {}

    function init_form_fields() {
      $this->form_fields = array(
          'enabled' => array(
              'title' => __('Enable/Disable', 'woocommerce'),
              'label' => __('Enable NICEPay', 'woocommerce'),
              'type' => 'checkbox',
              'description' => '',
              'default' => 'no',
          ),
          'title' => array(
              'title' => __('Title', 'woocommerce'),
              'type' => 'text',
              'description' => __('', 'woocommerce'),
              'default' => __('Pembayaran NICEPay Credit Card', 'woocommerce'),
          ),
          'description' => array(
              'title' => __('Description', 'woocommerce'),
              'type' => 'textarea',
              'description' => __('', 'woocommerce'),
              'default' => 'Sistem pembayaran menggunakan NICEPay Credit Card.',
          ),
          'iMid' => array(
              'title' => __('Merchant ID', 'woocommerce'),
              'type' => 'text',
              'description' => __('<small>Isikan dengan Merchant ID dari NICEPay</small>.', 'woocommerce'),
              'default' => 'IONPAYTEST',
          ),
          'mKey' => array(
              'title' => __('Merchant Key', 'woocommerce'),
              'type' => 'text',
              'description' => __('<small>Isikan dengan Merchant Key dari NICEPay</small>.', 'woocommerce'),
              'default' => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
          ),
          'reduceStock' => array(
              'title' => __('Reduce stock', 'woocommerce'),
              'type' => 'checkbox',
              'description' => __('<small>Check to enable.</small>', 'woocommerce'),
              'default' => 'no',
          ),
        // 'nicepayDebug' => array(
        // 'title' => __('Debug', 'woocommerce'),
        // 'type' => 'select',
        // 'description' => __('<small>Pilih No jika sedang dalam proses integrasi atau pilih Yes</small>.', 'woocommerce'),
        // 'default' => 'no',
        // 'options' => array(
        // 'yes' => 'Yes',
        // 'no' => 'No',
        // ),
        // ),
      );
    }

    // what this function for?
    public function admin_options() {
      echo '<table class="form-table">';
      $this->generate_settings_html();
      // if($this->adminFee > 0){
      // echo "<tr><th>Fraud Detection Fee (IDR)</th><td>".$this->adminFee."</td></tr>";
      // }
      // if($this->mdrFee > 0){
      // echo "<tr><th>Credit Card Fee (%)</th><td>".$this->mdrFee."</td></tr>";
      // }
      echo '</table>';
    }

    function payment_fields() {
      if ($this->description) {
        echo wpautop(wptexturize($this->description));
        // if ($this->adminFee > 0 || $this->mdrFee > 0) {
        // echo '<br/>';
        // }

        // if($this->adminFee > 0){
        // echo wpautop(wptexturize('Exclude Fraud Detection Fee <b>Rp. '.$this->adminFee.'</b>'));
        // }

        // if($this->mdrFee > 0){
        // echo wpautop(wptexturize('Exclude Credit Card Fee <b>'.$this->mdrFee.'%</b>'));
        // }
      }
    }

    // function add_content() {
    // if($this->adminFee > 0){
    // echo 'Exclude Fraud Detection Fee <b>Rp. '.$this->adminFee.'</b><br/>';
    // }
    // if($this->mdrFee > 0){
    // echo 'Exclude Credit Card Fee <b>'.$this->mdrFee.'%</b>';
    // }
    // }

    // public function validate_fields() {
    // WC()->session->set('bankCd', $_POST["bankCd"]);
    // }

    function receipt_page($order) {
      echo $this->generate_nicepay_form($order);
    }

    function includes() {
      // Validation class payment gateway woocommerce
      if (!class_exists('NicepayLibCC')) {
        include_once "NicepayLibCC/NicepayLibCC.php";
      }
    }

    // function konversi($nilai, $currency) {
    // if ($currency == 'USD') {
    // return $nilai*(int)13500;
    // } else {
    // return $nilai*(int)1;
    // }
    // }

    public function generate_nicepay_form($order_id) {

      $order = new WC_Order($order_id);
      $fees = $order->get_fees();
      // $currency = $order->get_currency();

      //running debug
      // $nicepay_log["redirect"] = "callback";
      // $nicepay_log["referenceNo"] = $order_id;
      // $nicepay_log["isi"] = $_SERVER["REQUEST_URI"];
      // $this->sent_log(json_encode($nicepay_log));

      if (sizeof($order->get_items()) > 0) {
        foreach ($order->get_items() as $item_id => $item ) {
          if (!$item['qty']) {
            continue;
          }

          $item_name = $item->get_name();
          $item_cost_non_discount = $item->get_subtotal();

          $pro = new WC_Product($item["product_id"]);
          $image = wp_get_attachment_image_src( get_post_thumbnail_id( $pro->get_id() ), 'single-post-thumbnail' );
          $img_url = $image[0];

          $orderInfo[] = array(
              'img_url' => $img_url,
              'goods_name' => $this->nicepay_item_name($item_name),
              'goods_detail' => $this->nicepay_item_name($item_name),
              'goods_amt' => $item_cost_non_discount
          );

          if (count($orderInfo) < 0) {
            return false; // Abort - negative line
          }
        }

        /*$order_total_price = 0;
        foreach ($orderInfo as $item) {
          $order_total_price += $item['goods_amt'];
        }*/

        function clean($string) {
          $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

          return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
        }

        // Loop over $cart fees
        if(!empty($fees)) {
          foreach ( $fees as $fees_key => $fee ) {
            $name = $fee['name'];
            $total = $fee['total'];
            if($total != 0){
              $orderInfo[] = array(
                  'img_url' => "http://www.jamgora.com/media/avatar/noimage.png",
                  'goods_name' => clean($name),
                  'goods_detail' => clean($name)." for ".$order_id,
                  'goods_amt' => wc_float_to_string($total),
                  'goods_quantity' => "1",
                  'goods_url' => "https://".$_SERVER['SERVER_NAME']
              );
            }
          }
        }

        if($order->calculate_shipping() > 0){
          $orderInfo[] = array(
              'img_url' => plugins_url()."/nicepay_cc/icons/delivery.png",
              'goods_name' => "SHIPPING",
              'goods_detail' => $order->get_shipping_method(),
              'goods_amt' => $order->calculate_shipping()
          );
          //$order_total_price += $order->calculate_shipping();
        }

        if(WC()->cart->get_total_tax() > 0) {
          $orderInfo[] = array(
              'img_url' => plugins_url()."/nicepay_cc/icons/delivery.png",
              'goods_name' => "TAX",
              'goods_detail' =>  WC()->cart->get_total_tax(),
              'goods_amt' => round(WC()->cart->get_total_tax())
          );
        }

        $coupons = $order->get_coupon_codes();
        if(!empty($coupons)){
          foreach( $coupons as $coupon_code ) {
            $coupon = new WC_Coupon($coupon_code);
            $couponName = $coupon_code;

            $orderInfo[] = array(
                'img_url' => plugins_url()."/nicepay_cc/icons/coupon.png",
                'goods_name' => "COUPON",
                'goods_detail' => $couponName,
                'goods_amt' => "-".$coupon->get_amount()
            );
          }
        }

        /*if($woocommerce->cart->fee_total != 0){
          for($i=0; $i<sizeof($woocommerce->cart->fees); $i++){
            $fees = $woocommerce->cart->fees;
            $discounts = $fees[$i];

            $fileImg = "fees.png";
            if(preg_match("/^\-/", $discounts->amount)){
              $fileImg = "sale.png";
            }

            $orderInfo[] = array(
                'img_url' => plugins_url()."/nicepay_cc/icons/".$fileImg,
                'goods_name' => $discounts->name,
                'goods_detail' => "",
                'goods_amt' => $discounts->amount
            );
          }
        }*/

        // if($this->adminFee && ($this->adminFee != null || $this->adminFee > 0)){
        // $orderInfo[] = array(
        // 'img_url' => plugins_url()."/nicepay_cc/icons/money.png",
        // 'goods_name' => "Fraud Detection Fee",
        // 'goods_detail' => 1,
        // 'goods_amt' => $this->adminFee
        // );
        // }

        // if($this->mdrFee && ($this->mdrFee != null || $this->mdrFee > 0)){
        // $orderInfo[] = array(
        // 'img_url' => plugins_url()."/nicepay_cc/icons/money.png",
        // 'goods_name' => "Credit Card Fee",
        // 'goods_detail' => 1,
        // 'goods_amt' => ceil($order_total_price/((100 - $this->mdrFee)/100)) - $order_total_price
        // );
        // }

        $order_total = 0;
        foreach ($orderInfo as $item) {
          $order_total += $item['goods_amt'];
        }

        $cartData = array(
            'count' => count($orderInfo),
            'item' => $orderInfo
        );

      }

      //running debug
      // $nicepay_log["isi"] = $cartData;
      // $this->sent_log(json_encode($nicepay_log));

      //Order Total
      // if($currency == 'USD'){
      // $order_total = $this->get_order_total()*(int)13500;
      // }else{
      // $order_total = $this->get_order_total();
      // }

      // echo json_decode($order_id);return;
      // $payment_page = $order->get_checkout_payment_url();

      //Get current user
      $current_user = wp_get_current_user();

      // Billing
      $bFirstName = ( $current_user->ID == 0 ) ? $order->get_billing_first_name() : get_user_meta( $current_user->ID, 'billing_first_name', true );
      $billingFirstName = $this->checkingAddrRule("name", $bFirstName);
      $bLastName = ( $current_user->ID == 0 ) ? $order->get_billing_last_name() : get_user_meta( $current_user->ID, 'billing_last_name', true );
      $billingLastName = $this->checkingAddrRule("name", $bLastName);
      $billingNm = $billingFirstName." ".$billingLastName;
      $bPhone = ( $current_user->ID == 0 ) ? $order->get_billing_phone() : get_user_meta( $current_user->ID, "billing_phone", true );
      $billingPhone = $this->checkingAddrRule("phone", $bPhone);
      $bEmail = ( $current_user->ID == 0 ) ? $order->get_billing_email() : get_user_meta( $current_user->ID, "billing_email", true );
      $billingEmail = $this->checkingAddrRule("email", $bEmail);
      $bAddress1 = ( $current_user->ID == 0 ) ? $order->get_billing_address_1() : get_user_meta( $current_user->ID, "billing_address_1", true );
      $billingAddress1 = $this->checkingAddrRule("addr", $bAddress1);
      $bAddress2 = ( $current_user->ID == 0 ) ? $order->get_billing_address_2() : get_user_meta( $current_user->ID, "billing_address_2", true );
      $billingAddress2 = $this->checkingAddrRule("addr", $bAddress2);
      $billingAddress = $billingAddress1." ".$billingAddress2;
      $bCity = ( $current_user->ID == 0 ) ? $order->get_billing_city() : get_user_meta( $current_user->ID, "billing_city", true );
      $billingCity = $this->checkingAddrRule("city", $bCity);
      $bState = ( $current_user->ID == 0 ) ? $order->get_billing_state() : get_user_meta( $current_user->ID, "billing_state", true );
      $billingState = $this->checkingAddrRule("state", $bState);
      $bPostCd = ( $current_user->ID == 0 ) ? $order->get_billing_postcode() : get_user_meta( $current_user->ID, "billing_postcode", true );
      $billingPostCd = $this->checkingAddrRule("postCd", $bPostCd);
      $bCountry = ( $current_user->ID == 0 ) ? $order->get_billing_country() : get_user_meta( $current_user->ID, "billing_country", true );
      $billingCountry = $this->checkingAddrRule("country", $bCountry);

      // Delivery
      if ( $current_user->ID == 0 ) {
        $dFirstName = $order->get_billing_first_name();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_first_name", true) == "" ){
          $dFirstName = get_user_meta($current_user->ID, "billing_first_name", true);
        } else {
          $dFirstName = get_user_meta($current_user->ID, "delivery_first_name", true);
        }
      }
      $deliveryFirstName = $this->checkingAddrRule("name", $dFirstName);

      if ( $current_user->ID == 0 ) {
        $dLastName = $order->get_billing_last_name();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_last_name", true) == "" ){
          $dLastName = get_user_meta($current_user->ID, "billing_last_name", true);
        } else {
          $dLastName = get_user_meta($current_user->ID, "delivery_last_name", true);
        }
      }
      $deliveryLastName = $this->checkingAddrRule("name", $dLastName);

      $deliveryNm = $deliveryFirstName." ".$deliveryLastName;


      if ( $current_user->ID == 0 ) {
        $dPhone = $order->get_billing_phone();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_phone", true) == "" ){
          $dPhone = get_user_meta($current_user->ID, "billing_phone", true);
        } else {
          $dPhone = get_user_meta($current_user->ID, "delivery_phone", true);
        }
      }
      $deliveryPhone = $this->checkingAddrRule("phone", $dPhone);

      if ( $current_user->ID == 0 ) {
        $dEmail = $order->get_billing_email();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_email", true) == "" ){
          $dEmail = get_user_meta($current_user->ID, "billing_email", true);
        } else {
          $dEmail = get_user_meta($current_user->ID, "delivery_email", true);
        }
      }
      $deliveryEmail = $this->checkingAddrRule("email", $dEmail);

      if ( $current_user->ID == 0 ) {
        $dAddress1 = $order->get_billing_address_1();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_address_1", true) == "" ){
          $dAddress1 = get_user_meta($current_user->ID, "billing_address_1", true);
        } else {
          $dAddress1 = get_user_meta($current_user->ID, "delivery_address_1", true);
        }
      }
      $deliveryAddress1 = $this->checkingAddrRule("addr", $dAddress1);

      if ( $current_user->ID == 0 ) {
        $dAddress2 = $order->get_billing_address_2();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_address_2", true) == "" ){
          $dAddress2 = get_user_meta($current_user->ID, "billing_address_2", true);
        } else {
          $dAddress2 = get_user_meta($current_user->ID, "delivery_address_2", true);
        }
      }
      $deliveryAddress2 = $this->checkingAddrRule("addr", $dAddress2);

      $deliveryAddress = $deliveryAddress1." ".$deliveryAddress2;


      if ( $current_user->ID == 0 ) {
        $dCity = $order->get_billing_city();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_city", true) == "" ){
          $dCity = get_user_meta($current_user->ID, "billing_city", true);
        } else {
          $dCity = get_user_meta($current_user->ID, "delivery_city", true);
        }
      }
      $deliveryCity = $this->checkingAddrRule("city", $dCity);

      if ( $current_user->ID == 0 ) {
        $dState = $order->get_billing_state();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_state", true) == "" ){
          $dState = get_user_meta($current_user->ID, "billing_state", true);
        } else {
          $dState = get_user_meta($current_user->ID, "delivery_state", true);
        }
      }
      $deliveryState = $this->checkingAddrRule("state", $dState);

      if ( $current_user->ID == 0 ) {
        $dPostCd = $order->get_billing_postcode();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_postcode", true) == "" ){
          $dPostCd = get_user_meta($current_user->ID, "billing_postcode", true);
        } else {
          $dPostCd = get_user_meta($current_user->ID, "delivery_postcode", true);
        }
      }
      $deliveryPostCd = $this->checkingAddrRule("postCd", $dPostCd);

      if ( $current_user->ID == 0 ) {
        $dCountry = $order->get_billing_country();
      } else if ( $current_user->ID > 0 ) {
        if ( get_user_meta($current_user->ID, "delivery_country", true) == "" ){
          $dCountry = get_user_meta($current_user->ID, "billing_country", true);
        } else {
          $dCountry = get_user_meta($current_user->ID, "delivery_country", true);
        }
      }
      $deliveryCountry = $this->checkingAddrRule("country", $dCountry);

      // Prepare Parameters
      $nicepay = new NicepayLibCC();

      $dateNow = date('Ymd');

      // $myaccount_page_id = get_option('woocommerce_myaccount_page_id');
      // $myaccount_page_url = null;

      // if ($myaccount_page_id) {
      // $myaccount_page_url = get_permalink($myaccount_page_id);
      // }

      // if ( $current_user->ID > 0 ) {
      // $checkout_url = get_permalink( $myaccount_page_id )."view-order/".$order_id;
      // }else{
      // $checkout_url = $woocommerce->cart->get_checkout_url()."order-received/";
      // }

      $nicepay->set('mKey', $this->mKey);

      $nicepay->set('iMid', $this->iMid);
      $nicepay->set('amt', $order_total);
      $nicepay->set('instmntMon', '1');
      $nicepay->set('referenceNo', $order_id);
      $nicepay->set('goodsNm', 'Payment of invoice No '.$order_id);
      $nicepay->set('payMethod', '01');
      $nicepay->set('billingNm', $billingNm);
      $nicepay->set('billingPhone', $billingPhone);
      $nicepay->set('billingEmail', $billingEmail);
      $nicepay->set('billingAddr', $billingAddress);
      $nicepay->set('billingCity', $billingCity);
      $nicepay->set('billingState', $billingState);
      $nicepay->set('billingPostCd', $billingPostCd);
      $nicepay->set('billingCountry', $billingCountry);
      $nicepay->set('deliveryNm', $deliveryNm);
      $nicepay->set('deliveryPhone', $deliveryPhone);
      $nicepay->set('deliveryAddr', $deliveryAddress);
      $nicepay->set('deliveryCity', $deliveryCity);
      $nicepay->set('deliveryState', $deliveryState);
      $nicepay->set('deliveryPostCd', $deliveryPostCd);
      $nicepay->set('deliveryCountry', $deliveryCountry);
      // $nicepay->set('callBackUrl', $woocommerce->cart->get_checkout_url().'order-received/');
      $nicepay->set('callBackUrl', $order->get_checkout_order_received_url());
      $nicepay->set('dbProcessUrl', WC()->api_request_url('WC_Gateway_NICEPay_CC'));
      $nicepay->set('vat', '0');
      $nicepay->set('fee', '0');
      $nicepay->set('notaxAmt', '0');
      $nicepay->set('description', 'Payment of invoice No '.$order_id);
      $nicepay->set('merchantToken', $nicepay->merchantToken());
      $nicepay->set('reqDt', date('Ymd'));
      $nicepay->set('reqTm', date('His'));
      // $nicepay->set('reqDomain', '');
      // $nicepay->set('reqServerIP', '');
      // $nicepay->set('reqClientVer', '');
      $nicepay->set('userIP', $nicepay->getUserIP());
      // $nicepay->set('userSessionID', '');

      $nicepay->set('userAgent', $_SERVER['HTTP_USER_AGENT']);
      // $nicepay->set('userLanguage', '');
      $nicepay->set('instmntType', '2');
      // $nicepay->set('worker', '');
      $nicepay->set('cartData', json_encode($cartData));
      // $nicepay->set('paymentExpDt', '');
      // $nicepay->set('paymentExpTm', '');
      $nicepay->set('recurrOpt', '2');
      $nicepay->set('timeStamp', date('YmdHis'));
      // $nicepay->set('version', '');

      unset($nicepay->requestData['mKey']);

      //running debug
      // $nicepay_log["isi"] = $nicepay;
      // $this->sent_log(json_encode($nicepay_log));

      // echo "<pre>";
      // print_r($order_total);
      // echo "</pre>";
      // exit();

      // Send Data
      $response = $nicepay->requestCC();

      //running debug
      // $nicepay_log["isi"] = $response;
      // $this->sent_log(json_encode($nicepay_log));

      // Response from NICEPAY
      if (isset($response->data->resultCd) && $response->data->resultCd == "0000") {
        $order->add_order_note(__('Menunggu pembayaran melalui NICEPay Credit Card Payment Gateway dengan id transaksi '.$response->tXid, 'woocommerce'));
        //REDUCE WC Stock
        if ( property_exists($this,'reduceStock') && $this->reduceStock == 'yes' ) {
          wc_reduce_stock_levels($order);
        }

        header("Location: ".$response->data->requestURL."?tXid=".$response->tXid);
        // please save tXid in your database
        // echo "<pre>";
        // echo "tXid              : $response->tXid\n";
        // echo "API Type          : $response->apiType\n";
        // echo "Request Date      : $response->requestDate\n";
        // echo "Response Date     : $response->requestDate\n";
        // echo "</pre>";
      } elseif(isset($response->data->resultCd)) {
        // API data not correct or error happened in bank system, you can redirect back to checkout page or echo error message.
        // In this sample, we echo error message
        // header("Location: "."http://example.com/checkout.php");
        echo "<pre>";
        echo "result code: ".$response->data->resultCd."\n";
        echo "result message: ".$response->data->resultMsg."\n";
        // echo "requestUrl: ".$response->data->requestURL."\n";
        echo "</pre>";
      } else {
        // Timeout, you can redirect back to checkout page or echo error message.
        // In this sample, we echo error message
        // header("Location: "."http://example.com/checkout.php");
        echo "<pre>Connection Timeout. Please Try again.</pre>";
      }
    }

    public function add_description_payment_success($orderdata) {
      $order = new WC_Order($orderdata);
      if ($order->get_payment_method() == 'nicepay_cc') {

        echo '<h2 id="h2thanks">NICEPAY Secure Payment</h2>';
        echo '<table border="0" cellpadding="10">';
        // echo '<tr><td><strong>Result Code</strong></td><td>'.$_GET['resultCd'].'</td></tr>';
        // echo '<tr><td><strong>Result Message</strong></td><td>'.$_GET['resultMsg'].'</td></tr>';
        // echo '<tr><td><strong>Authorization Number</strong></td><td>'.$_GET['authNo'].'</td></tr>';
        echo '<tr><td><strong>Transaction ID</strong></td><td>'.$_GET['tXid'].'</td></tr>';
        echo '<tr><td><strong>Merchant Order No</strong></td><td>'.$_GET['referenceNo'].'</td></tr>';
        echo '<tr><td><strong>Transaction Date</strong></td><td>'.date("Y/m/d", strtotime($_GET['transDt'])).'</td></tr>';
        echo '<tr><td><strong>Transaction Time</strong></td><td>'.date("H:i:s", strtotime($_GET['transTm'])).'</td></tr>';
        echo '<tr><td><strong>Transaction Amount</strong></td><td>'.'Rp'.number_format($_GET['amount'],2,",",".").'</td></tr>';
        // echo '<tr><td><strong>Token That Using Recurring payment</strong></td><td>'.$_GET['recurringToken'].'</td></tr>';
        // echo '<tr><td><strong>Token That Using Capture process</strong></td><td>'.$_GET['preauthToken'].'</td></tr>';
        echo '<tr><td><strong>Transaction Description</strong></td><td>'.$_GET['description'].'</td></tr>';
        // echo '<tr><td><strong>Card Number</strong></td><td>'.$_GET['cardNo'].'</td></tr>';
        // echo '<tr><td><strong>Acquire Bank Code</strong></td><td>'.$_GET['acquBankCd'].'</td></tr>';
        // echo '<tr><td><strong>Issue Bank Code</strong></td><td>'.$_GET['issuBankCd'].'</td></tr>';
        // echo '<tr><td><strong>Vat</strong></td><td>'.$_GET['vat'].'</td></tr>';
        // echo '<tr><td><strong>Service Fee</strong></td><td>'.$_GET['fee'].'</td></tr>';
        // echo '<tr><td><strong>Tax Free Amount</strong></td><td>'.$_GET['notaxAmt'].'</td></tr>';
        echo '</table>';
        // echo '<p>Pembayaran melalui Bank '.WC()->session->get('bankName').' dapat dilakukan dengan mengikuti petunjuk berikut :</p>';
        // echo  $this->petunjuk_payment_va(WC()->session->get('bankCd'));
      }
    }

    //Add details to Processing Order email
    public function np_add_payment_email_detail($orderdata, $sent_to_admin, $plain_text, $email){
      $order = new WC_Order($orderdata);
      if ($order->get_payment_method() == 'nicepay_cc') {
        if ( $email->id == 'customer_processing_order' ) {
          echo '<h2 class="email-upsell-title">We Have Received Your Payment!</h2>';
        }
      }
    }

    //Change Email Subject for Processing Email
    public function np_change_subject_payment_email_detail($formated_subject, $orderdata){
      $order = new WC_Order($orderdata);
      if ($order->get_payment_method() == 'nicepay_cc') {
        $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
        $subject = sprintf( 'Hi %s, Thank you for your payment on %s', $order->billing_first_name, $blogname );
        return $subject;
      }
    }

    public function modify_fee_html_for_taxes( $cart_fee_html, $fees ) {

      if ( 'incl' === get_option( 'woocommerce_tax_display_cart' ) && isset( $fees->tax ) && $fees->tax > 0 && in_array( $fees->name, $this->fees_added, true ) ) {
        $cart_fee_html .= '<small class="includes_tax">' . sprintf( __( '(includes %s Tax)', 'checkout-fees-for-woocommerce' ), wc_price( $fees->tax ) ) . '</small>'; // phpcs:ignore
      }
      return $cart_fee_html;
    }

    // what this function for?
    function process_payment($order_id) {
      global $woocommerce;
      $order = new WC_Order($order_id);
      return array(
          'result' => 'success',
          'redirect' => $order->get_checkout_payment_url(true),
      );
    }

    function notification_handler() {

      $nicepay = new NicepayLibCC();

      // Listen for parameters passed
      $pushParameters = array(
          'tXid',
          'referenceNo',
          'payMethod',
          'amt',
          'transDt',
          'transTm',
          'currency',
          'goodsNm',
          'billingNm',
          'matchCl',
          'status',
          'merchantToken',
          'authNo',
          'issuBankCd',
          'acquBankCd',
          'cardNo',
          'instmntMon',
          'instmntType',
          'preauthToken',
          'recurringToken',
          'ccTransType',
          'cardExpYymm',
          'issuBankNm',
          'acquBankNm',
          'vat',
          'fee',
          'notaxAmt',
      );

      $nicepay->extractNotification($pushParameters);

      //running debug
      // $nicepay_log["redirect"] = "dbproccess";
      // $nicepay_log["referenceNo"] = $referenceNo;
      // $nicepay_log["isi"] = $_SERVER["REQUEST_URI"];
      // $this->sent_log(json_encode($nicepay_log));

      $tXid = $nicepay->getNotification('tXid');
      $referenceNo = $nicepay->getNotification('referenceNo');
      $payMethod = $nicepay->getNotification('payMethod');
      $amt = $nicepay->getNotification('amt');
      $transDt = $nicepay->getNotification('transDt');
      $transTm = $nicepay->getNotification('transTm');
      $currency = $nicepay->getNotification('currency');
      $goodsNm = $nicepay->getNotification('goodsNm');
      $billingNm = $nicepay->getNotification('billingNm');
      $matchCl = $nicepay->getNotification('matchCl');
      $status = $nicepay->getNotification('status');
      $merchantToken = $nicepay->getNotification('merchantToken');

      $authNo = $nicepay->getNotification('authNo');
      $issuBankCd = $nicepay->getNotification('issuBankCd');
      $acquBankCd = $nicepay->getNotification('acquBankCd');
      $cardNo = $nicepay->getNotification('cardNo');
      $instmntMon = $nicepay->getNotification('instmntMon');
      $instmntType = $nicepay->getNotification('instmntType');
      $preauthToken = $nicepay->getNotification('preauthToken');
      $recurringToken = $nicepay->getNotification('recurringToken');
      $ccTransType = $nicepay->getNotification('ccTransType');
      $cardExpYymm = $nicepay->getNotification('cardExpYymm');
      $issuBankNm = $nicepay->getNotification('issuBankNm');
      $acquBankNm = $nicepay->getNotification('acquBankNm');
      $vat = $nicepay->getNotification('vat');
      $fee = $nicepay->getNotification('fee');
      $notaxAmt = $nicepay->getNotification('notaxAmt');

      // $timeStamp = $transDt.$transTm;
      $iMid = $this->iMid;
      $mKey = $this->mKey;
      $pushedToken = $nicepay->getNotification('merchantToken');

      // $nicepay->set('timeStamp', $timeStamp);
      $nicepay->set('iMid', $iMid);
      $nicepay->set('tXid', $tXid);
      $nicepay->set('referenceNo', $referenceNo);
      $nicepay->set('amt', $amt);
      $nicepay->set('mKey', $mKey);

      $merchantToken = $nicepay->merchantTokenC(); // iMid + tXid + amt + mKey
      $nicepay->set('merchantToken', $merchantToken);

      //running debug
      // $nicepay_log["isi"] = $pushedToken ." == ". $merchantToken;
      // $this->sent_log(json_encode($nicepay_log));

      // <RESQUEST to NICEPAY>
      $paymentStatus = $nicepay->checkPaymentStatus();

      //running debug
      // $nicepay_log["isi"] = $paymentStatus;
      // $this->sent_log(json_encode($nicepay_log));

      if($pushedToken == $merchantToken) {
        $order = new WC_Order((int)$referenceNo);
        if (isset($paymentStatus->status) && $paymentStatus->status == '0') {
          $order->add_order_note(__('Pembayaran telah dilakukan melalui NICEPay dengan id transaksi '.$tXid, 'woocommerce'));
          $order->payment_complete();
        } else {
          $order->add_order_note(__('Pembayaran gagal! '.$referenceNo, 'woocommerce'));
          $order->update_status('Failed');
        }
      }
    }

    public function addrRule() {
      $addrRule = array(
          "name" => (object) array(
              "type" => "string",
              "length" => 30,
              "defaultValue" => "John Doe",
          ),
          "email" => (object) array(
              "type" => "string",
              "length" => 40,
              "defaultValue" => "customer@merchant.com",
          ),
          "phone" => (object) array(
              "type" => "string",
              "length" => 15,
              "defaultValue" => "08123456789",
          ),
          "addr" => (object) array(
              "type" => "string",
              "length" => 100,
              "defaultValue" => "Jl. Casablanca Raya Kav 88",
          ),
          "city" => (object) array(
              "type" => "string",
              "length" => 100,
              "defaultValue" => "Jakarta",
          ),
          "state" => (object) array(
              "type" => "string",
              "length" => 50,
              "defaultValue" => "Jakarta Selatan",
          ),
          "postCd" => (object) array(
              "type" => "string",
              "length" => 10,
              "defaultValue" => "12345",
          ),
          "country" => (object) array(
              "type" => "string",
              "length" => 10,
              "defaultValue" => "Indonesia",
          ),
      );

      return $addrRule;
    }

    public function checkingAddrRule($var, $val) {
      $value = null;

      $rule = $this->addrRule();
      $type = $rule[$var]->type;
      $length =(int)$rule[$var]->length;

      $defaultValue = $rule[$var]->defaultValue;
      if ($val == null || $val == "" || "null" == $val) {
        $val = $defaultValue;
      }

      switch ($type) {
        case "string" :
          $valLength = strlen($val);
          if ($valLength > $length) {
            $val = substr($val, 0, $length);
          }

          $value = (string)$val;
          break;

        case "integer" :
          if (gettype($val) != "string" || gettype($val) != "String") {
            $val = (string)$val;
          }

          $valLength = strlen($val);
          if ($valLength > $length) {
            $val = substr($val, 0, $length);
          }

          $value = (int)$val;
          break;

        default:
          $value = (string)$val;
          break;
      }

      return $value;
    }

    // public function sent_log($data){
    // $debugMode = $this->nicepayDebug;
    // if ($debugMode == 'yes') {
    // $ch = curl_init();
    //set the url, number of POST vars, POST data

    // curl_setopt($ch,CURLOPT_URL, "http://checking-bug.hol.es/proc.php");
    // curl_setopt($ch,CURLOPT_POST, 1);
    // curl_setopt($ch,CURLOPT_POSTFIELDS, "log=".$data."++--++debug==".$debugMode);

    //execute post
    // $result = curl_exec($ch);

    //close connection
    // curl_close($ch);
    // }
    // } 

  }

  function add_nicepay_cc_gateway($methods) {
    $methods[] = 'WC_Gateway_NICEPay_CC';
    return $methods;
  }
  add_filter('woocommerce_payment_gateways', 'add_nicepay_cc_gateway');

}
?>
