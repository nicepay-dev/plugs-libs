const route = require("express").Router();
const {
  registVitrualAccount,
} = require("../controllers/virtualAccountController");

route.post("/bi-snap/regist", registVitrualAccount);

module.exports = route;
