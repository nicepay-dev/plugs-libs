const route = require("express").Router();
const {
  registEWallet,
  inquiryEWallet,
  refundEWallet,
} = require("../controllers/eWalletController.js");

route.post("/bi-snap/regist", registEWallet);
route.post("/bi-snap/inquiry", inquiryEWallet);
route.post("/bi-snap/refund", refundEWallet);

module.exports = route;
