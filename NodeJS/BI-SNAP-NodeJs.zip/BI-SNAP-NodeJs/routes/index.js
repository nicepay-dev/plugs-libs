const route = require("express").Router();
const vacctRoute = require("./vacctRoute");
const ewlletRoute = require("./ewalletRoute");
const payoutRoute = require("./payoutRoute");
const qrisRoute = require("./qrisRoute");

route.use("/vacct", vacctRoute);
route.use("/payout", payoutRoute);
route.use("/ewallet", ewlletRoute);
route.use("/qris", qrisRoute);

module.exports = route;
