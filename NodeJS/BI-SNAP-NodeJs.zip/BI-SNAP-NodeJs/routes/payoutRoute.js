const route = require("express").Router();
const {
  registPayout,
  approvePayout,
  inquiryPayout,
  cancelPayout,
  rejectPayout,
  balanceInquiryPayout,
} = require("../controllers/payoutController.js");

route.post("/bi-snap/regist", registPayout);
route.post("/bi-snap/approve", approvePayout);
route.post("/bi-snap/inquiry", inquiryPayout);
route.post("/bi-snap/cancel", cancelPayout);
route.post("/bi-snap/reject", rejectPayout);
route.post("/bi-snap/balance-inquiry", balanceInquiryPayout);

module.exports = route;
