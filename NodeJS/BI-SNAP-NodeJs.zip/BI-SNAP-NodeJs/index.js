require("dotenv").config();
const express = require("express");
const app = express();
const port = process.env.APP_PORT;
const routes = require("./routes");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/api", routes);
app.set("trust proxy", true);

app.use((error, req, res, next) => {
  res.status(500).json(error.response.data);
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
