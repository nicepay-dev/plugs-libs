const { DateTime } = require("luxon");
const crypto = require("crypto");
const request = require("../lib/request");
const urlRegist = `${process.env.DEV_ENV}/nicepay/api/v1.0/qr/qr-mpm-generate`;
const urlInquiry = `${process.env.DEV_ENV}/nicepay/api/v1.0/qr/qr-mpm-query`;
const urlRefund = `${process.env.DEV_ENV}/nicepay/api/v1.0/qr/qr-mpm-refund`;
const X_PARTNER_ID = "IONPAYTEST";
const CHANNEL_ID = "IONPAYTEST01";
//You will get client secret by asking team Nicepay
const clientSecret = process.env.clientSecret;
const requestAccessToken = require("../lib/accessToken");
const { encodePayload, registSignature } = require("../lib/signature");

const registQris = async (req, res, next) => {
  try {
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      partnerReferenceNo: "order" + new Date().getTime(),
      amount: {
        value: "10000.00",
        currency: "IDR",
      },
      FeeAmount: {
        value: "10000.00",
        currency: "IDR",
      },
      merchantId: X_PARTNER_ID,
      storeId: "NICEPAY",
      additionalInfo: {
        mitraCd: "QSHP",
        goodsNm: "Test",
        billingNm: "Buyer Name",
        billingPhone: "02112345678",
        billingEmail: "email@merchant.com",
        billingCity: "Jakarta",
        billingState: "DKI Jakarta",
        billingPostCd: "12345",
        billingCountry: "Indonesia",
        dbProcessUrl: "https://nicepay.co.id/",
        callBackUrl: "https://www.nicepay.co.id",
        cartData:
          '{"count":"2","item":[{"img_url":"http://img.aaa.com/ima1.jpg","goods_name":"Item 1 Name","goods_detail":"Item 1 Detail","goods_amt":"0.00","goods_quantity":"1"},{"img_url":"http://img.aaa.com/ima2.jpg","goods_name":"Item 2 Name","goods_detail":"Item 2 Detail","goods_amt":"10000.00","goods_quantity":"1"}]}',
      },
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/qr/qr-mpm-generate:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };
    const response = await request(headers, requestBody, urlRegist);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const inquiryQris = async (req, res, next) => {
  try {
    const { originalReferenceNo, originalPartnerReferenceNo } = req.body;
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      originalReferenceNo,
      originalPartnerReferenceNo,
      merchantId: X_PARTNER_ID,
      externalStoreId: "NICEPAY",
      serviceCode: "51",
      additionalInfo: {},
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/qr/qr-mpm-query:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };
    const response = await request(headers, requestBody, urlInquiry);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const refundQris = async (req, res, next) => {
  try {
    const { originalReferenceNo, originalPartnerReferenceNo } = req.body;
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      originalReferenceNo,
      originalPartnerReferenceNo,
      partnerRefundNo: originalPartnerReferenceNo,
      merchantId: X_PARTNER_ID,
      externalStoreId: "NICEPAY",
      refundAmount: {
        value: "10000.00",
        currency: "IDR",
      },
      reason: "Refund Trans",
      additionalInfo: {
        cancelType: "1",
      },
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/qr/qr-mpm-refund:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };
    const response = await request(headers, requestBody, urlRefund);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

module.exports = { registQris, inquiryQris, refundQris };
