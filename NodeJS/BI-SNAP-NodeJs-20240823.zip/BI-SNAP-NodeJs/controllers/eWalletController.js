const { DateTime } = require("luxon");
const request = require("../lib/request");
const crypto = require("crypto");

const urlRegist = `${process.env.DEV_ENV}/nicepay/api/v1.0/debit/payment-host-to-host`;
const urlInquiry = `${process.env.DEV_ENV}/nicepay/api/v1.0/debit/status`;
const urlRefund = `${process.env.DEV_ENV}/nicepay/api/v1.0/debit/refund`;

const X_PARTNER_ID = "IONPAYTEST";
const CHANNEL_ID = "IONPAYTEST01";
//You will get client secret by asking team Nicepay
const clientSecret = process.env.clientSecret;
const requestAccessToken = require("../lib/accessToken");
const { encodePayload, registSignature } = require("../lib/signature");

const registEWallet = async (req, res, next) => {
  try {
    const { mitraCd } = req.body;
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      partnerReferenceNo: "order" + new Date().getTime(),
      merchantId: X_PARTNER_ID,
      amount: {
        value: "10000.00",
        currency: "IDR",
      },
      urlParam: [
        {
          url: "https://test1.bi.go.id/v1/test",
          type: "PAY_NOTIFY",
          isDeeplink: "Y",
        },
        {
          url: "https://test2.bi.go.id/v1/test",
          type: "PAY_RETURN",
          isDeeplink: "Y",
        },
      ],
      externalStoreId: "",
      //   validUpTo: "2020-12-23T07:44:11+07:00",
      pointOfInitiation: "Mobile App",
      additionalInfo: {
        mitraCd,
        goodsNm: "Test",
        billingNm: "Buyer Name",
        billingPhone: "0851141347531",
        dbProcessUrl: "https://nicepay.co.id/",
        callBackUrl: "http://www.merchant.com/notification",
        cartData:
          '{"count":"2","item":[{"img_url":"http://img.aaa.com/ima1.jpg","goods_name":"Item 1 Name","goods_detail":"Item 1 Detail","goods_amt":"0.00","goods_quantity":"1"},{"img_url":"http://img.aaa.com/ima2.jpg","goods_name":"Item 2 Name","goods_detail":"Item 2 Detail","goods_amt":"10000.00","goods_quantity":"1"}]}',
      },
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/debit/payment-host-to-host:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;

    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };
    const response = await request(headers, requestBody, urlRegist);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const inquiryEWallet = async (req, res, next) => {
  try {
    const { originalPartnerReferenceNo, originalReferenceNo } = req.body;
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      merchantId: X_PARTNER_ID,
      amount: {
        value: "10000.00",
        currency: "IDR",
      },
      subMerchantId: "",
      originalPartnerReferenceNo,
      originalReferenceNo,
      serviceCode: "54",
      externalStoreId: "",
      additionalInfo: {},
    };
    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/debit/status:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };
    const response = await request(headers, requestBody, urlInquiry);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const refundEWallet = async (req, res, next) => {
  try {
    const { originalReferenceNo, originalPartnerReferenceNo } = req.body;
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      merchantId: X_PARTNER_ID,
      subMerchantId: "",
      originalPartnerReferenceNo,
      originalReferenceNo,
      partnerRefundNo: "order" + Date.now(),
      refundAmount: {
        value: "10000.00",
        currency: "IDR",
      },
      externalStoreId: "",
      reason: "Customer complain",
      additionalInfo: {
        refundType: "1",
      },
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/debit/refund:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;

    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };
    const response = await request(headers, requestBody, urlRefund);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

module.exports = { registEWallet, inquiryEWallet, refundEWallet };
