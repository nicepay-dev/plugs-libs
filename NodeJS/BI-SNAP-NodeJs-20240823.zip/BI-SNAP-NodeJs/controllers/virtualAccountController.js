const request = require("../lib/request");
const url = `${process.env.DEV_ENV}/nicepay/api/v1.0/transfer-va/create-va`;
const ulrDeleteVA = `${process.env.DEV_ENV}/nicepay/api/v1.0/transfer-va/delete-va`;
const X_PARTNER_ID = "NORMALTEST";
const CHANNEL_ID = "NORMALTEST";
//You will get client secret by asking team Nicepay
const clientSecret = process.env.clientSecret;
const requestAccessToken = require("../lib/accessToken");
const { encodePayload, registSignature } = require("../lib/signature");
const { generateXExternalId, generateXTimestamp } = require("../util/utils");

const registVitrualAccount = async (req, res, next) => {
  try {
    const { bankCd } = req.body;
    const X_EXTERNAL_ID = generateXExternalId();
    const X_TIMESTAMP = generateXTimestamp();

    let requestBody = {
      partnerServiceId: "",
      customerNo: "",
      virtualAccountNo: "",
      virtualAccountName: "NodeJS Test",
      trxId: "order" + new Date().getTime(),
      totalAmount: {
        value: "10000.00",
        currency: "IDR",
      },
      additionalInfo: {
        bankCd,
        goodsNm: "Test",
        dbProcessUrl: "https://nicepay.co.id/",
      },
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/transfer-va/create-va:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };

    const response = await request(headers, requestBody, url);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};


const deleteVirtualAccount = async (req, res, next) => {
  try {
    
    const { trxId, bankCd, amount, virtualAccountNo, tXidVA } = req.body;
    const X_EXTERNAL_ID = generateXExternalId();
    const X_TIMESTAMP = generateXTimestamp();

    let requestBody = {
      partnerServiceId: "",
      customerNo: "",
      virtualAccountNo,
      trxId,
      additionalInfo: {
        tXidVA,
        bankCd,
        goodsNm: "Test",
        dbProcessUrl: "https://nicepay.co.id/",
        totalAmount: {
          value: amount,
          currency: "IDR",
        },
      },
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `DELETE:/api/v1.0/transfer-va/delete-va:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);


    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };

  
    const response = await request(headers, requestBody, ulrDeleteVA, "delete");

    res.status(response.status).json(response.data);

  } catch (error) {
    next(error);
  }
};

module.exports = { registVitrualAccount, deleteVirtualAccount };
