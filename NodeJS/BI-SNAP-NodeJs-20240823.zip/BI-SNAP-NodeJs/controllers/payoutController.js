const { DateTime } = require("luxon");
const crypto = require("crypto");
const request = require("../lib/request");

const urlRegist = `${process.env.DEV_ENV}/nicepay/api/v1.0/transfer/registration`;
const urlApprove = `${process.env.DEV_ENV}/nicepay/api/v1.0/transfer/approve`;
const urlInquiry = `${process.env.DEV_ENV}/nicepay/api/v1.0/transfer/inquiry`;
const urlCancel = `${process.env.DEV_ENV}/nicepay/api/v1.0/transfer/cancel`;
const urlReject = `${process.env.DEV_ENV}/nicepay/api/v1.0/transfer/reject`;
const urlBalanceInquiry = `${process.env.DEV_ENV}/nicepay/api/v1.0/transfer/balance-inquiry`;

const X_PARTNER_ID = "IONPAYTEST";
const CHANNEL_ID = "IONPAYTEST01";
//You will get client secret by asking team Nicepay
const clientSecret = process.env.clientSecret;
const requestAccessToken = require("../lib/accessToken");
const { encodePayload, registSignature } = require("../lib/signature");

const registPayout = async (req, res, next) => {
  try {
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");
    const expired = date.plus({ days: 1 });
    const reservedDt = expired.toFormat("yyyyMMdd");
    const reservedTm = expired.toFormat("HHmmss");

    let requestBody = {
      merchantId: X_PARTNER_ID,
      beneficiaryAccountNo: "5345000060",
      beneficiaryName: "IONPAY NETWORKS",
      beneficiaryPhone: "08123456789",
      beneficiaryCustomerResidence: "1",
      beneficiaryCustomerType: "1",
      beneficiaryPostalCode: "123456",
      payoutMethod: "0",
      beneficiaryBankCode: "CENA",
      amount: {
        value: "12345678.00",
        currency: "IDR",
      },
      partnerReferenceNo: "order" + new Date().getTime(),
      description: "This is test Request",
      deliveryName: "Ciki",
      deliveryId: "1234567890234512",
      reservedDt,
      reservedTm,
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/transfer/registration:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };

    const response = await request(headers, requestBody, urlRegist);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const approvePayout = async (req, res, next) => {
  try {
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const { originalReferenceNo, originalPartnerReferenceNo } = req.body;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      merchantId: X_PARTNER_ID,
      originalReferenceNo,
      originalPartnerReferenceNo,
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/transfer/approve:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };

    const response = await request(headers, requestBody, urlApprove);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const inquiryPayout = async (req, res, next) => {
  try {
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const { originalPartnerReferenceNo, originalReferenceNo } = req.body;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      merchantId: X_PARTNER_ID,
      originalPartnerReferenceNo,
      originalReferenceNo,
      beneficiaryAccountNo: "5345000060",
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/transfer/inquiry:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };

    const response = await request(headers, requestBody, urlInquiry);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const cancelPayout = async (req, res, next) => {
  try {
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const { originalPartnerReferenceNo, originalReferenceNo } = req.body;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      merchantId: X_PARTNER_ID,
      originalPartnerReferenceNo,
      originalReferenceNo,
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/transfer/cancel:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };

    const response = await request(headers, requestBody, urlCancel);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const rejectPayout = async (req, res, next) => {
  try {
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const { originalPartnerReferenceNo, originalReferenceNo } = req.body;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      merchantId: X_PARTNER_ID,
      originalPartnerReferenceNo,
      originalReferenceNo,
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/transfer/reject:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };

    const response = await request(headers, requestBody, urlReject);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

const balanceInquiryPayout = async (req, res, next) => {
  try {
    const X_EXTERNAL_ID = `${crypto
      .randomBytes(4)
      .readUInt32BE(0)}${Date.now()}`;
    const date = DateTime.local();
    const X_TIMESTAMP = date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");

    let requestBody = {
      merchantId: X_PARTNER_ID,
      additionalInfo: {
        msId: "123",
      },
    };

    const hexPayload = encodePayload(requestBody);
    const accessToken = await requestAccessToken();
    if (!accessToken) {
      throw new Error("access token is null");
    }
    const stringToSign = `POST:/api/v1.0/transfer/balance-inquiry:${accessToken}:${hexPayload}:${X_TIMESTAMP}`;
    const signature = registSignature(stringToSign, clientSecret);

    const headers = {
      "Content-type": "Application/JSON",
      Authorization: `Bearer ${accessToken}`,
      "X-TIMESTAMP": X_TIMESTAMP,
      "X-PARTNER-ID": X_PARTNER_ID,
      "X-SIGNATURE": signature,
      "X-EXTERNAL-ID": X_EXTERNAL_ID,
      "CHANNEL-ID": CHANNEL_ID,
    };

    const response = await request(headers, requestBody, urlBalanceInquiry);

    res.status(200).json(response.data);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  registPayout,
  approvePayout,
  inquiryPayout,
  cancelPayout,
  rejectPayout,
  balanceInquiryPayout,
};
