const route = require("express").Router();
const {
  registQris,
  inquiryQris,
  refundQris,
} = require("../controllers/qrisController");

route.post("/bi-snap/regist", registQris);
route.post("/bi-snap/inquiry", inquiryQris);
route.post("/bi-snap/refund", refundQris);

module.exports = route;
