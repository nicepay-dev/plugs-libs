const route = require("express").Router();
const {
  registVitrualAccount,
  deleteVirtualAccount
} = require("../controllers/virtualAccountController");

route.post("/bi-snap/regist", registVitrualAccount);
route.delete("/bi-snap/delete", deleteVirtualAccount);

module.exports = route;
