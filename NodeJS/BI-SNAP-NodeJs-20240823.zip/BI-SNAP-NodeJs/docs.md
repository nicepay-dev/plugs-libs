# API Documentation

## Endpoints :

List of available endpoints:

- `POST /api/va/bi-snap/regist`
- `DELETE /api/vacct/bi-snap/delete`
- `POST /api/ewallet/bi-snap/regist`
- `POST /api/ewallet/bi-snap/inquiry`
- `POST /api/ewallet/bi-snap/refund`
- `POST /api/qris/bi-snap/regist`
- `POST /api/qris/bi-snap/inquiry`
- `POST /api/qris/bi-snap/refund`
- `POST /api/payout/bi-snap/regist`
- `POST /api/payout/bi-snap/approve`
- `POST /api/payout/bi-snap/inquiry`
- `POST /api/payout/bi-snap/cancel`
- `POST /api/payout/bi-snap/reject`
- `POST /api/payout/bi-snap/balance-inquiry`

&nbsp;

## 1. POST /api/va/bi-snap/regist

Request:

- body:

```json
{
  "bankCd": "CENA"
}
```

_Response (200 - OK)_

```json
{
  "responseCode": "2002700",
  "responseMessage": "Successful",
  "virtualAccountData": {
    "partnerServiceId": "",
    "customerNo": "",
    "virtualAccountNo": "111111101032458146",
    "virtualAccountName": "NodeJS Test",
    "trxId": "order1675395166380",
    "totalAmount": {
      "value": "10000.00",
      "currency": "IDR"
    },
    "additionalInfo": {
      "bankCd": "CENA",
      "tXidVA": "IONPAYTEST02202302031032458146",
      "goodsNm": "Test",
      "vacctValidDt": "20230205",
      "vacctValidTm": "103245",
      "msId": null,
      "msFee": null,
      "msFeeType": null,
      "mbFee": null,
      "mbFeeType": null
    }
  }
}
```

&nbsp;
## 2. DELETE /api/vacct/bi-snap/delete

Request:

- body:

```json
{
  "bankCd": "BDIN",
  "trxId" : "order1724150636675",
  "amount": "10000.00",
  "virtualAccountNo" : "7915000002002482",
  "tXidVA" : "NORMALTEST02202408201743566921"
}
```

_Response (200 - OK)_

```json
{
    "responseCode": "2003100",
    "responseMessage": "Successful",
    "virtualAccountData": {
        "partnerServiceId": "",
        "customerNo": "",
        "virtualAccountNo": "7915000002002482",
        "trxId": "order1724150636675",
        "additionalInfo": {
            "cancelVATime": "2024-08-20T17:43:56+07:00",
            "totalAmount": {
                "value": "10000.00",
                "currency": "IDR"
            },
            "tXidVA": "NORMALTEST02202408201743566921"
        }
    }
}
```

## 3. POST /api/ewallet/bi-snap/regist

Request:

- body:

```json
{
  "mitraCd": "OVOE"
}
```

_Response (201 - Created)_

```json
{
  "responseCode": "2005400",
  "responseMessage": "Successful",
  "partnerReferenceNo": "order1675395207943",
  "originalReferenceNo": "IONPAYTEST05202302031033278147"
}
```

&nbsp;

## 3. POST /api/ewallet/bi-snap/inquiry

Request:

- body:

```json
{
  "originalPartnerReferenceNo": "order1675322716736",
  "originalReferenceNo": "IONPAYTEST05202302021425177555"
}
```

_Response (200 - OK)_

```json
{
  "responseCode": "2005500",
  "responseMessage": "Successful",
  "originalPartnerReferenceNo": "order1675322716736",
  "originalReferenceNo": "IONPAYTEST05202302021425177555",
  "serviceCode": "54",
  "latestTransactionStatus": "04",
  "transactionStatusDesc": "Refunded",
  "transAmount": {
    "currency": "IDR",
    "value": "10000.00"
  },
  "additionalInfo": {
    "goodsNm": "Test",
    "mitraCd": "OVOE",
    "billingPhone": "0851141347531",
    "billingNm": "Buyer Name"
  }
}
```

&nbsp;

## 4. POST /api/ewallet/bi-snap/refund

Request:

- body:

```json
{
  "originalPartnerReferenceNo": "order1675395207943",
  "originalReferenceNo": "IONPAYTEST05202302031033278147"
}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2005800",
  "responseMessage": "Successful",
  "originalPartnerReferenceNo": "order1675395207943",
  "originalReferenceNo": "IONPAYTEST05202302031626308431",
  "refundAmount": {
    "currency": "IDR",
    "value": "10000.00"
  },
  "refundNo": "IONPAYTEST05202302031033278147",
  "partnerRefundNo": "order1675416391973"
}
```

&nbsp;

## 6. POST /api/qris/bi-snap/regist

Request:

- body:

```json
{}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2004700",
  "responseMessage": "Successful",
  "referenceNo": "IONPAYTEST08202302031710098483",
  "partnerReferenceNo": "order1675419011862",
  "qrContent": "00020101021226580016ID.CO.SHOPEE.WWW01189360091800000169110205169110303UMI520412345303360540810000.005802ID5907NICEPAY6015KOTA JAKARTA PU61051234562360520082023020317101060460708T00000016304664D",
  "qrUrl": "https://mapi.gw.uat.airpay.co.id/v3/merchant-host/qr/download?qr=Tx4TChU9nGSwooatVSmOpL6a8KHsiHs7KvTNqEMGMJ",
  "additionalInfo": {
    "goodsNm": "Test",
    "billingNm": "Buyer Name",
    "mitraCd": "QSHP",
    "validityPeriod": "2023-02-03T17:15:09+07:00"
  }
}
```

&nbsp;

## 7. POST /api/qris/bi-snap/inquiry

Request:

- body:

```json
{
  "originalReferenceNo": "IONPAYTEST08202302031710098483",
  "originalPartnerReferenceNo": "order1675419011862"
}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2005100",
  "responseMessage": "Successful",
  "originalReferenceNo": "IONPAYTEST08202302031710098483",
  "originalPartnerReferenceNo": "order1675419011862",
  "serviceCode": "51",
  "latestTransactionStatus": "03",
  "paidTime": "2023-02-03T17:10:10+07:00",
  "amount": {
    "value": "10000.00",
    "currency": "IDR"
  },
  "additionalInfo": {
    "goodsNm": "Test",
    "billingNm": "Buyer Name",
    "merchantId": "IONPAYTEST",
    "paymentTrxSn": "",
    "cancelTrxSn": "",
    "userId": "",
    "externalStoreId": "NICEPAY",
    "requestTime": "2023-02-03T17:10:09+07:00"
  }
}
```

&nbsp;

## 8. POST /api/qris/bi-snap/refund

Request:

- body:

```json
{
  "originalReferenceNo": "IONPAYTEST08202302031710098483",
  "originalPartnerReferenceNo": "order1675419011862"
}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2005100",
  "responseMessage": "Successful",
  "originalReferenceNo": "IONPAYTEST08202302031712568486",
  "referenceNo": "IONPAYTEST08202302031710098483",
  "partnerRefundNo": "order1675419011862",
  "refundTime": "2023-02-03T17:10:10+07:00",
  "refundAmount": {
    "value": "10000.00",
    "currency": "IDR"
  },
  "additionalInfo": {
    "cancelTrxSn": ""
  }
}
```

&nbsp;

## 9. POST /api/payout/bi-snap/regist

Request:

- body:

```json
{}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2000000",
  "responseMessage": "Successful",
  "partnerReferenceNo": "order1675420052795",
  "originalReferenceNo": "IONPAYTEST07202302031727308502",
  "beneficiaryaccountNo": "5345000060",
  "beneficiaryName": "NICEPAY",
  "payoutMethod": "1",
  "beneficiaryBankCode": "CENA",
  "amount": {
    "value": "12345678.00",
    "currency": "IDR"
  }
}
```

&nbsp;

## 10. POST /api/payout/bi-snap/approve

Request:

- body:

```json
{
  "originalPartnerReferenceNo": "order1675420052795",
  "originalReferenceNo": "IONPAYTEST07202302031727308502"
}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2000000",
  "responseMessage": "Successful",
  "originalPartnerReferenceNo": "order1675420052795",
  "originalReferenceNo": "IONPAYTEST07202302031727308502",
  "beneficiaryAccountNo": "5345000060",
  "beneficiaryName": "NICEPAY",
  "beneficiaryBankCode": "CENA",
  "amount": {
    "value": "12345678.00",
    "currency": "IDR"
  },
  "transactionStatus": "03"
}
```

&nbsp;

## 11. POST /api/payout/bi-snap/inquiry

Request:

- body:

```json
{
  "originalPartnerReferenceNo": "order1675420052795",
  "originalReferenceNo": "IONPAYTEST07202302031727308502"
}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2000000",
  "responseMessage": "Successful",
  "originalPartnerReferenceNo": "order1675420052795",
  "originalReferenceNo": "IONPAYTEST07202302031727308502",
  "beneficiaryAccountNo": "5345000060",
  "beneficiaryName": "IONPAY NETWORKS",
  "beneficiaryBankCode": "CENA",
  "beneficiaryCustomerResidence": "1",
  "beneficiaryCustomerType": "1",
  "amount": {
    "value": "12345678.00",
    "currency": "IDR"
  },
  "latestTransactionStatus": "03",
  "transactionStatusDesc": "Pending"
}
```

&nbsp;

## 12. POST /api/payout/bi-snap/cancel

Request:

- body:

```json
{
  "originalPartnerReferenceNo": "order1675420052795",
  "originalReferenceNo": "IONPAYTEST07202302031727308502"
}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2000000",
  "responseMessage": "Successful",
  "originalPartnerReferenceNo": "order1675420052795",
  "originalReferenceNo": "IONPAYTEST07202302031727308502",
  "beneficiaryAccountNo": "5345000060",
  "beneficiaryName": "NICEPAY",
  "beneficiaryBankCode": "CENA",
  "amount": {
    "value": "12345678.00",
    "currency": "IDR"
  }
}
```

&nbsp;

## 13. POST /api/payout/bi-snap/reject

Request:

- body:

```json
{
  "originalPartnerReferenceNo": "order1675421181022",
  "originalReferenceNo": "IONPAYTEST07202302031746188545"
}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2000000",
  "responseMessage": "Successful",
  "originalPartnerReferenceNo": "order1675421181022",
  "originalReferenceNo": "IONPAYTEST07202302031746188545",
  "beneficiaryAccountNo": "5345000060",
  "beneficiaryName": "NICEPAY",
  "beneficiaryBankCode": "CENA",
  "amount": {
    "value": "12345678.00",
    "currency": "IDR"
  }
}
```

&nbsp;

## 14. POST /api/payout/bi-snap/balance-inquiry

Request:

- body:

```json
{}
```

\_Response (200 - OK)\_

```json
{
  "responseCode": "2001100",
  "responseMessage": "Successful",
  "availableBalance": {
    "value": "8549247415.00",
    "currency": "IDR"
  }
}
```

&nbsp;
