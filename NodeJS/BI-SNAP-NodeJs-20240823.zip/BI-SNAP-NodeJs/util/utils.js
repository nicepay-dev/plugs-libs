const crypto = require("crypto");
const { DateTime } = require("luxon");

const generateXExternalId = () => {
    return `${crypto
        .randomBytes(4)
        .readUInt32BE(0)}${Date.now()}`
}

const generateXTimestamp = () => {
    const date = DateTime.local();
    return date.toFormat("yyyy-MM-dd'T'HH:mm:ssZZ");
}

module.exports = {generateXExternalId, generateXTimestamp}