<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yC3fHCxyoN7T3y2s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dUsrXFs7QESc3IWF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iXc7Bab982ItlwSh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/v1.0/access-token' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gih2sBQBebtvWBTr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/transfer-va/create-va' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mKvip6sJ7xGEL0Da',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/qr/qr-mpm-generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f33ftEPbEVtCGinZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/qr/qr-mpm-query' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vhB6jM2fNciymluE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/qr/qr-mpm-refund' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9JtTPJdc2Qtwqjdk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/debit/payment-host-to-host' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::49b4fRxHexUO3vdc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/debit/status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pxUzMweviQarFPpq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/debit/refund' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F4CdKdzNF1Q61ilc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/transfer/registration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6fP9bIS8NKr5eaoS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/transfer/approve' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YSU2Od0hacTrqb4M',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/transfer/inquiry' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bcDhBiSuTmrjLWPM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/transfer/balance-inquiry' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MPPsXBIqP5XsumUX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/transfer/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QEjM6V1y7nsANvSY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1.0/transfer/reject' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jlfqBr8YaEMIDYaH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
    ),
    3 => 
    array (
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::yC3fHCxyoN7T3y2s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::yC3fHCxyoN7T3y2s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dUsrXFs7QESc3IWF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001c1fe861000000000ca70f4f";}";s:4:"hash";s:44:"HOCSPFaCQsXlbYkKB2UPaiNXGy+1anAPR88zyko1egw=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::dUsrXFs7QESc3IWF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iXc7Bab982ItlwSh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:269:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:51:"function () {
    return \\view(\'template.index\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000001c1fe863000000000ca70f4f";}";s:4:"hash";s:44:"6m17EGLXK1vRropCN4CtF8Ph8xxxCdHrcuvVzP9jY8M=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::iXc7Bab982ItlwSh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Gih2sBQBebtvWBTr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'v1.0/access-token',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\accessToken\\GenerateAccessTokenController@generateAccessToken',
        'controller' => 'App\\Http\\Controllers\\api\\accessToken\\GenerateAccessTokenController@generateAccessToken',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/v1.0',
        'where' => 
        array (
        ),
        'as' => 'generated::Gih2sBQBebtvWBTr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mKvip6sJ7xGEL0Da' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/transfer-va/create-va',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\va\\GenerateVirtualAccountController@generateVirtualAccount',
        'controller' => 'App\\Http\\Controllers\\api\\va\\GenerateVirtualAccountController@generateVirtualAccount',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '/api/v1.0',
        'where' => 
        array (
        ),
        'as' => 'generated::mKvip6sJ7xGEL0Da',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f33ftEPbEVtCGinZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/qr/qr-mpm-generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\qris\\GenerateQrisController@generateQris',
        'controller' => 'App\\Http\\Controllers\\api\\qris\\GenerateQrisController@generateQris',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/qr',
        'where' => 
        array (
        ),
        'as' => 'generated::f33ftEPbEVtCGinZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vhB6jM2fNciymluE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/qr/qr-mpm-query',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\qris\\GenerateQrisController@inquiryQris',
        'controller' => 'App\\Http\\Controllers\\api\\qris\\GenerateQrisController@inquiryQris',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/qr',
        'where' => 
        array (
        ),
        'as' => 'generated::vhB6jM2fNciymluE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9JtTPJdc2Qtwqjdk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/qr/qr-mpm-refund',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\qris\\GenerateQrisController@refundQris',
        'controller' => 'App\\Http\\Controllers\\api\\qris\\GenerateQrisController@refundQris',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/qr',
        'where' => 
        array (
        ),
        'as' => 'generated::9JtTPJdc2Qtwqjdk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::49b4fRxHexUO3vdc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/debit/payment-host-to-host',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\ewallet\\GenerateEwalletController@generateEwallet',
        'controller' => 'App\\Http\\Controllers\\api\\ewallet\\GenerateEwalletController@generateEwallet',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/debit',
        'where' => 
        array (
        ),
        'as' => 'generated::49b4fRxHexUO3vdc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pxUzMweviQarFPpq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/debit/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\ewallet\\GenerateEwalletController@inquiryEwallet',
        'controller' => 'App\\Http\\Controllers\\api\\ewallet\\GenerateEwalletController@inquiryEwallet',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/debit',
        'where' => 
        array (
        ),
        'as' => 'generated::pxUzMweviQarFPpq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::F4CdKdzNF1Q61ilc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/debit/refund',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\ewallet\\GenerateEwalletController@refundEwallet',
        'controller' => 'App\\Http\\Controllers\\api\\ewallet\\GenerateEwalletController@refundEwallet',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/debit',
        'where' => 
        array (
        ),
        'as' => 'generated::F4CdKdzNF1Q61ilc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6fP9bIS8NKr5eaoS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/transfer/registration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@generatePayout',
        'controller' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@generatePayout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/transfer',
        'where' => 
        array (
        ),
        'as' => 'generated::6fP9bIS8NKr5eaoS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YSU2Od0hacTrqb4M' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/transfer/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@approvePayout',
        'controller' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@approvePayout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/transfer',
        'where' => 
        array (
        ),
        'as' => 'generated::YSU2Od0hacTrqb4M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bcDhBiSuTmrjLWPM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/transfer/inquiry',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@inquiryPayout',
        'controller' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@inquiryPayout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/transfer',
        'where' => 
        array (
        ),
        'as' => 'generated::bcDhBiSuTmrjLWPM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MPPsXBIqP5XsumUX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/transfer/balance-inquiry',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@balanceInquiryPayout',
        'controller' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@balanceInquiryPayout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/transfer',
        'where' => 
        array (
        ),
        'as' => 'generated::MPPsXBIqP5XsumUX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QEjM6V1y7nsANvSY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/transfer/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@cancelPayout',
        'controller' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@cancelPayout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/transfer',
        'where' => 
        array (
        ),
        'as' => 'generated::QEjM6V1y7nsANvSY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jlfqBr8YaEMIDYaH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1.0/transfer/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@rejectPayout',
        'controller' => 'App\\Http\\Controllers\\api\\payout\\GeneratePayoutController@rejectPayout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/v1.0/transfer',
        'where' => 
        array (
        ),
        'as' => 'generated::jlfqBr8YaEMIDYaH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
