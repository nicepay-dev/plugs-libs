<?php

return [
    'merchant_id' => '',
    'private_key' => '',
    'client_secret' => '',
    'access_token' => '',
    'original_partner_reference_no' => '',
    'original_reference_no' => '',
];
